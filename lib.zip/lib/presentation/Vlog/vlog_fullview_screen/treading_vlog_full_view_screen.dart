import 'package:flutter/material.dart';
import 'package:frenly_app/core/utils/pref_utils.dart';
import 'package:frenly_app/core/utils/size_utils.dart';
import 'package:frenly_app/presentation/Vlog/vlog_fullview_screen/vlog_full_view_controller.dart';
import 'package:frenly_app/presentation/home_screen/controller/home_controller.dart';
import 'package:get/get.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:video_player/video_player.dart';
import '../../../Widgets/custom_appbar.dart';
import '../../../Widgets/custom_image_view.dart';
import '../../../core/utils/calculateTimeDifference.dart';
import '../../../data/repositories/api_repository.dart';
import '../../auth/my_profile_view/my_profile_controller.dart';
import '../../user_profile_screen/user_profile_screen.dart';
import '../edit_vlog/edit_vlog.dart';
import '../treading_vlog_controller.dart';
import '../vlog_like_commnet_share_common_view.dart';


class VlogFullViewScreen extends StatefulWidget {
  final String videoUrl;
  final String vlogId;

  const VlogFullViewScreen(
      {super.key, required this.videoUrl, required this.vlogId});

  @override
  _VlogFullViewScreenState createState() => _VlogFullViewScreenState();
}

class _VlogFullViewScreenState extends State<VlogFullViewScreen> {
  @override
  Widget build(BuildContext context001) {
    return SafeArea(
      child: Scaffold(
        appBar: customAppbar(
          title: "vloggs".tr,
          context: context001,
        ),
        body: Dsdfdfgfdfgf(videoUrl: widget.videoUrl, vlogId: widget.vlogId),
      ),
    );
  }

  TrendingVlogController trendingVlogController =
      Get.put(TrendingVlogController());
}

class Dsdfdfgfdfgf extends StatefulWidget {
  final String videoUrl;

  final String vlogId;

  const Dsdfdfgfdfgf({super.key, required this.videoUrl, required this.vlogId});

  @override
  State<Dsdfdfgfdfgf> createState() => _DsdfdfgfdfgfState();
}

class _DsdfdfgfdfgfState extends State<Dsdfdfgfdfgf> {
  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  HomeController controller = Get.find<HomeController>();
  VlogSingleViewController vlogSingleViewController = Get.put(VlogSingleViewController());

  late VideoPlayerController _controller;

  @override
  void initState() {
    super.initState();
    vlogSingleViewController.getVlogById(vlogId: widget.vlogId);
    _controller = VideoPlayerController.networkUrl(Uri.parse(widget.videoUrl))
      ..initialize().then((_) {
        _controller.play();
        setState(() {});
      });
  }

  TrendingVlogController trendingVlogController =
      Get.put(TrendingVlogController());

  @override
  Widget build(BuildContext context) {
    vlogSingleViewController.context=context;
    return Scaffold(
      body: Obx(
        () => vlogSingleViewController.isLoading.value
            ? const Center(child: CircularProgressIndicator())
            : ListView(
                children: [
                  Padding(
                    padding: EdgeInsets.all(14.0.aw),
                    child: Column(
                      children: [
                        InkWell(
                          onTap: () {
                            setState(() {
                              _controller.value.isPlaying
                                  ? _controller.pause()
                                  : _controller.play();
                            });
                          },
                          child: Center(
                            child: _controller.value.isInitialized
                                ? ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child: AspectRatio(
                                      aspectRatio: 2,
                                      child: VideoPlayer(_controller),
                                    ),
                                  )
                                : SizedBox(
                                    width: double.infinity,
                                    height: 170.ah,
                                    child: const Center(
                                        child: CircularProgressIndicator()),
                                  ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(left: 2.0.aw, right: 2.aw),
                          child: userLikeViewShare1(context),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Padding(
                          padding: EdgeInsets.only(left: 2.0.aw, right: 2.aw),
                          child: SizedBox(
                            height: 34.ah,
                            child: Row(
                              children: [
                                Text(
                                  '${vlogSingleViewController.vlogByIdModel.vlog?.user?.numberOfFollower}',
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 18.adaptSize,
                                    fontFamily: 'Roboto',
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: -0.41,
                                  ),
                                ),
                                SizedBox(
                                  width: 10.aw,
                                ),
                                 Opacity(
                                  opacity: 0.50,
                                  child: Text(
                                    'Followers'.tr,
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 16,
                                      fontFamily: 'Roboto',
                                      fontWeight: FontWeight.w600,
                                      letterSpacing: -0.41,
                                    ),
                                  ),
                                ),
                                Spacer(),
                                VlogLikeCommentsShareView(
                                  vlog: vlogSingleViewController.vlogByIdModel.vlog!,
                                  colors: true,
                                ),
                                Spacer(),
                                // Text("data${ PrefUtils().getUserId()}"),
                                // Text("data${vlogSingleViewController.vlogByIdModel.vlog!.user?.id}"),
                                PrefUtils().getUserId() == "${vlogSingleViewController.vlogByIdModel.vlog!.user?.id}"
                                    ? const SizedBox()
                                    : InkWell(
                                        onTap: () async {
                                          if(vlogSingleViewController.vlogByIdModel.vlog!.isFollowed==false){
                                           await ApiRepository.follow(userId: "${vlogSingleViewController.vlogByIdModel.vlog!.user?.id}");
                                           setState(() {
                                             vlogSingleViewController.vlogByIdModel.vlog!.isFollowed=true;
                                           });
                                          }else{
                                            await  ApiRepository.unfollow(userId: "${vlogSingleViewController.vlogByIdModel.vlog!.user?.id}");
                                            setState(() {
                                              vlogSingleViewController.vlogByIdModel.vlog!.isFollowed=false;
                                            });

                                          }

                                        },
                                        child: Container(
                                          width: 98.aw,
                                          height: 34.ah,
                                          decoration: ShapeDecoration(
                                            color: const Color(0xFF001649),
                                            shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(4)),
                                          ),
                                          child: Center(
                                            child: Text(
                                              vlogSingleViewController.vlogByIdModel.vlog!.isFollowed ==false? "Follow".tr : "Unfollow".tr,
                                              textAlign: TextAlign.center,
                                              style: const TextStyle(
                                                color: Colors.white,
                                                fontSize: 14,
                                                fontFamily: 'Roboto',
                                                fontWeight: FontWeight.w500,
                                                height: 0,
                                              ),
                                            ),
                                          ),
                                        ),
                                      )
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        discoverUsers(),
                        const SizedBox(
                          height: 15,
                        ),
                      ],
                    ),
                  ),
                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    scrollDirection: Axis.vertical,
                    itemCount:
                        trendingVlogController.trendingVlogModel.vlogs?.length,
                    padding: const EdgeInsets.only(bottom: 10),
                    itemBuilder: (context, index) {
                      return InkWell(
                        onTap: () {
                          print(
                              "sdfghgfdfgfdfgfdfg${trendingVlogController.trendingVlogModel.vlogs![index].id}");
                          print(
                              "videoUrlvideoUrl${trendingVlogController.trendingVlogModel.vlogs![index].videoUrl}");

                          Get.off(() => VlogFullViewScreen(
                                vlogId: trendingVlogController.trendingVlogModel.vlogs![index].id.toString(),
                                videoUrl: '${trendingVlogController.trendingVlogModel.vlogs![index].videoUrl}',
                              ));
                        },
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            SizedBox(
                              height: 196.ah,
                              width: double.infinity,
                              child: Stack(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        left: 15.0, right: 15, bottom: 15),
                                    child: CustomImageView(
                                      height: 196.ah,
                                      width: double.infinity,
                                      radius:
                                          BorderRadius.circular(15.adaptSize),
                                      fit: BoxFit.cover,
                                      // color: Colors.black,
                                      imagePath: trendingVlogController
                                          .trendingVlogModel
                                          .vlogs?[index]
                                          .thumbnailUrl,
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        left: 15.0, right: 15, bottom: 15),
                                    child: Container(
                                      height: 196.ah,
                                      width: double.infinity,
                                      decoration: ShapeDecoration(
                                        gradient: LinearGradient(
                                          end: const Alignment(-0.45, 0.87),
                                          begin: const Alignment(0.45, -0.87),
                                          colors: [
                                            Colors.black.withOpacity(.10),
                                            Colors.black.withOpacity(.55),
                                          ],
                                        ),
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(
                                              15.adaptSize),
                                        ),
                                      ),
                                    ),
                                  ),
                                  vlogInLocationRow(index),
                                  Padding(
                                    padding: EdgeInsets.only(
                                        left: 15.0,
                                        right: 15,
                                        bottom: 15,
                                        top: 116.ah),
                                    child: SizedBox(
                                      height: 160.ah,
                                      width: double.infinity,
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.only(
                                              left: 15.0,
                                            ),
                                            child: Text(
                                              '${trendingVlogController.trendingVlogModel.vlogs?[index].title}'
                                                  .capitalizeFirst!,
                                              style: TextStyle(
                                                  color:
                                                      const Color(0xffFFFFFF),
                                                  fontWeight: FontWeight.w700,
                                                  fontSize: 16.fSize,
                                                  height: 1.5),
                                            ),
                                          ),
                                          const SizedBox(
                                            height: 5,
                                          ),
                                          Row(
                                            children: [
                                              Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                children: [
                                                  SizedBox(width: 10.ah),
                                                  CustomImageView(
                                                    height: 30.ah,
                                                    width: 30.ah,
                                                    imagePath:
                                                        trendingVlogController
                                                            .trendingVlogModel
                                                            .vlogs?[index]
                                                            .user
                                                            ?.avatarUrl,
                                                    radius:
                                                        BorderRadius.circular(
                                                            30.ah),
                                                    fit: BoxFit.cover,
                                                  ),
                                                  SizedBox(
                                                    width: 80,
                                                    child: Text(
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      "  ${'${trendingVlogController.trendingVlogModel.vlogs![index].user?.handle}  '.capitalizeFirst!}",
                                                      style: TextStyle(
                                                        color: const Color(
                                                            0xffFFFFFF),
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        fontSize: 11.fSize,
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    '${trendingVlogController.trendingVlogModel.vlogs![index].numberOfViews} views  ',
                                                    style: TextStyle(
                                                      color: const Color(
                                                          0xffFFFFFF),
                                                      fontWeight:
                                                          FontWeight.w600,
                                                      fontSize: 11.fSize,
                                                    ),
                                                  ),
                                                  Text(
                                                    '${calculateTimeDifference("${trendingVlogController.trendingVlogModel.vlogs![index].createdAt}")}',
                                                    style: TextStyle(
                                                      color: const Color(
                                                          0xffFFFFFF),
                                                      fontWeight:
                                                          FontWeight.w600,
                                                      fontSize: 11.fSize,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              const Spacer(),
                                              VlogLikeCommentsShareView(
                                                vlog: trendingVlogController
                                                    .trendingVlogModel
                                                    .vlogs![index],
                                              ),
                                              SizedBox(width: 15.0.aw)
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  )
                ],
              ),
      ),
    );
  }

  Widget userLikeViewShare1(BuildContext context001) {
    return Column(
      children: [
        SizedBox(
          height: 10,
        ),
        Container(
          // color: Colors.grey,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomImageView(
                height: 50.ah,
                width: 50.ah,
                fit: BoxFit.cover,
                radius: BorderRadius.circular(50),
                imagePath: vlogSingleViewController
                    .vlogByIdModel.vlog?.user?.avatarUrl,
              ),
              SizedBox(
                width: 10.aw,
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${vlogSingleViewController.vlogByIdModel.vlog?.title}'
                        .capitalizeFirst!,
                    style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 16.adaptSize,
                        height: 1.5),
                  ),
                  Row(
                    children: [
                      Text(
                        '${vlogSingleViewController.vlogByIdModel.vlog?.user?.fullName} :  '
                            .capitalizeFirst!,
                        style: TextStyle(
                          color: Colors.black.withOpacity(.50),
                          fontWeight: FontWeight.w600,
                          fontSize: 11.fSize,
                        ),
                      ),
                      Text(
                        '${vlogSingleViewController.vlogByIdModel.vlog?.numberOfViews} views :  ',
                        style: TextStyle(
                          color: Colors.black.withOpacity(.50),
                          fontWeight: FontWeight.w600,
                          fontSize: 11.fSize,
                        ),
                      ),
                      Builder(builder: (context) {
                        DateTime currentDate = DateTime.now();
                        DateTime createdAtDate = DateTime.parse("${vlogSingleViewController.vlogByIdModel.vlog?.createdAt}");

                        return Text(
                          '${calculateTimeDifference(vlogSingleViewController.vlogByIdModel.vlog!.createdAt.toString())}',
                          style: TextStyle(
                            color: Colors.black.withOpacity(.50),
                            fontWeight: FontWeight.w600,
                            fontSize: 11.fSize,
                          ),
                        );
                      }),
                    ],
                  )
                ],
              ),
              const Spacer(),
              PrefUtils().getUserId() == "${vlogSingleViewController.vlogByIdModel.vlog!.user?.id}" ?
              InkWell(
                  onTap: () {
                    _bottomSheetWidget3(vlogId: '${vlogSingleViewController.vlogByIdModel.vlog!.id}');
                  },
                  child: CustomImageView(
                    imagePath: "assets/image/ic_info_outline_24px.png",
                    height: 25,
                    color: Colors.red,
                  )):  InkWell(
                  onTap: () {
                    _bottomSheetWidget2();
                  },
                  child: CustomImageView(
                    imagePath: "assets/image/ic_info_outline_24px.png",
                    height: 25,
                  )),
              SizedBox(
                width: 20,
              )
            ],
          ),
        ),
      ],
    );
  }

  _bottomSheetWidget2() {
    showBottomSheet(
        context: context,
        builder: (BuildContext context) {
          return FractionallySizedBox(
              heightFactor: .50,
              child: GestureDetector(
                onTap: () {
                  Get.back();
                },
                child: Container(
                  decoration:
                      BoxDecoration(borderRadius: BorderRadius.circular(20)),
                  child: Container(
                    // color: Colors.white,
                    child: Padding(
                      padding: EdgeInsets.only(left: 20.0.ah, right: 20.ah),
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            SizedBox(
                              width: double.infinity,
                            ),
                            const SizedBox(
                              height: 20,
                            ),
                            Center(
                                child: Text("Description",
                              style: TextStyle(
                                  fontWeight: FontWeight.w600, fontSize: 25),
                            )),
                            const SizedBox(
                              height: 20,
                            ),
                            Text(
                              "${vlogSingleViewController.vlogByIdModel.vlog?.description}",
                              style: TextStyle(fontSize: 18.adaptSize),
                            ),
                            const SizedBox(
                              height: 20,
                            ),
                          ]),
                    ),
                  ),
                ),
              ));
        }).closed.then((value) {});
  }
  _bottomSheetWidget3(
      { required String vlogId}) {
    MyProfileController myProfileControllerasd =Get.find();
    VlogSingleViewController myProfileController=Get.find();
    showBottomSheet(
        context: myProfileController.context,
        builder: (BuildContext context) {
          return FractionallySizedBox(
              heightFactor: .25,
              child: GestureDetector(
                onTap: () {
                  Get.back();
                },
                child: Container(
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20)
                  ),
                  child: Container(
                    // color: Colors.white,
                    child: Padding(
                      padding: EdgeInsets.only(left: 20.0.ah, right: 20.ah),
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const SizedBox(height: 40,),
                            InkWell(
                              onTap: () async {
                                await  ApiRepository.deleteVlog(postId: "${vlogId}");
                                myProfileControllerasd.getProfile();
                                Get.back();

                              },
                              child: Row(
                                children: [
                                  CustomImageView(
                                    height: 38,
                                    width: 38,
                                    imagePath: "assets/image/delete (1).png",
                                  ),
                                  SizedBox(width: 20,),
                                  const SizedBox(
                                    child: Text("Delete this Blog"),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 20,),
                            InkWell(
                              onTap: () async {
                             //   Get.to(()=>BlogsEditScreen(getBlogByIdModel: vlogId,));
                                 Get.to(()=>EditVlogScreen(vlogByIdModel: vlogSingleViewController.vlogByIdModel,));
                              },
                              child: Row(
                                children: [
                                  CustomImageView(
                                    height: 38,
                                    width: 38,
                                    imagePath: "assets/image/edit_with_container.png",
                                  ),
                                  SizedBox(width: 20,),
                                  const SizedBox(
                                    child: Text("Edit this Blog"),
                                  ),
                                ],
                              ),
                            ),
                          ]),
                    ),
                  ),
                ),
              ));
        }).closed.then((value) {});
  }

  Widget discoverUsers() {
    return SizedBox(
      height: 223.ah,
      child: Obx(
        () => ListView.builder(
          shrinkWrap: true,
          scrollDirection: Axis.horizontal,
          itemCount: controller.homeModel.discoverUsers?.length,
          itemBuilder: (context, index) {
            return Padding(
              padding: const EdgeInsets.only(right: 14.0),
              child: InkWell(
                onTap: () {
                  Get.to(() => UserProfileScreen(
                        userId:
                            '${controller.homeModel.discoverUsers?[index].id}',
                      ));
                },
                child: Container(
                  height: 223.ah,
                  width: 120.aw,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(7),
                      border: Border.all(
                          //color: HexColor('#FFFFFF'),
                          color: Colors.black12,
                          width: 1)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CustomImageView(
                        radius: BorderRadius.circular(100.ah),
                        height: 100.ah,
                        width: 100.ah,
                        imagePath: controller
                            .homeModel.discoverUsers?[index].coverPhotoUrl,
                        fit: BoxFit.cover,
                      ),
                      SizedBox(height: 4.ah),
                      Text(
                        '${controller.homeModel.discoverUsers?[index].fullName?.capitalizeFirst}',
                        style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.w500,
                            fontSize: 13.fSize),
                      ),
                      SizedBox(height: 2.ah),
                      Text(
                        '${controller.homeModel.discoverUsers?[index].handle ?? ""}',
                        style: TextStyle(
                            color: Colors.grey,
                            fontWeight: FontWeight.w600,
                            fontSize: 12.fSize),
                      ),
                      SizedBox(height: 2.ah),
                      Text(
                        '${controller.homeModel.discoverUsers?[index].numberOfFollower}',
                        style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.w500,
                            fontSize: 12.fSize),
                      ),
                      SizedBox(height: 10.ah),
                      InkWell(
                        onTap: () {
                          setState(
                            () {
                              controller.homeModel.discoverUsers![index]
                                      .isFollowed =
                                  !controller.homeModel.discoverUsers![index]
                                      .isFollowed!;
                              if (controller.homeModel.discoverUsers![index]
                                  .isFollowed!) {
                                ApiRepository.follow(
                                    userId:
                                        "${controller.homeModel.discoverUsers![index].id!}");
                              } else {
                                ApiRepository.unfollow(
                                    userId:
                                        "${controller.homeModel.discoverUsers![index].id!}");
                              }
                            },
                          );
                        },
                        child: Container(
                          height: 24.ah,
                          width: 98.aw,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4),
                            color: controller
                                    .homeModel.discoverUsers![index].isFollowed!
                                ? Colors.red
                                : HexColor('#001649'),
                          ),
                          child: Center(
                            child: Text(
                              controller.homeModel.discoverUsers![index].isFollowed! ? "Unfollow".tr : "Follow".tr,
                              style: TextStyle(
                                  color: controller.homeModel
                                          .discoverUsers![index].isFollowed!
                                      ? Colors.white
                                      : Colors.white,
                                  fontWeight: FontWeight.w500,
                                  fontSize: 14.fSize),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget vlogInLocationRow(int index) {
    return Padding(
      padding: const EdgeInsets.only(left: 15.0, right: 15, bottom: 15),
      child: SizedBox(
        height: 40.ah,
        width: double.infinity,
        child: Row(
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 10.0),
              child: Image.asset(
                'assets/image/location-outline.png',
                width: 21.ah,
                height: 21.ah,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 10.0),
              child: Text(
                '${trendingVlogController.trendingVlogModel.vlogs?[index].user?.city}, ',
                style: TextStyle(
                  color: Color(0xffFFFFFF),
                  fontWeight: FontWeight.w600,
                  fontSize: 11.fSize,
                ),
              ),
            ),
            Text(
              '${trendingVlogController.trendingVlogModel.vlogs?[index].user?.country}',
              style: TextStyle(
                color: Color(0xffFFFFFF),
                fontWeight: FontWeight.w600,
                fontSize: 11.fSize,
              ),
            ),
            Spacer(),
            Builder(builder: (context) {
              try {
                MyProfileController controller = Get.find();
                if (controller.getUserByIdModel.user?.id ==
                    trendingVlogController
                        .trendingVlogModel.vlogs?[index].userId) {
                  return SizedBox(

                    width: 22.aw,
                  );
                }
              } catch (e) {}
              return const SizedBox.shrink();
            }),
            SizedBox(
              width: 20,
            )
          ],
        ),
      ),
    );
  }
}
