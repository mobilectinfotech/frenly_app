import 'package:flutter/cupertino.dart';
import 'package:frenly_app/data/models/vlog_by_id_model.dart';
import 'package:frenly_app/data/repositories/api_repository.dart';
import 'package:get/get.dart';



class VlogSingleViewController extends GetxController {
  late BuildContext context;

  VlogByIdModel vlogByIdModel=VlogByIdModel();
  RxBool isLoading =false.obs;
  getVlogById({required String vlogId}) async {
    isLoading.value=true;
    vlogByIdModel  =await ApiRepository.getVlogById(userId:vlogId );
    isLoading.value=false;
  }


}