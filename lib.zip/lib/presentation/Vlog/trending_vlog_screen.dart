import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:frenly_app/Widgets/custom_appbar.dart';
import 'package:frenly_app/core/utils/calculateTimeDifference.dart';
import 'package:frenly_app/core/utils/size_utils.dart';
import 'package:frenly_app/presentation/Vlog/treading_vlog_controller.dart';
import 'package:frenly_app/presentation/Vlog/vlog_fullview_screen/treading_vlog_full_view_screen.dart';
import 'package:frenly_app/presentation/Vlog/vlog_like_commnet_share_common_view.dart';
import 'package:get/get.dart';
import '../../Widgets/custom_image_view.dart';

class TreadingVlogScreen extends StatefulWidget {
  const TreadingVlogScreen({super.key});

  @override
  State<TreadingVlogScreen> createState() => _TreadingVlogScreenState();
}

class _TreadingVlogScreenState extends State<TreadingVlogScreen> {
  TrendingVlogController controller = Get.find();
  double keyboardHeight = 0;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    controller.getVlog();
  }

  @override
  Widget build(BuildContext contexttt) {
    return SafeArea(
      child: Scaffold(
        appBar: customAppbar(context: context, title: 'Trendingvloggs'.tr),
        body: Obx(() => controller.isLoading.value
            ? const Center(
          child: CircularProgressIndicator(),
        )
            : VlogView()),
      ),
    );
  }
}

class VlogView extends StatefulWidget {
  const VlogView({super.key});

  @override
  State<VlogView> createState() => _VlogViewState();
}

class _VlogViewState extends State<VlogView> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  ScrollController _scrollController = ScrollController();
  TrendingVlogController controller = Get.find();

  void scrollUp() {
    print("scrollUp");
    _scrollController.animateTo(_scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
  }

  @override
  Widget build(BuildContext context) {
    TrendingVlogController controller = Get.find();
    controller.context=context;
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarIconBrightness: Brightness.dark,
      statusBarColor: Colors.white, //
    ));

    return SizedBox(
      width: double.infinity,
      child: ListView.builder(
        shrinkWrap: true,
        physics: const AlwaysScrollableScrollPhysics(),
        scrollDirection: Axis.vertical,
        itemCount: controller.trendingVlogModel.vlogs?.length,
        padding: const EdgeInsets.only(bottom: 10),
        itemBuilder: (context, index) {
          return InkWell(
            onTap: () {
              print(
                  "sdfghgfdfgfdfgfdfg${controller.trendingVlogModel.vlogs![index].id}");
              print(
                  "videoUrlvideoUrl${controller.trendingVlogModel.vlogs![index].videoUrl}");
              Get.to(() => VlogFullViewScreen(
                vlogId: controller.trendingVlogModel.vlogs![index].id.toString(),
                videoUrl: '${controller.trendingVlogModel.vlogs![index].videoUrl}',
              ));
            },
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  height: 196.ah,
                  width: double.infinity,
                  child: Stack(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(
                            left: 15.0, right: 15, bottom: 15),
                        child: CustomImageView(
                          height: 196.ah,
                          width: double.infinity,
                          radius: BorderRadius.circular(15.adaptSize),
                          fit: BoxFit.cover,
                          // color: Colors.black,
                          imagePath: controller
                              .trendingVlogModel.vlogs?[index].thumbnailUrl,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            left: 15.0, right: 15, bottom: 15),
                        child: Container(
                          height: 196.ah,
                          width: double.infinity,
                          decoration: ShapeDecoration(
                            gradient: LinearGradient(
                              end: const Alignment(-0.45, 0.87),
                              begin: const Alignment(0.45, -0.87),
                              colors: [
                                Colors.black.withOpacity(.10),
                                Colors.black.withOpacity(.55),
                              ],
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15.adaptSize),
                            ),
                          ),
                        ),
                      ),
                      vlogInLocationRow(index),
                      Padding(
                        padding: EdgeInsets.only(
                            left: 15.0, right: 15, bottom: 15, top: 116.ah),
                        child: SizedBox(
                          height: 160.ah,
                          width: double.infinity,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(
                                  left: 15.0,
                                ),
                                child: Text(
                                  '${controller.trendingVlogModel.vlogs![index].title}'
                                      .capitalizeFirst!,
                                  style: TextStyle(
                                      color: const Color(0xffFFFFFF),
                                      fontWeight: FontWeight.w700,
                                      fontSize: 16.fSize,
                                      height: 1.5),
                                ),
                              ),
                              const SizedBox(
                                height: 5,
                              ),
                              Row(
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment:
                                    CrossAxisAlignment.center,
                                    children: [
                                      SizedBox(width: 10.ah),
                                      CustomImageView(
                                        height: 30.ah,
                                        width: 30.ah,
                                        imagePath: controller.trendingVlogModel
                                            .vlogs![index].user?.avatarUrl,
                                        radius: BorderRadius.circular(30.ah),
                                        fit: BoxFit.cover,
                                      ),
                                      SizedBox(
                                        width: 95,
                                        child: Text(
                                          "  ${'${controller.trendingVlogModel.vlogs![index].user?.fullName}  '.capitalizeFirst!}",
                                          overflow: TextOverflow.ellipsis,
                                          style: TextStyle(
                                            color: Color(0xffFFFFFF),
                                            fontWeight: FontWeight.w600,
                                            fontSize: 11.fSize,
                                          ),
                                        ),
                                      ),
                                      Text(
                                        '${controller.trendingVlogModel.vlogs![index].numberOfViews} views  ',
                                        style: TextStyle(
                                          color: Color(0xffFFFFFF),
                                          fontWeight: FontWeight.w600,
                                          fontSize: 11.fSize,
                                        ),
                                      ),
                                      Text(calculateTimeDifference(controller.trendingVlogModel.vlogs![index].createdAt!.toString()),
                                        style: TextStyle(
                                          color: const Color(0xffFFFFFF),
                                          fontWeight: FontWeight.w600,
                                          fontSize: 11.fSize,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const Spacer(),
                                  VlogLikeCommentsShareView(vlog: controller.trendingVlogModel.vlogs![index],),
                                  SizedBox(width: 15.0.aw)
                                ],
                              ),
                            ],
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget vlogInLocationRow(int index) {
    return Padding(
      padding: const EdgeInsets.only(left: 15.0, right: 15, bottom: 15),
      child: SizedBox(
        height: 40.ah,
        width: double.infinity,
        child: Row(
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 10.0),
              child: Image.asset(
                'assets/image/location-outline.png',
                width: 21.ah,
                height: 21.ah,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 10.0),
              child: Text(
                '${controller.trendingVlogModel.vlogs![index].user?.city}, ',
                style: TextStyle(
                  color: Color(0xffFFFFFF),
                  fontWeight: FontWeight.w600,
                  fontSize: 11.fSize,
                ),
              ),
            ),
            Text(
              '${controller.trendingVlogModel.vlogs![index].user?.country}',
              style: TextStyle(
                color: Color(0xffFFFFFF),
                fontWeight: FontWeight.w600,
                fontSize: 11.fSize,
              ),
            ),
            Spacer(),
            // Image.asset(
            //   'assets/image/more op.png',
            //   width: 22.aw,
            // ),
            SizedBox(
              width: 22.aw,
            ),
            SizedBox(
              width: 20,
            )
          ],
        ),
      ),
    );
  }

  Widget userLikeViewShare({
    required int index,
    required BuildContext contextttt,
  }) {
    DateTime currentDate = DateTime.now();
    DateTime createdAtDate = DateTime.parse(
        "${controller.trendingVlogModel.vlogs?[index].createdAt}");
    int differenceInDays = currentDate.difference(createdAtDate).inDays;
    return Padding(
      padding: EdgeInsets.only(left: 15.0, right: 15, bottom: 15, top: 116.ah),
      child: SizedBox(
        height: 160.ah,
        width: double.infinity,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(
                left: 15.0,
              ),
              child: Text(
                '${controller.trendingVlogModel.vlogs![index].title}'
                    .capitalizeFirst!,
                style: TextStyle(
                    color: const Color(0xffFFFFFF),
                    fontWeight: FontWeight.w700,
                    fontSize: 16.fSize,
                    height: 1.5),
              ),
            ),
            const SizedBox(
              height: 5,
            ),
            Row(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(width: 10.ah),
                    CustomImageView(
                      height: 30.ah,
                      width: 30.ah,
                      imagePath: controller
                          .trendingVlogModel.vlogs![index].user?.avatarUrl,
                      radius: BorderRadius.circular(30.ah),
                      fit: BoxFit.cover,
                    ),
                    Text(
                      "  ${'${controller.trendingVlogModel!.vlogs![index].user?.fullName}  '.capitalizeFirst!}",
                      style: TextStyle(
                        color: Color(0xffFFFFFF),
                        fontWeight: FontWeight.w600,
                        fontSize: 11.fSize,
                      ),
                    ),
                    Text(
                      '${controller.trendingVlogModel.vlogs![index].numberOfViews} views  ',
                      style: TextStyle(
                        color: const Color(0xffFFFFFF),
                        fontWeight: FontWeight.w600,
                        fontSize: 11.fSize,
                      ),
                    ),
                    Text(
                      '$differenceInDays days ago',
                      style: TextStyle(
                        color: const Color(0xffFFFFFF),
                        fontWeight: FontWeight.w600,
                        fontSize: 11.fSize,
                      ),
                    ),
                  ],
                ),
                const Spacer(),
                VlogLikeCommentsShareView(
                  vlog: controller.trendingVlogModel.vlogs![index],
                ),
                SizedBox(width: 15.0.aw)
              ],
            ),
          ],
        ),
      ),
    );
  }
}
