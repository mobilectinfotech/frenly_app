import 'package:flutter/cupertino.dart';
import 'package:frenly_app/data/repositories/api_repository.dart';
import 'package:get/get.dart';
import '../../data/models/GetCommentsModel.dart';
import 'TrendingVlogModel.dart';

class TrendingVlogController extends GetxController{

  RxDouble hight = 0.80.obs;


  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    getVlog();
  }
  late BuildContext context ;
  TrendingVlogModel trendingVlogModel=TrendingVlogModel();
  RxBool isLoading = false.obs;


  getVlog()async{
    isLoading.value=true;
    trendingVlogModel = await ApiRepository.getVlog();
    isLoading.value=false;

  }

  RxBool isLoadingONComments = false.obs;

  Rx<GetCommentsModel> getdata =GetCommentsModel().obs;
  GetCommentsModel get getCommentsModel => getdata.value;



  //GetCommentsModel getCommentsModel =GetCommentsModel();


  getComments({required String vlogId,bool ? isLoading})async{
    isLoadingONComments.value = isLoading ?? true;
    var response =  await ApiRepository.getCommentsOnVlog(vlogId: vlogId);
    getdata(response);
    getdata.refresh();

    isLoadingONComments.value=false;
  }

  TextEditingController commentController =TextEditingController();
  RxBool isLoadingONCommentsPost = false.obs;
  postCommnetOnVlog({required String vlogId})async{
    isLoadingONComments.value=true;
    bool isCommented =  await ApiRepository.postCommentOnVlog(vlogId: vlogId, comment: commentController.text);
    isLoadingONComments.value=false;
    if(isCommented){
      commentController.clear();
      getComments(vlogId: vlogId,isLoading: false);
    }
  }

  @override
  void onClose() {
    // TODO: implement onClose
    super.onClose();
    commentController.dispose();
  }



}
