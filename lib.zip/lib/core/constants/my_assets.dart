class MyStrings {
  MyStrings._();
  //SignUp PAGE
  static   String createYourAccount = 'Create Your \nAccount';
  static   String fullName = 'Full Name';
  static   String userName = 'Username';
  static   String email    = 'Email';
  static   String passWord = 'Password';
  static   String reEnterPassword = 'Re-Enter Password';
  static   String alreadyHavePassword = 'Already know password ?';
  static   String signUp = 'Sign Up';
  static   String loginA = 'Login';
  static   String userNameNotBeEmpty = 'username not be empty';
  static   String usernameAlreadyRegistered = 'username Already Registered';
  static   String PleaseEnterYourConfirmPassword = 'Please enter your confirm password';
  static   String alreadyHaveAccount = 'Already have account?';
  static   String passwordsDoNotMatch = 'Passwords do not match';

  //Login Page
  static   String dontHaveAccount = "Don't have account";
  static   String helloLoginToContinue = 'Hello, \nLogin to continue';
  static   String forgetPassword = 'Forgot Password?';

  //Forget Password
  static   String forgettPassword = 'Forgot\nPassword?';
  static   String continuee = 'Continue';

  //Create New password
  static   String creatNewPassword = 'Create New\nPassword !';
  static   String reSetPassword = 'Reset Password';

  //Home Page
  static   String forYou = 'For You';
  static   String checkIn = 'Check-in';
  static   String live = 'Live';
  static   String viewAll = 'View All';
  static   String trending = 'Trending';
  static   String popularBlogs = 'Popular Blogs';
  static   String discover = 'Discover';
  static   String posts = 'Posts';
  static   String activeFriends = 'Active Friends';
  static   String follow = 'Follow';
  static   String unFollow = 'Unfollow';

  //Search Screen
  static   String blog = 'Blog';
  static   String vlog = 'Vlog';
  static   String photo = 'Photo';
  static   String profiles = 'Profiles';

  //Photo Post Screen
  static   String  photoPost = 'Photo Post';
  static   String  caption = 'Caption';
  static   String  post = 'Post';

  //Video Post Screen
  static   String videoPost = 'Video Post';
  static   String title = 'Title';
  static   String camera = 'Camera';
  static   String gallery = 'Gallery';
  static   String  description = 'Description';

  //Create Blog Screen
  static   String  createBlog = 'Create Blog';
  static   String  body = 'Body';
  static   String  titles = 'Title';
  static   String  tags = 'Tags';

  // Message Screen
  static   String messages = 'Messages';

  //My Profile Screen
  static   String editProfile = 'Edit Profile';
  static   String blogs = 'Blogs';
  static   String vlogs = 'Vlogs';
  static   String photos = 'Photos';
  static   String follower = 'Follower';
  static   String followers = 'Followers';
  static   String following = 'following';
  static   String followings = 'followings';

  //Setting Screen
  static   String settings = 'Settings';
  static   String lastSeen = 'Last Seen';
  static   String commentsOnPost = 'Comments on Post';
  static   String account = 'Account';
  static   String savedItems = 'Saved Items';
  static   String blockedList = 'Blocked List';
  static   String language = 'Language';
  static   String chooseYourLanguage = 'Choose Your Language';
  static   String english = 'English';
  static   String swedish = 'Swedish';
  static   String deleteAccount = 'Delete Account';
  static   String allCategory = 'All Categories ';
  static   String notifications = 'Notifications';
  static   String chatNotification = 'Chat notification';
  static   String feedNotification = 'Feed notification';
  static   String save = 'Save';
  static   String contacts = 'Contacts';
  static   String logout = 'Logout';

  //Fashion Screen
  static   String fashion = 'Fashion';

  //PopulaCity Screen
  static   String popular = 'Popular';
  static   String allCity = 'All City';
  static   String actives = 'Actives';

  // Treading Vlog Screen
  static   String treadingVlog = 'Trending Vlog';

  // Popular Blog Screen
  static   String popularBlog = 'Popular Blog';

  //Discover Screen
  static   String profile = 'Profile';

  //Edit Profile Screen
  static   String bio = 'Bio';
  static   String handleisunique  = 'handle is unique';







  //////////////////jnbnfgbni///////////////////////////////
  static   String loginWith = 'Log with';
  static   String letme = 'Let me show some \nwhite vibes of the london';
  static   String Find = 'Find Friends & Get Inspiration';
  static   String Loream = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Erat vitae quis quam augue quam a.';
  static   String Meet = 'Meet Awesome People & Enjoy yourself';
  static   String Hangout = 'Hangout with with Friends';
  static   String Sign = 'Create Your Account';

  static   String Places = 'Places';

  static   String Circle  = 'Circular Quay port are hubs of waterside life, \nwith the arched Harbour Bridge';
  static   String MyNamePro = 'My name is Brett Pit and I enjoy meeting new \nMovies role into new';

  static   String Follower = 'Follower';
  static   String Following = 'Following';
  static   String Profilephoto = 'Profile Photo';
  static   String Cook = 'Cooking';

  static   String Uses = 'Ues that good for you can try and';
  static   String iam = 'I am here just near u';

  static   String Hand = 'Handle';

  static   String  drinkmilkshake = 'How to drink milkshake';
  static   String  ThisisDescrip = 'This is the description of new video. My name is Jessica Parker and I enjoy meeting new people';
  static   String  Location = 'Location';
  static   String  Upload = 'Upload';

  static   String  Share = 'Share';
  static   String  Block = 'Block this user';
  static   String  Delete = 'Delete';
  static   String  Clearchat = 'Body';
  static   String  Deletecht = 'Delete Chat';
  static   String  Fashion = 'Fashion';

  static   String  NewCategory = 'New Category';
  static   String  Food = 'Food';
  static   String  Tech = 'Tech';
  static   String  Science = 'Science';
  static   String  Game = 'Game';
  static   String  Finance = 'Finance';
  static   String  Comedy = 'Comedey';
  static   String  Song = 'Songs';
  static   String  Holloywood = 'Holloywood';
  static   String  Humor = 'Humor';
  static   String  Asian = 'Asian';
  static   String  Code = 'Code';
  static   String  Apps = 'Apps';
  static   String  Uiux = 'UI/UX';
  static   String  Nature = 'Nature';
  static   String  Sowe = 'So when user signups he will be added to his own age group, where he can enter the time of his race which will be compared to other users of same group and will be showing a list of top 100 users on the chart.';
  static   String  Result = 'Result For';
  static   String  Addnew = 'Add New Category';
  static   String  Editblog = 'Edit blog';
}
