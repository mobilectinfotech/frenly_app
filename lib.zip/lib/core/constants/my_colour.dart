import 'dart:ui';

import 'package:flutter/material.dart';

 abstract class MyColor{
  MyColor._();

  static const primaryColor = Color(0xff001649);
  static const secoundryColor = Colors.green;


}