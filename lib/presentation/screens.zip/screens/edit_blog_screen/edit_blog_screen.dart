import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:frenly_file/presentation/screens/postfull_view/postfull_view_screen.dart';
import 'package:frenly_file/core/utils/size_utils.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:get/get.dart';
import '../../../core/constants/my_textfield.dart';
import '../create_blog_screen/create_blog.dart';

class EditBlog_Screen extends StatefulWidget {
  const EditBlog_Screen({super.key});

  @override
  State<EditBlog_Screen> createState() => _EditBlog_ScreenState();
}

class _EditBlog_ScreenState extends State<EditBlog_Screen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        title: Text('Editblog'.tr,
          style: TextStyle(
            color: Colors.black,fontWeight: FontWeight.w600,fontSize:20.fSize,
          ),),
        leading: Padding(
          padding:  EdgeInsets.only(left: 35.h),
          child: InkWell(
              onTap: () {
                Navigator.pop(context);
              },
              child: Icon(Icons.arrow_back_sharp)),
        ),
        backgroundColor: Colors.white,
        shadowColor: Colors.white,
        surfaceTintColor: Colors.white,

        elevation:3,
      ),

      body: Padding(
        padding: const EdgeInsets.only(left:20,right:20,top: 20),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Stack(
                alignment: Alignment.bottomRight,
                children: [
                  Container(
                    height: 185.ah,width: MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(25),
                      // color: Colors.grey,
                      image: DecorationImage(
                        // alignment: Alignment.center,
                          fit: BoxFit.fill,
                          image: AssetImage('assets/image/Frame 21150 (3).png')
                      ),),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Image.asset('assets/image/edit.png',height: 38.ah,width: 38.aw,fit: BoxFit.fill,),
                  ),],),
          
              SizedBox(height: 20.ah),
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: Text('Title'.tr,
                  style: TextStyle(
                      color: Colors.black,fontWeight: FontWeight.w700,fontSize: 15.fSize
                  ),),
              ),
          
              SizedBox(height: 10.ah,),
              primaryTextfield2(
                  hintText: 'lect'.tr,
                  controller: null),

              SizedBox(height: 20.ah),
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: Text('Body'.tr,
                  style: TextStyle(
                      color: Colors.black,fontWeight: FontWeight.w700,fontSize: 15.fSize
                  ),),
              ),
          
              SizedBox(height: 10.ah,),
              primaryTextfield6(
                  hintText: 'Sowe'.tr,
                  controller: null),

              SizedBox(height: 20.ah),
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: Text('Tagg'.tr,
                  style: TextStyle(
                      color: Colors.black,fontWeight: FontWeight.w700,fontSize: 15.fSize
                  ),),
              ),

              SizedBox(height: 10.ah),
              Container(
                height: 40.ah,width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.grey,width: 1)
                ),
                child:  Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Container(
                      height: 20.ah,width: 65.aw,
                      decoration: BoxDecoration(
                          border: Border.all(
                              color: Colors.black,
                              width: 0.3
                          ),
                          borderRadius: BorderRadius.circular(5),
                          color: Colors.grey.shade200
                      ),
                      child:  Center(
                        child: Text('Cooking'.tr,
                          style: TextStyle(
                              color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize
                          ),
                        ),
                      ),
                    ),
                    SizedBox(width: 10.aw),
                    Container(
                      height: 20.ah,width: 60.aw,
                      decoration: BoxDecoration(
                          border: Border.all(
                              color: Colors.black,
                              width: 0.3
                          ),
                          borderRadius: BorderRadius.circular(5),
                          color: Colors.grey.shade200
                      ),
                      child:  Center(
                        child: Text('Vlogs'.tr,
                          style: TextStyle(
                              color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize
                          ),
                        ),
                      ),
                    ),
                    SizedBox(width: 10.aw),
                    Container(
                      height: 20.ah,width: 60.aw,
                      decoration: BoxDecoration(
                          border: Border.all(
                              color: Colors.black,
                              width: 0.3
                          ),
                          borderRadius: BorderRadius.circular(5),
                          color: Colors.grey.shade200
                      ),
                      child:  Center(
                        child: Text('Nature'.tr,
                          style: TextStyle(
                              color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              SizedBox(height: 20.ah),
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: Text('Location'.tr,
                  style: TextStyle(
                      color: Colors.black,fontWeight: FontWeight.w700,fontSize: 15.fSize
                  ),),
              ),

              SizedBox(height: 10.ah),
              Container(
                height: 40.ah,width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.grey,width: 1)
                ),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text('New York, USA',
                    style: TextStyle(
                        color: Colors.black,fontWeight: FontWeight.w700,fontSize: 15.fSize
                    ),),
                ),
              ),

              SizedBox(height: 30.ah),
              Center(
                child: CustomPrimaryBtn1(
                  title: 'Upload'.tr,
                  isLoading: false,
                  onTap: () {
                  //  Navigator.push(context, MaterialPageRoute(builder: (context) => BlogsFullViewScreen()));
                  },
                ),
              ),
              Padding(padding: EdgeInsets.symmetric(vertical: MediaQuery.of(context).viewInsets.bottom),),

              SizedBox(height: 20.ah),
            ],
          ),
        ),
      ),
    );
  }
}
