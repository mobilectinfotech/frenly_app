import 'dart:convert';
import 'package:get/get.dart';
import 'package:dio/dio.dart';
import 'freinds_model.dart';



class FriendsController extends GetxController{

 RxBool isLoading = false.obs;
 FriendsModel friendsModel = FriendsModel();


 @override
 void onInit() {
  // TODO: implement onInit
  super.onInit();
  friendFunction();
 }

 Future<void>friendFunction() async {
  isLoading(true);
  var data = {};
  //var token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjYsImVtYWlsIjoiZ3JlZW5zMUBtYWlsaW5hdG9yLmNvbSIsImlhdCI6MTcxMjA0MDg5MywiZXhwIjoxNzEyMzAwMDkzfQ.e1MjiVbliK9akjmxFhKrJsz3cipoR_NsK8nK-6loqAI';
  var headers = {
   'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjYsImVtYWlsIjoiZ3JlZW5zMUBtYWlsaW5hdG9yLmNvbSIsImlhdCI6MTcxMjA0MDg5MywiZXhwIjoxNzEyMzAwMDkzfQ.e1MjiVbliK9akjmxFhKrJsz3cipoR_NsK8nK-6loqAI'
  };

  var dio = Dio();
  var response = await dio.request(
   'http://192.168.1.35:3001/home/friends',
   options: Options(
    method: 'GET',
    headers: headers,
   ),
   data: data,
  );

  if (response.statusCode == 200) {
   friendsModel =FriendsModel.fromJson(response.data);
   isLoading(false);
   print(json.encode(response.data));

  }
  else {
   print(response.statusMessage);
  }
 }

 }