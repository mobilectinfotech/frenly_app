import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:frenly_file/presentation/screens/aap/apmodel.dart';
import 'package:http/http.dart' as http;
import 'package:dio/dio.dart';

/*
class MACScreen extends StatefulWidget {
  const MACScreen({super.key});

  @override
  State<MACScreen> createState() => _MACScreenState();
}

class _MACScreenState extends State<MACScreen> {
List<ApScreen_Model> apscreen_model =[];

 Future<List<ApScreen_Model>> GetModeldata()async{
   final response = await http.get(Uri.parse('http://18.233.72.175:4000/Get_all_product'));
   print('hj');
   var data = response.body;
   print(data);
   print('sdfghhj');
   if (response.statusCode == 200) {
     return apscreen_model;
   } else {
     throw Exception('Unable to fetch products from the REST API');
   }
 }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: FutureBuilder(
          future: GetModeldata(),
          builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
            if(snapshot.hasData){
              return ListView.builder(
                itemCount: apscreen_model.length,
                itemBuilder: (BuildContext context, int index) {
                  return Expanded(
                    child: Container(
                        color: Colors.grey,
                        height: 250,
                        width: 250,
                        child: Center(
                            child: Column(
                              children: [
                                Text(apscreen_model[index].productInfo!.first.productName.toString()),
                                Text(apscreen_model[index].productInfo!.first.description.toString()),
                              ],
                            )
                        )
                    ),
                  );
                },

              );
            }
           else{
             return Text('No Data');
            }

          },

        ),
      ),
    );
  }
}
*/


class GreenFk extends StatefulWidget {
  const GreenFk({super.key});

  @override
  State<GreenFk> createState() => _GreenFkState();
}

class _GreenFkState extends State<GreenFk> {

  var headers = {
    'Content-Type': 'application/x-www-form-urlencoded'
  };

  //List<ApScreen_Model>? apscreen_model = [];
  List<GreenFamily>? greenfamily = [];

     var data = {
    'family_id': '1'
  };

  Future<dynamic> Gettadata() async {
    print('1asdfgvbn');
    var dio = Dio();

    print('2sdfghbn');

    var response = await dio.request(
      'http://3.104.197.136:4000/user/getFamilyMembers',
      options: Options(
        method: 'GET',
        headers: headers,),

      data: data,);
   // print(data);
    //data[''][''];
   // return resp['slip']['advice'];

    //print(data ['$data'] );

    print('34567uio');
    if (response.statusCode == 200) {
      print(json.encode(response.data));
    }
    else {
      print(response.statusMessage);
    }
  }

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      body: Center(
        child: FutureBuilder(
          future: Gettadata(),
          builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
            if(snapshot.hasData){
              return ListView.builder(
                itemCount: greenfamily!.length,
                itemBuilder: (BuildContext context, int index) {
                  return Container(
                      color: Colors.grey,
                      height: 250,
                      width: 250,
                      child: Center(
                          child: Column(
                            children: [
                               Text(greenfamily![index].familyDetails.first.userName.toString()),
                               Text(greenfamily![index].familyDetails.first.userName.toString()),

                             // Text(greenfamily[index].familyDetails.first.),
                          //Text(apscreen_model![index].productInfo!.first.productName!.length.toString()),
                              // Text(apscreen_model[index].productInfo!.first.productName.toString()),
                              // Text(apscreen_model[index].productInfo!.first.description.toString()),
                             // Image.asset('${apscreen_model![index].productInfo!.first.productImage!.length}')

                            ],
                          )
                      )
                  );
                },
              );
            }
            else{
              return Text('No fghData');
            }

          },

        ),
      ),
    );
  }
}


class Heartscreen extends StatefulWidget {
  const Heartscreen({super.key});

  @override
  State<Heartscreen> createState() => _HeartscreenState();
}

class _HeartscreenState extends State<Heartscreen> {
  bool isheart=false;

  bool _liked = false;

  void _toggleLike() {
    setState(() {
      _liked = !_liked;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

      ),
      body: Center(child:
      Container(
        height: 150,
        width: 200,
        color: Colors.green,
        child: GestureDetector(
          onTap: _toggleLike,
          child: _liked
              ? Icon(
            Icons.favorite,
            size: 100,
            color: Colors.red,
          )
              : Icon(
            Icons.favorite_border,
            size: 100,
            color: Colors.grey,
          ),
        ),
        /*IconButton(
          onPressed: () {
            setState(() {
              isheart= !isheart;
            });
          },
          icon:
          isheart?Image.asset('assets/image/fillheart.png', width: 21.aw, height: 21.ah,):
          Image.asset('assets/image/like.png', width: 21.aw, height: 21.ah),

        ),*/


      )
      ),
    );
  }
}
