import 'dart:convert';


class ApScreen_Model {
  int? status;
  bool? success;
  String? message;
  List<ProductInfo>? productInfo;

  ApScreen_Model({this.status, this.success, this.message, this.productInfo});

  ApScreen_Model.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    success = json['success'];
    message = json['message'];
    if (json['product_info'] != null) {
      productInfo = <ProductInfo>[];
      json['product_info'].forEach((v) {
        productInfo!.add(new ProductInfo.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['success'] = this.success;
    data['message'] = this.message;
    if (this.productInfo != null) {
      data['product_info'] = this.productInfo!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class ProductInfo {
  String? productName;
  String? productImage;
  String? description;

  ProductInfo({this.productName, this.productImage, this.description});

  ProductInfo.fromJson(Map<String, dynamic> json) {
    productName = json['product_name'];
    productImage = json['product_image'];
    description = json['description'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['product_name'] = this.productName;
    data['product_image'] = this.productImage;
    data['description'] = this.description;
    return data;
  }
}

// To parse this JSON data, do
//
//     final greenFamily = greenFamilyFromJson(jsonString);


GreenFamily greenFamilyFromJson(String str) => GreenFamily.fromJson(json.decode(str));

String greenFamilyToJson(GreenFamily data) => json.encode(data.toJson());

class GreenFamily {
  int status;
  String message;
  bool success;
  List<FamilyDetail> familyDetails;

  GreenFamily({
    required this.status,
    required this.message,
    required this.success,
    required this.familyDetails,
  });

  factory GreenFamily.fromJson(Map<String, dynamic> json) => GreenFamily(
    status: json["status"],
    message: json["message"],
    success: json["success"],
    familyDetails: List<FamilyDetail>.from(json["familyDetails"].map((x) => FamilyDetail.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "success": success,
    "familyDetails": List<dynamic>.from(familyDetails.map((x) => x.toJson())),
  };
}

class FamilyDetail {
  int id;
  int familyId;
  String userName;
  int levelAtTree;
  String firstName;
  String lastName;
  String gender;
  String imageLink;
  String maritalStatus;
  String hasChild;
  DateTime createdAt;
  DateTime updatedAt;

  FamilyDetail({
    required this.id,
    required this.familyId,
    required this.userName,
    required this.levelAtTree,
    required this.firstName,
    required this.lastName,
    required this.gender,
    required this.imageLink,
    required this.maritalStatus,
    required this.hasChild,
    required this.createdAt,
    required this.updatedAt,
  });

  factory FamilyDetail.fromJson(Map<String, dynamic> json) => FamilyDetail(
    id: json["id"],
    familyId: json["family_id"],
    userName: json["user_name"],
    levelAtTree: json["level_at_tree"],
    firstName: json["first_name"],
    lastName: json["last_name"],
    gender: json["gender"],
    imageLink: json["image_link"],
    maritalStatus: json["marital_status"],
    hasChild: json["has_child"],
    createdAt: DateTime.parse(json["created_at"]),
    updatedAt: DateTime.parse(json["updated_at"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "family_id": familyId,
    "user_name": userName,
    "level_at_tree": levelAtTree,
    "first_name": firstName,
    "last_name": lastName,
    "gender": gender,
    "image_link": imageLink,
    "marital_status": maritalStatus,
    "has_child": hasChild,
    "created_at": createdAt.toIso8601String(),
    "updated_at": updatedAt.toIso8601String(),
  };
}

