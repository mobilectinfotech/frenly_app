import 'package:flutter/material.dart';

class Search_tabs extends StatefulWidget {
  const Search_tabs({super.key});

  @override
  State<Search_tabs> createState() => _Search_tabsState();
}

class _Search_tabsState extends State<Search_tabs> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
