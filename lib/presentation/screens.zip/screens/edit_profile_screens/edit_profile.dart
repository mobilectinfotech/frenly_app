import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:frenly_file/presentation/screens/edit_profile_screens/controller/editprofile_controller.dart';
import 'package:frenly_file/presentation/screens/signup_screen/signup_screen.dart';
import 'package:frenly_file/core/utils/size_utils.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:get/get.dart';
import 'package:image_cropper_platform_interface/src/models/cropped_file/unsupported.dart';
import '../../../core/constants/my_textfield.dart';
import '../settings_screen/setting_screen.dart';

import 'package:image_picker/image_picker.dart';

class Edit_Profile extends StatefulWidget {
  const Edit_Profile({super.key});

  @override
  State<Edit_Profile> createState() => _Edit_ProfileState();
}

class _Edit_ProfileState extends State<Edit_Profile> {
  // File? image1 ;
  //
  //  Future<void> _pickImageFromGallery() async {
  //    final picker = ImagePicker();
  //    final pickedImage = await picker.pickImage(source: ImageSource.gallery);
  //
  //    if (pickedImage != null) {
  //      print('Image picked from gallery: ${pickedImage.path}');
  //    }
  //  }
  //
  //  Future<void> _pickImageFromCamera() async {
  //    final picker = ImagePicker();
  //    final pickedImage = await picker.pickImage(source: ImageSource.camera);
  //
  //    if (pickedImage != null) {
  //      print('Image picked from camera: ${pickedImage.path}');
  //    }
  //  }
  //
  //  final _picker = ImagePicker();
  //
  //  Future getImage()async{
  //    final pickedFile = await _picker.pickImage(source: ImageSource.gallery , imageQuality: 80);
  //
  //    if(pickedFile!= null ){
  //      image1 = File(pickedFile.path);
  //      setState(() {
  //
  //      });
  //    }else {
  //      print(' no image selected');
  //    }
  //  }

  // EditProfileController editProfileController = Get.put(EditProfileController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // backgroundColor: Colors.grey,
      body: SingleChildScrollView(
        child: Column(
          children: [
            Stack(
              children: [
                Padding(
                  padding: EdgeInsets.only(left: 15.h, right: 15.h, top: 245.v),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            height: 45.ah,
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 10.h),
                            child: Text(
                              'fullnm'.tr,
                              style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 15.fSize),
                            ),
                          ),
                          SizedBox(
                            height: 10.ah,
                          ),
                          primaryTextfield2(
                              hintText: 'John Smith', controller: null),
                          SizedBox(
                            height: 10.ah,
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 10.h),
                            child: Text(
                              'emailn'.tr,
                              style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 15.fSize),
                            ),
                          ),
                          SizedBox(
                            height: 10.ah,
                          ),
                          primaryTextfield2(
                              hintText: 'john.smith@gmail.com',
                              controller: null),
                          SizedBox(
                            height: 15.ah,
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 10.h),
                            child: Text(
                              'Bio'.tr,
                              style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 15.fSize),
                            ),
                          ),
                          SizedBox(
                            height: 10.ah,
                          ),
                          primaryTextfield3(
                              hintText: 'MyNamePro'.tr, controller: null),
                          SizedBox(
                            height: 15.ah,
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 10.h),
                            child: Text(
                              'Hand'.tr,
                              style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 15.fSize),
                            ),
                          ),
                          SizedBox(
                            height: 10.ah,
                          ),
                          primaryTextfield2(
                              hintText: 'jessie5204', controller: null),
                          SizedBox(
                            height: 10.ah,
                          ),
                          Container(
                            height: 24.ah,
                            width: 131.aw,
                            decoration: BoxDecoration(
                              color: Color(0xFFF7F7F7),
                              borderRadius: BorderRadius.circular(25),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Image.asset(
                                  'assets/image/Accept.png',
                                  height: 14.ah,
                                  width: 14.aw,
                                  fit: BoxFit.fill,
                                ),
                                Text(
                                  'Handlle'.tr,
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontFamily: 'Roboto',
                                      fontWeight: FontWeight.w400,
                                      fontSize: 12.fSize),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 30.ah,
                          ),
                          Center(
                            child: CustomPrimaryBtn1(
                              title: 'Saveid'.tr,
                              isLoading: false,
                              onTap: () {
                                // Navigator.push(context, MaterialPageRoute(builder: (context) => SignUp_Screen()));
                              },
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Container(
                  height: MediaQuery.of(context).size.width,
                  width: MediaQuery.of(context).size.width,
                ),
                Container(
                  width: MediaQuery.of(context).size.width,
                  height: 229.ah,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                        bottomRight: Radius.circular(25),
                        bottomLeft: Radius.circular(25)),
                    image: DecorationImage(
                      image: AssetImage('assets/image/Frame 21141.png'),
                      fit: BoxFit.fill,
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(right: 20.h, top: 35.v),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          InkWell(
                              onTap: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            Setting_Screen()));
                              },
                              child: Image.asset(
                                'assets/image/ic_settings_24px.png',
                                height: 50.ah,
                                width: 50.aw,
                                color: Colors.white,
                              )),
                        ],
                      ),
                      SizedBox(
                        height: 120.ah,
                      ),
                      InkWell(
                          onTap: () {
                            /*showModalBottomSheet(
                                context: context,
                                backgroundColor: Colors.white,
                                builder: (context) {
                                  return Column(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      SizedBox(height: 15.ah),
                                      ListTile(
                                        leading: Icon(Icons.camera_alt_outlined),
                                        title: Text('Camera'.tr,
                                          style: TextStyle(
                                              color: Colors.black,fontWeight: FontWeight.w600,fontSize:16
                                          ),),
                                        onTap: () {
                                          _pickImageFromCamera();
                                        },
                                      ),

                                      ListTile(
                                        leading:  Icon(Icons.browse_gallery_outlined),
                                        title: Text('Gallery'.tr,
                                          style: TextStyle(
                                              color: Colors.black,fontWeight: FontWeight.w600,fontSize:16
                                          ),),
                                        onTap: () {
                                          _pickImageFromGallery();
                                        },
                                      ),
                                    ],
                                  );
                                }
                            );*/
                            //editProfileController.showPicker(context);
                            //getImage();
                          },
                          child: Image.asset(
                            'assets/image/edit.png',
                            height: 38.ah,
                            width: 38.aw,
                            fit: BoxFit.contain,
                          ))
                    ],
                  ),
                ),
                Positioned(
                    top: 135.ah,
                    left: 120.aw,
                    child: Center(
                        child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Container(
                            width: 148.aw,
                            height: 148.ah,
                            //color: Colors.redAccent,
                            decoration: ShapeDecoration(
                              color: Colors.white,
                              shape: CircleBorder(),
                            )),
                        Container(
                            width: 140.aw,
                            height: 140.ah,
                            decoration: ShapeDecoration(
                              color: Colors.grey,
                              shape: CircleBorder(),
                              image: DecorationImage(
                                  fit: BoxFit.cover,
                                  image:
                                      //NetworkImage("${firestore.currentUser!.photoURL}"),
                                      AssetImage(
                                          'assets/image/nick-andreka-XJWm6jERxcc-unsplash.jpg')),
                            )),
                        Positioned(
                            right: 10,
                            top: 85,
                            child: Image.asset(
                              'assets/image/edit.png',
                              height: 38.ah,
                              width: 38.aw,
                              fit: BoxFit.contain,
                            )),
                      ],
                    )

                        /*Stack(
                        children: [
                          Container(
                            decoration: BoxDecoration(
                                color: Colors.grey,
                                //borderRadius: BorderRadius.circular(50)
                                shape: BoxShape.circle
                            ),
                            height: 148.ah,width:148.aw,
                            child:
                            image1 == null ?
                            Center(child: Text('Pick Image'),)
                                :
                            Container(
                              child: Center(
                                child: Image.file(File(image1!.path).absolute,
                                  height: 100, width: 100, fit: BoxFit.cover,
                                ),
                              )
                            ),
                          ),

                          Positioned(
                            right: 10,top:85,
                              child: InkWell(
                                  onTap: () {

                                    */

                        /*showModalBottomSheet(
                                        context: context,
                                        backgroundColor: Colors.white,
                                        builder: (context) {
                                          return Column(
                                            mainAxisSize: MainAxisSize.min,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children: <Widget>[
                                              SizedBox(height: 15.ah),
                                              ListTile(
                                                leading: Icon(Icons.camera_alt_outlined),
                                                title: Text('Camera'.tr,
                                                  style: TextStyle(
                                                      color: Colors.black,fontWeight: FontWeight.w600,fontSize:16
                                                  ),),
                                                onTap: () {
                                                  _pickImageFromCamera();
                                                },
                                              ),

                                              ListTile(
                                                leading:  Icon(Icons.browse_gallery_outlined),
                                                title: Text('Gallery'.tr,
                                                  style: TextStyle(
                                                      color: Colors.black,fontWeight: FontWeight.w600,fontSize:16
                                                  ),),
                                                onTap: () {
                                                  _pickImageFromGallery();
                                                },
                                              ),
                                            ],
                                          );
                                        }
                                    );*/

                        /*

                                   // editProfileController.showPicker(context);
                                    getImage();
                                  },
                                  child: Image.asset('assets/image/edit.png',height:38.ah,width: 38.aw,fit: BoxFit.contain,))),

                        ],

                      ),*/
                        )),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
