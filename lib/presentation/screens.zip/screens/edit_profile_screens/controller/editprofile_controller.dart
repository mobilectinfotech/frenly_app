// import 'dart:convert';
// import 'package:flutter/cupertino.dart';
// import 'package:dio/dio.dart';
// import 'package:frenly_file/presentation/screens/edit_profile_screens/edit_profile_screen.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:get/get_rx/src/rx_types/rx_types.dart';
// import 'package:get/get_state_manager/src/simple/get_controllers.dart';
// import 'package:flutter/material.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:image_picker/image_picker.dart';
// import 'package:image_cropper/image_cropper.dart';
//
// class EditProfileController extends GetxController {
//
//   TextEditingController fulnameController = TextEditingController();
//   TextEditingController EemailController = TextEditingController();
//   TextEditingController bioController = TextEditingController();
//   TextEditingController handleController = TextEditingController();
//
//   RxBool isLoadig = false.obs;
//
//   Rx<String>  profiePic  = "assets/images/image_not_found.png".obs;
//
//   @override
//   void onReady() {
//     // TODO: implement onReady
//     super.onReady();
//   }
//
//   @override
//   void onInit() {
//     // TODO: implement onInit
//     super.onInit();
//     EditProfilefunction();
//   }
//
//   @override
//   void onClose() {
//     super.onClose();
//     fulnameController.dispose();
//     EemailController.dispose();
//     bioController.dispose();
//     handleController.dispose();
//   }
//
//
//   Rx<String>  profiePicc = "assets/images/image_not_found.png".obs;
//
//
//
//   final ImagePicker _picker = ImagePicker();
//
//   Future<void> imagePicker({required ImageSource source}) async {
//     final XFile? pickedFile = await _picker.pickImage(source: source);
//     CroppedFile ? croppedFile = await ImageCropper().cropImage(
//       sourcePath: pickedFile!.path,
//       aspectRatioPresets: [
//         CropAspectRatioPreset.square,
//       ],
//       maxWidth: 600,
//       maxHeight: 600,
//     );
//     if (croppedFile != null) {
//       profiePicc.value = croppedFile.path;
//       print("object${croppedFile.path}");
//       print("object${profiePicc.value}");
//     //  Edit_Profile(croppedFile);
//
//     }
//   }
//
//   void showPicker(context) {
//     showModalBottomSheet(
//         context: context,
//         builder: (BuildContext bc) {
//           return SafeArea(
//             child: Container(
//               color: Colors.white,
//               child: Wrap(
//                 children: <Widget>[
//
//                   ListTile(
//                       leading: const Icon(Icons.photo_library),
//                       title: const Text('Gallery '),
//                       onTap: () {
//                         imagePicker(source: ImageSource.gallery);
//                         Navigator.of(context).pop();
//                       }),
//
//                   ListTile(
//                     leading: const Icon(Icons.video_camera_back_rounded),
//                     title: const Text('Camera'),
//                     onTap: () {
//                       imagePicker(source: ImageSource.camera);
//                       Navigator.of(context).pop();
//                     },
//                   ),
//
//                 ],
//               ),
//             ),
//           );
//         });
//   }
//
//
//   Future<void> EditProfilefunction() async {
//     isLoadig(true);
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     var headers = {
//       'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsImVtYWlsIjoieWFzaHJhanNpbmdobWFuZGxvaUBnbWFpbC5jb20iLCJpYXQiOjE3MTAzMzA5MjMsImV4cCI6MTcxMDU5MDEyM30.D4zTRRYFc3YXXJ15qZv_S0eBmY5edrHCoGDF_Zd_QzU'
//     };
//
//     var data = {
//       'full_name': '${fulnameController.text.trim()}',
//          'email': '${EemailController.text.trim()}',
//          'bio': '${bioController.text.trim()}',
//         'handle': '${handleController.text.trim()}'
//     };
//
//     //var formData = FormData.fromMap({'profile': [await MultipartFile.fromFile(file.path, ),],});
//
//     var data2 = FormData.fromMap({
//       'files': [
//         await MultipartFile.fromFile('',
//             filename: 'MAGGI-2-MINN-Mas-96x70g-Recipes-IN.jpg')
//       ],
//       'full_name': 'yashraj mandloi',
//       'email': 'yashraj1@mailinator.com',
//       'bio': 'I am working now ',
//       'handle': 'username123'
//     });
//
//     var dio = Dio();
//     var response = await dio.request(
//       'http://localhost:3001/editProfile',
//       options: Options(
//         method: 'POST',
//         headers: headers,
//       ),
//       data: data2,
//     );
//
//     if (response.statusCode == 200) {
//       print(json.encode(response.data));
//     }
//     else {
//       print(response.statusMessage);
//     }
//
//   }
//
// }
//
//
//
