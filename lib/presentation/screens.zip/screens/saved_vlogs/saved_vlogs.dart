import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:frenly_file/presentation/screens/saved_blog/saved_blog.dart';
import 'package:frenly_file/presentation/screens/saved_people_profile/saved_people_profile.dart';
import 'package:frenly_file/presentation/screens/saved_photo/saved_photo.dart';
import 'package:frenly_file/presentation/screens/savedd_vlog_tab/saved_vlog_tab.dart';
import 'package:frenly_file/core/utils/size_utils.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:get/get.dart';

class Save_Vlogs_Screen extends StatefulWidget {
  const Save_Vlogs_Screen({super.key});

  @override
  State<Save_Vlogs_Screen> createState() => _Save_Vlogs_ScreenState();
}

class _Save_Vlogs_ScreenState extends State<Save_Vlogs_Screen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        surfaceTintColor: Colors.white,
        backgroundColor: Colors.white,
        title: Row(
          children: [
            Text('Fashion'.tr,
              style: TextStyle(
                  color: Colors.black,fontWeight: FontWeight.w700,fontSize:32.fSize
              ),
            ),
          ],
        ),
        leading: Padding(
          padding:  EdgeInsets.only(left: 15.h),
          child: InkWell(
              onTap: () {
                Navigator.pop(context);
              },
              child: Icon(Icons.arrow_back_sharp)),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: InkWell(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => Saved_Tab_bar()));
              },
              child: Container(
                height: 36.ah,
                width: 36.aw,
                decoration: BoxDecoration(
                  // borderRadius: BorderRadius.all(Radius.circular(35)),
                    color: Color(0x305B5B5B),
                    shape: BoxShape.circle,
                    image: DecorationImage(
                      fit: BoxFit.fill,
                      image: AssetImage('assets/image/Ellipse 1.png'),
                    )),
                // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
              ),
            ),
          ),
        ],
      ),

      body: Padding(
        padding: const EdgeInsets.only(left: 10,right: 10,top:20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              height: 52.ah,width: 358.aw,
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10)
              ),
              child: Padding(
                padding: const EdgeInsets.all(4.0),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      height: 40.ah,width:83.aw,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                         color: HexColor('#001649')
                      ),
                      child:  Center(
                        child: Text('Vlogs'.tr,
                          style: TextStyle(
                              color: Colors.white,fontWeight: FontWeight.w600,fontSize:18.fSize
                          ),
                        ),
                      ),
                    ),

                    InkWell(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => Saved_Blog_screen(),));
                      },
                      child: Container(
                        height: 40.ah,width:83.aw,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          //color: HexColor('#001649')
                        ),
                        child:  Center(
                          child: Text('Blogs'.tr,
                            style: TextStyle(
                                color: Colors.grey,fontWeight: FontWeight.w500,fontSize:18.fSize
                            ),
                          ),
                        ),
                      ),
                    ),

                    InkWell(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => SavedPhoto_Screen()));
                      },
                      child: Container(
                        height: 40.ah,width:83.aw,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          //color: HexColor('#001649')
                        ),
                        child:  Center(
                          child: Text('Photos'.tr,
                            style: TextStyle(
                                color: Colors.grey,fontWeight: FontWeight.w500,fontSize:18.fSize
                            ),
                          ),
                        ),
                      ),
                    ),

                    InkWell(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => SavedPeople_profile()));
                      },
                      child: Container(
                        height: 40.ah,width:83.aw,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                           // color: HexColor('#001649')
                        ),
                        child:  Center(
                          child: Text('Profiles'.tr,
                            style: TextStyle(
                                color: Colors.grey,fontWeight: FontWeight.w500,fontSize:18.fSize
                            ),),

                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            SizedBox(height: 10.ah),
            Text('Vlogs'.tr, style: TextStyle(color: Colors.black,fontWeight: FontWeight.w600,fontSize: 24.fSize),),

            SizedBox(height: 10.ah),
            SaveVlog_lisst(),

          ]
        ),
      ),
    );
  }
}


class SaveVlog_lisst extends StatelessWidget {
  const SaveVlog_lisst({super.key});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        width: MediaQuery.of(context).size.width,
        height: 105.ah,
        child: ListView.builder(
          shrinkWrap: true,
          scrollDirection: Axis.vertical,
          itemCount: 10,
          itemBuilder: (context, index) {
            return Padding(
              padding: const EdgeInsets.all(8.0),
              child: Stack(
                alignment: Alignment.topLeft,
                children: [
                  Container(
                    height: 196.ah,width: 362.aw,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(25),
                      // color: Colors.grey,
                      image: DecorationImage(
                          alignment: Alignment.center,fit: BoxFit.fill,
                          image: AssetImage('assets/image/Frame 21150.png')
                      ),

                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left:10,right: 15,top: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Image.asset('assets/image/location-outline.png',width:21.aw,height:21.ah,),
                                // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                Text('Sydney, Australia',
                                  style: TextStyle(
                                    color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                  ),),
                              ],
                            ),
                            Image.asset('assets/image/more op.png',width:22.aw,height: 16.ah,),
                          ],
                        ),
                        SizedBox(height: 60.ah),
                        Text('Circle'.tr,
                          style: TextStyle(
                              color: HexColor('#FFFFFF'),fontWeight: FontWeight.w700,fontSize:16.fSize,
                              height:1.5
                          ),
                        ),
                        SizedBox(height:10.ah),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  height: 24.ah,
                                  width: 24.aw,
                                  decoration: BoxDecoration(
                                    // borderRadius: BorderRadius.all(Radius.circular(35)),
                                      color: Color(0x305B5B5B),
                                      shape: BoxShape.circle,
                                      image: DecorationImage(
                                        fit: BoxFit.fill,
                                        image: AssetImage('assets/image/Ellipse 1.png'),
                                      )),
                                  // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                                ),
                                // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                Text('   Kriston',
                                  style: TextStyle(
                                    color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                  ),),
                                Text('  125K views',
                                  style: TextStyle(
                                    color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                  ),),
                                Text('3 week'.tr,
                                  style: TextStyle(
                                    color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                  ),),

                              ],
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment. spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Image.asset('assets/image/like.png',width:21.aw,height:21.ah,),
                                SizedBox(width: 5.aw),
                                Image.asset('assets/image/Union (2).png',width:21.aw,height:21.ah,),
                                SizedBox(width: 5.aw),
                                Image.asset('assets/image/Vector (1).png',width:22.aw,height:21.ah,),
                                SizedBox(width: 5.aw),
                                Image.asset('assets/image/bookmark.png',width:22.aw,height:21.ah,),
                              ],
                            )

                          ],
                        ),
                      ],
                    ),
                  ),

                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

