// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/rendering.dart';
// import 'package:flutter/widgets.dart';
// import 'package:frenly_file/core/utils/size_utils.dart';
// import 'package:hexcolor/hexcolor.dart';
// import 'package:get/get.dart';
//
// class PopularsCityScreen extends StatefulWidget {
//   const PopularsCityScreen({super.key});
//
//   @override
//   State<PopularsCityScreen> createState() => _PopularsCityScreenState();
// }
//
// class _PopularsCityScreenState extends State<PopularsCityScreen> {
//
//
//   List CAviat = [
//     'assets/image/king.png',
//     'assets/image/kimngdom.png',
//     'assets/image/kinggs.png',
//     'assets/image/king.png',
//     'assets/image/kimngdom.png',
//     'assets/image/kinggs.png'
//   ];
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Padding(
//         padding: const EdgeInsets.only(left: 10,right: 10,top:63),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           mainAxisAlignment: MainAxisAlignment.start,
//           mainAxisSize: MainAxisSize.min,
//           children: [
//
//             Row(
//               // mainAxisSize: MainAxisSize.min,
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                   crossAxisAlignment: CrossAxisAlignment.center,
//                   children: [
//                     InkWell(
//                         onTap: () {
//                           Navigator.pop(context);
//                         },
//                         child: Icon(Icons.arrow_back)),
//                     SizedBox(width: 10.aw,),
//                     Text('Popular'.tr,
//                       style: TextStyle(
//                           color: Colors.black,fontWeight: FontWeight.w700,fontSize: 35
//                       ),
//                     ),
//                   ],
//                 ),
//
//                 Container(
//                   height: 36.ah,
//                   width: 36.aw,
//                   decoration: BoxDecoration(
//                     // borderRadius: BorderRadius.all(Radius.circular(35)),
//                       color: Color(0x305B5B5B),
//                       shape: BoxShape.circle,
//                       image: DecorationImage(
//                         fit: BoxFit.fill,
//                         image: AssetImage('assets/image/Ellipse 1.png'),
//                       )),
//                   // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
//                 ),
//               ],
//             ),
//
//             SizedBox(height: 20.ah),
//             Text('Allcit'.tr,
//               style: TextStyle(
//                   color: Colors.black,fontWeight: FontWeight.w600,fontSize:24
//               ),
//             ),
//             AllCities(),
//           ],
//         ),
//       ),
//     );
//   }
// }
//
// class AllCities extends StatelessWidget {
//   const AllCities({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//
//     List CAviat = [
//       'assets/image/king.png',
//       'assets/image/kimngdom.png',
//       'assets/image/kinggs.png',
//       'assets/image/king.png',
//       'assets/image/kimngdom.png',
//       'assets/image/kinggs.png'
//     ];
//
//     return Expanded(
//       child: Container(
//         color: Colors.white,
//         width: MediaQuery.of(context).size.width,
//         height: 165.ah,
//         child: ListView.builder(
//           shrinkWrap: true,
//           scrollDirection: Axis.vertical,
//           itemCount: 15,
//           padding: EdgeInsets.only(bottom: 10,),
//           itemBuilder: (context, index) {
//             return Padding(
//               padding: const EdgeInsets.all(5.0),
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 crossAxisAlignment: CrossAxisAlignment.center,
//                 children: [
//                   Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     mainAxisAlignment: MainAxisAlignment.start,
//                     children: [
//                       Text('New York',
//                         style: TextStyle(
//                           color: Colors.black,fontWeight: FontWeight.w700,fontSize:17.fSize,
//                         ),),
//                       Text('USA',
//                         style: TextStyle(
//                           color: Colors.grey,fontWeight: FontWeight.w500,fontSize:15.fSize,
//                         ),),
//                     ],
//                   ),
//                   Row(
//                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                     crossAxisAlignment:CrossAxisAlignment.center ,
//                     children: [
//                       Align(
//                         alignment: Alignment.bottomCenter,
//                         child: Row(
//                           mainAxisSize: MainAxisSize.min,
//                           mainAxisAlignment: MainAxisAlignment.center,
//                           crossAxisAlignment: CrossAxisAlignment.center,
//                           children: [
//                             for (int i = 0; i < CAviat.length; i++)
//                               Align(
//                                 widthFactor: 0.5,
//                                 // parent circle avatar.
//                                 // We defined this for better UI
//                                 child: CircleAvatar(
//                                   radius:15.ah,
//                                   //backgroundColor: Colors.white,
//                                   // Child circle avatar
//                                   child: CircleAvatar(
//                                     radius: 18.aw,
//                                     backgroundImage: AssetImage(CAviat[i]),
//                                     //NetworkImage(RandomImages[i]),
//                                   ),
//                                 ),
//                               )
//                           ],
//                         ),
//                       ),
//                       SizedBox(width:10.aw,),
//                       Text('1.5K\nActives'.tr,
//                         style: TextStyle(
//                           color: HexColor('#111111'),fontWeight: FontWeight.w600,fontSize:12.3.fSize,
//                         ),
//                       ),
//                   ],)
//
//
//                 ],
//               ),
//             );
//           },
//         ),
//       ),
//     );
//   }
// }
//
//
// /*
// class AllCities extends StatelessWidget {
//   const AllCities({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//
//     List CAviat = [
//       'assets/image/king.png',
//       'assets/image/kimngdom.png',
//       'assets/image/kinggs.png',
//       'assets/image/king.png',
//       'assets/image/kimngdom.png',
//       'assets/image/kinggs.png'
//     ];
//
//     return Expanded(
//       child: GridView.builder(
//           itemCount: 18,
//           gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
//               crossAxisCount: 3,mainAxisExtent:233.ah,
//               mainAxisSpacing: 10
//           ),
//           itemBuilder: (context, index) {
//             return  Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               mainAxisAlignment: MainAxisAlignment.start,
//               children: [
//                 Stack(
//                   //alignment: Alignment.topCenter,
//                   children: [
//                     Container(
//                       width: 115.aw,
//                       height: 192.ah,
//                       decoration: ShapeDecoration(
//                           image: DecorationImage(
//                               image: AssetImage('assets/image/cyril-mzn-WSvth_lwCi0-unsplash.jpg'),
//                               fit: BoxFit.fill
//                           ), shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.all(Radius.circular(10)),)
//                       ),
//
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.center,
//                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                         children: [
//                           Padding(
//                             padding:  EdgeInsets.only(left:15.h,right:15.h,top: 5),
//                             child: Center(
//                               //child: Text('New York City \ncomprises 5 \nboroughs sitting \nwhere the Hudson \nRiver meets the \nAtlantic Ocean. ',
//                               child: Text('Dubai is a city and emirate in the United Arab Emirates known for luxury shopping,',
//                                 style: TextStyle(
//                                   color: HexColor('#FFFFFF'),fontFamily: 'Roboto',fontWeight: FontWeight.w600,fontSize:9.fSize,
//                                 ),
//                               ),
//                             ),
//                           ),
//                           Column(
//                             mainAxisAlignment: MainAxisAlignment.start,
//                             crossAxisAlignment: CrossAxisAlignment.start,
//                             children: [
//                               Align(
//                                 alignment: Alignment.bottomCenter,
//                                 child: Row(
//                                   mainAxisSize: MainAxisSize.min,
//                                   mainAxisAlignment: MainAxisAlignment.center,
//                                   crossAxisAlignment: CrossAxisAlignment.center,
//                                   children: [
//                                     for (int i = 0; i < CAviat.length; i++)
//                                       Align(
//                                         widthFactor: 0.5,
//                                         // parent circle avatar.
//                                         // We defined this for better UI
//                                         child: CircleAvatar(
//                                           radius:15.ah,
//                                           //backgroundColor: Colors.white,
//                                           // Child circle avatar
//                                           child: CircleAvatar(
//                                             radius: 18.aw,
//                                             backgroundImage: AssetImage(CAviat[i]),
//                                             //NetworkImage(RandomImages[i]),
//                                           ),
//                                         ),
//                                       )
//                                   ],
//                                 ),
//                               ),
//                               SizedBox(height: 5,),
//                               Text('     1.5K \n     Active friends',
//                                 style: TextStyle(
//                                   color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:9.fSize,
//                                 ),
//                               ),
//
//                             ],
//                           ),
//
//                         ],
//                       ),
//                     ),
//                   ],
//                 ),
//
//                 Text(' Paris',
//                   style: TextStyle(color: Colors.black,fontWeight: FontWeight.w600,fontSize:15.fSize,),),
//
//                 Text(' France',
//                   style: TextStyle(color: HexColor('#AAAAAA'),fontWeight: FontWeight.w600,fontSize:12.fSize,),
//                 ),
//
//               ],
//             );
//           }),
//     );
//   }
// }
// */
