import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class FullScreenPage extends StatefulWidget {
  const FullScreenPage({super.key});

  @override
  State<FullScreenPage> createState() => _FullScreenPageState();
}

class _FullScreenPageState extends State<FullScreenPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
         // color: Colors.red,
          image: DecorationImage(
            fit: BoxFit.fill,
              image: AssetImage('assets/image/Full screennnn (1).png')
          )
        ),
      ),
    );
  }
}
