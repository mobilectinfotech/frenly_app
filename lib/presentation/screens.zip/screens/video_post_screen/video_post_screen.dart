import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:frenly_file/presentation/screens/photo_post/photo_post.dart';
import 'package:frenly_file/core/utils/size_utils.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:get/get.dart';
import '../../../core/constants/my_textfield.dart';

class Video_Post_Screen extends StatefulWidget {
  const Video_Post_Screen({super.key});

  @override
  State<Video_Post_Screen> createState() => _Video_Post_ScreenState();
}

class _Video_Post_ScreenState extends State<Video_Post_Screen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
      appBar: AppBar(

        title: Row(
          children: [
            Text('VideoPost'.tr,
              style: TextStyle(
                  color: Colors.black,fontWeight: FontWeight.w600,fontSize:20.fSize
              ),
            ),
          ],
        ),
        leading: Padding(
          padding:  EdgeInsets.only(left: 35.h),
          child: InkWell(
            onTap: () {
              Navigator.pop(context);
            },
              child: Icon(Icons.arrow_back_sharp)),
        ),
        backgroundColor: Colors.white,
        shadowColor: Colors.white,
        surfaceTintColor: Colors.white,

        elevation:3,
      ),

      body: Padding(
        padding: const EdgeInsets.only(left: 10,right: 10,top: 20),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment:  MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    height: 194.ah,
                    //width: 362.aw,
                    width: MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(25),
                      // color: Colors.grey,
                      image: DecorationImage(
                          alignment: Alignment.center,fit: BoxFit.fill,
                          image: AssetImage('assets/image/Frame 21150.png')
                      ),

                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left:10,right: 15,top: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(height:30.ah),
                        Center(child: Image.asset('assets/image/Polygon 2.png',height: 40.ah,
                          width: MediaQuery.of(context).size.width,
                        )),
                        SizedBox(height: 60.ah),
                        Image.asset('assets/image/Frame 427320855.png',width:MediaQuery.of(context).size.width,
                          height: 24.ah,),


                      ],
                    ),
                  ),

                ],
              ),

              SizedBox(height: 20.ah),
              Padding(
                padding: const EdgeInsets.only(left:10),
                child: Text('Title'.tr,
                  style: TextStyle(
                      color: Colors.black,fontWeight: FontWeight.w700,fontSize: 15.fSize
                  ),
                ),
              ),

              SizedBox(height: 10.ah,),
              primaryTextfield2(
                  hintText: 'How to drink milkshake'.tr,
                  controller: null
              ),

              SizedBox(height: 20.ah),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left:10),
                    child: Text('Description'.tr,
                      style: TextStyle(
                          color: Colors.black,fontWeight: FontWeight.w700,fontSize: 15.fSize
                      ),
                    ),
                  ),
                  SizedBox(height: 10.ah,),
                  primaryTextfield4(
                      hintText: 'This is Description'.tr,
                      controller: null
                  ),
                ],
              ),


              Center(
                child: CustomPrimaryBtn1(
                  title: 'Upload'.tr,
                  isLoading: false,
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => Photo_post()));
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
