import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:frenly_file/core/constants/my_app_url.dart';
import 'package:get/get.dart';
import 'package:fluttertoast/fluttertoast.dart';

class ForgetPasswordController extends GetxController {

  TextEditingController emailforgetcontr = TextEditingController();

  RxBool isLoadig =false.obs;
  RxBool seePassword =true.obs;
  RxBool seePassword1 =true.obs;


}