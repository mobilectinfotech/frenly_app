import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:frenly_file/presentation/screens/following_screen/followingscreen.dart';
import 'package:frenly_file/core/utils/size_utils.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:get/get.dart';
class Followers_Screen extends StatefulWidget {
  const Followers_Screen({super.key});

  @override
  State<Followers_Screen> createState() => _Followers_ScreenState();
}

class _Followers_ScreenState extends State<Followers_Screen> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        surfaceTintColor: Colors.white,
        backgroundColor: Colors.white,
        title: Row(
          children: [
            Text('Followers'.tr,
              style: TextStyle(
                  color: Colors.black,fontWeight: FontWeight.w700,fontSize:32.fSize
              ),
            ),
          ],
        ),
        leading: Padding(
          padding:  EdgeInsets.only(left: 15.h),
          child: InkWell(
              onTap: () {
                Navigator.pop(context);
              },
              child: Icon(Icons.arrow_back_sharp)),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              height: 36.ah,
              width: 36.aw,
              decoration: BoxDecoration(
                // borderRadius: BorderRadius.all(Radius.circular(35)),
                  color: Color(0x305B5B5B),
                  shape: BoxShape.circle,
                  image: DecorationImage(
                    fit: BoxFit.fill,
                    image: AssetImage('assets/image/Ellipse 1.png'),
                  )),
              // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.only(left: 10,right: 10,top:20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('126K', style: TextStyle(color: Colors.black,fontWeight: FontWeight.w600,fontSize: 24.fSize),),

            SizedBox(height: 20.ah),
            Expanded(
                child: InkWell(
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => FollowingScreen()));
                    },
                    child: Content5())
            ),
          // ah  InkWell(
          //     InkWellonTap: () {
          //       Navigator.push(context, MaterialPageRoute(builder: (context) => Content5()));
          //     },
          //     child: Content5(),
          //   ),

          ],
        ),
      ),
    );
  }
}


class Content5 extends StatefulWidget {
  @override
  State<Content5> createState() => _Content5State();
}

class _Content5State extends State<Content5> {

  List<bool> active = [false, false, ];
  List<String> follow_Unfollow = [
    "Follow",
    "Unfollow",
  ];

  var selectone;

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
        itemCount: 12,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,mainAxisExtent: 223,
            mainAxisSpacing: 5,crossAxisSpacing: 5
        ),
        itemBuilder: (context, index) {
          return Container(
           height: 223.ah,width: 120.aw,
            decoration: BoxDecoration(
              color: Colors.white,
                borderRadius: BorderRadius.circular(7),
                border: Border.all(
                  //color: HexColor('#FFFFFF'),
                    color: Colors.black12,
                    width:1
                )
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  height: 109.ah,width: 109.aw,
                    decoration: ShapeDecoration(
                        color: Colors.white,
                        shape: CircleBorder(),
                        image: DecorationImage(
                            image: AssetImage('assets/image/girrrls.png'),
                            fit: BoxFit.cover
                        )
                    )
                ),

                SizedBox(height:2.ah),
                Text('Rose celebs',
                  style: TextStyle(
                      color: Colors.black,fontWeight: FontWeight.w500,fontSize:13.fSize
                  ),
                ),

                SizedBox(height:2.ah),
                Text('rose_ce',
                  style: TextStyle(
                      color: Colors.grey,fontWeight: FontWeight.w600,fontSize:12.fSize
                  ),
                ),

                SizedBox(height:2.ah),
                Text('27M',
                  style: TextStyle(
                      color: Colors.black,fontWeight: FontWeight.w500,fontSize:12.fSize
                  ),
                ),


                SizedBox(height:10.ah),
                InkWell(
                  onTap:  () {
                    active[0] = !active[0];
                    setState(() {
                      follow_Unfollow[0] = "Follow".tr;
                    },
                    );
                  },
                  child: Container(
                    height: 24.ah,width: 98.aw,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(4),
                        color: active[0] ? Colors.red : HexColor('#001649'),
                    ),
                    child:  Center(
                      child: Text(active[0] ?'Unfollow'.tr:'Follow'.tr,
                        style: TextStyle(
                            color: active[0] ? Colors.white : Colors.white,
                            fontWeight: FontWeight.w500,fontSize:14.fSize
                        ),
                      ),
                    ),
                  ),
                )
              ],
            ),
          );
        });
  }
}


