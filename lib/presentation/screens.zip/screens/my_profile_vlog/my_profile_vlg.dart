import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:frenly_file/presentation/screens/video_player_screen/video_player_screen.dart';
import 'package:frenly_file/core/utils/size_utils.dart';
import 'package:get/get.dart';
import 'package:hexcolor/hexcolor.dart';

import '../create_password/create_password.dart';
class MyProfileVlog extends StatefulWidget {
  const MyProfileVlog({super.key});

  @override
  State<MyProfileVlog> createState() => _MyProfileVlogState();
}

class _MyProfileVlogState extends State<MyProfileVlog> {


  List<bool> active = [false, false, ];

  List<String> follow_Unfollow = [
    "Follow",
    "Unfollow",
  ];

  var selectone;
  late TabController tabController;
  int _tabIndex = 0;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length:3,
      child: Scaffold(
        backgroundColor: HexColor('#E8E8E8'),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Stack(
              children: [
                Padding(
                  padding: EdgeInsets.only(left: 10.h,right: 10.h,top: 260.v),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Brett Pit',
                                style: TextStyle(
                                    color: Colors.black,fontWeight: FontWeight.w600,fontSize:25.fSize
                                ),
                              ),

                              Text('brittie',
                                style: TextStyle(
                                    color: Colors.black54,fontWeight: FontWeight.w700,fontSize:15.fSize
                                ),
                              ),
                            ],
                          ),

                          InkWell(
                            onTap: () {
                              active[0] = !active[0];
                              setState(() {
                                follow_Unfollow[0] = "Follow".tr;
                              },);
                            },
                            child: Container(
                              height: 34.ah,width: 98.aw,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(4),
                                color:  active[0] ? Colors.red : HexColor('#001649'),
                                //HexColor('#001649')
                              ),
                              child:  Center(
                                child: Text(active[0] ?'Unfollow'.tr:'Follow'.tr,
                                  style: TextStyle(
                                      color: active[0] ? Colors.white : Colors.white,
                                      fontWeight: FontWeight.w500,fontSize:14.fSize
                                  ),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),

                      SizedBox(height: 10.ah),
                      Text('MyNamePro'.tr,
                        style: TextStyle(height: 1.5,
                          color: Colors.grey,fontWeight: FontWeight.w400,fontSize:16.fSize,
                        ),
                      ),

                      SizedBox(height: 15.ah),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text('18',
                                style: TextStyle(
                                  color: Colors.black,fontWeight: FontWeight.w600,fontSize:16.fSize,
                                ),
                              ),

                              Text('Posts'.tr,
                                style: TextStyle(
                                  color: Colors.grey,fontWeight: FontWeight.w500,fontSize:16.fSize,
                                ),
                              ),
                            ],
                          ),

                          Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text('517K',
                                style: TextStyle(
                                  color: Colors.black,fontWeight: FontWeight.w600,fontSize:16.fSize,
                                ),
                              ),

                              Text('Follower'.tr,
                                style: TextStyle(
                                  color: Colors.grey,fontWeight: FontWeight.w500,fontSize:16.fSize,
                                ),
                              ),
                            ],
                          ),

                          Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text('5.3k',
                                style: TextStyle(
                                  color: Colors.black,fontWeight: FontWeight.w600,fontSize:16.fSize,
                                ),
                              ),

                              Text('Following'.tr,
                                style: TextStyle(
                                  color: Colors.grey,fontWeight: FontWeight.w500,fontSize:16.fSize,
                                ),
                              ),
                            ],
                          ),

                          Image.asset('assets/image/msg btn.png',height: 42.ah,width: 42.aw,fit: BoxFit.contain,)

                        ],),
                      SizedBox(height: 15.ah),
                    ],
                  ),
                ),
                Container(
                  height: MediaQuery.of(context).size.width,
                  width: MediaQuery.of(context).size.width,),

                Container(
                  width:MediaQuery.of(context).size.width,
                  height: 229.ah,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                        bottomRight: Radius.circular(25),bottomLeft: Radius.circular(25)
                    ),
                    image: DecorationImage(
                      image: AssetImage('assets/image/Frame 21141.png'),
                      fit: BoxFit.fill,
                    ),
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.all(30.0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Image.asset('assets/image/arrow.png',height: 20.ah,width: 20.aw),

                      InkWell(
                          onTap: () {
                           // Navigator.push(context, MaterialPageRoute(builder: (context) => MyProfileVlog()));
                          },
                          child: Image.asset('assets/image/ic_settings_24px.png',height: 20.ah,width: 20.aw,color: Colors.red,)),
                    ],
                  ),
                ),

                Positioned(
                    top: 135.ah,
                    left: 120.aw,
                    child: Center(
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            Container(
                                width: 148.aw,
                                height: 148.ah,
                                //color: Colors.redAccent,
                                decoration: ShapeDecoration(
                                  color: Colors.white,
                                  shape: CircleBorder(),
                                )
                            ),

                            Container(
                                width: 140.aw,
                                height: 140.ah,
                                decoration: ShapeDecoration(
                                  color: Colors.grey,
                                  shape: CircleBorder(),
                                  image: DecorationImage(
                                      fit: BoxFit.cover,
                                      image:
                                      //NetworkImage("${firestore.currentUser!.photoURL}"),
                                      AssetImage('assets/image/nick-andreka-XJWm6jERxcc-unsplash.jpg')
                                  ),
                                )
                            ),
                          ],
                        )
                    )),

              ],
            ),

            Padding(
              padding: const EdgeInsets.only(left: 10,right: 10),
              child: Container(
                height: 62.ah,
                width:MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                    color: Colors.white,
                    //color: Colors.black,
                    borderRadius: BorderRadius.circular(10)
                ),
                child: TabBar(

                  automaticIndicatorColorAdjustment: false,
                  indicatorColor: Colors.transparent,
                  indicatorWeight: 2,
                 dividerColor: Colors.transparent,
                   indicator: BoxDecoration(
                    borderRadius: BorderRadius.circular(10.0,),
                    color: colors[_tabIndex],
                  ),
                  labelStyle: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w500),
                  unselectedLabelColor: Colors.grey,

                  padding: EdgeInsets.all(10),

                  //indicatorColor: Colors.blueGrey,
                  // overlayColor: MaterialStateProperty.resolveWith<Color?>(
                  //       (Set<MaterialState> states) {
                  //     if (states.contains(MaterialState.hovered))
                  //       return Colors.red; //<-- SEE HERE
                  //     return null;
                  //   },
                  // ),

                  tabs: [
                    Tab(
                      //icon: Icon(Icons.chat_bubble),
                      child: Container(
                        height: 40,
                        width:MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                           // color: HexColor('#001649')
                        ),
                        child:  Center(
                          child: Text('Vlogs'.tr,
                            //style: TextStyle(color: Colors.grey,fontWeight: FontWeight.w600,fontSize:18.fSize),
                          ),
                        ),
                      ),
                    ),

                    Tab(
                      child: Container(
                        height: 40.ah,width:112.aw,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          // color: HexColor('#001649')
                        ),
                        child:  Center(
                          child: Text('Blogs'.tr,
                           // style: TextStyle(color: Colors.grey,fontWeight: FontWeight.w500,fontSize:18.fSize),
                          ),
                        ),),
                    ),

                    Tab(
                      child: Container(
                        height: 40.ah,width:112.aw,
                        decoration: BoxDecoration(
                        //  borderRadius: BorderRadius.circular(50),
                        //  color: Colors.red
                          // color: HexColor('#001649')
                        ),
                        child:  Center(
                          child: Text('Photos'.tr,
                            //style: TextStyle(color: Colors.grey,fontWeight: FontWeight.w500,fontSize:18.fSize),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            Expanded(
              child:  Padding(
                padding: const EdgeInsets.only(left: 10,right: 10,top: 10),
                child: TabBarView(
                  children: [

                    InkWell(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => VideoPlayer()));
                        },
                        child: MyVlogslist()),

                    MyBlogsList(),

                    SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Image.asset('assets/image/Frame 21150 (2).png',height: 120.ah,width: 120.aw,fit: BoxFit.fill,),
                              Image.asset('assets/image/Frame 21158.png',height: 120.ah,width: 120.aw,fit: BoxFit.fill,),
                              Image.asset('assets/image/Frame 21150 (2).png',height: 120.ah,width: 120.aw,fit: BoxFit.fill,),
                            ],
                          ),
                          SizedBox(height: 10.ah),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Image.asset('assets/image/Frame 21160.png',height: 120.ah,width: 120.aw,fit: BoxFit.fill,),
                                  SizedBox(height: 8.ah),
                                  Image.asset('assets/image/Frame 21150 (2).png',height: 120.ah,width: 120.aw,fit: BoxFit.fill,),

                                ],
                              ),
                              SizedBox(width: 5.aw,),
                              Image.asset('assets/image/Frame 21161.png',height:252.ah,width:243.aw,fit: BoxFit.fill,),

                            ],
                          ),
                          SizedBox(height: 10.ah),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [

                              Image.asset('assets/image/Frame 21161.png',height:252.ah,width:243.aw,fit: BoxFit.fill,),
                              SizedBox(width: 5.aw,),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Image.asset('assets/image/Frame 21160.png',height: 120.ah,width: 120.aw,fit: BoxFit.fill,),
                                  SizedBox(height: 8.ah),
                                  Image.asset('assets/image/Frame 21150 (2).png',height: 120.ah,width: 120.aw,fit: BoxFit.fill,),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

          ],
        ),
      ),
    );
  }
}

class MyVlogslist extends StatelessWidget {
  const MyVlogslist({super.key});

  @override
  Widget build(BuildContext context) {
    return  ListView.builder(
      shrinkWrap: true,
      scrollDirection: Axis.vertical,
      itemCount: 10,
      padding: EdgeInsets.only(bottom: 10),
      itemBuilder: (context, index) {
        return Padding(
            padding: EdgeInsets.only(bottom: 10),
          child: Stack(
            alignment: Alignment.topLeft,
            children: [
              Container(
                height: 194.ah,width:MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(25),
                  // color: Colors.grey,
                  image: DecorationImage(
                      alignment: Alignment.center,fit: BoxFit.fill,
                      image: AssetImage('assets/image/victor-freitas-qZ-U9z4TQ6A-unsplash.jpg')
                  ),

                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left:10,right: 15,top: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Icon(Icons.location_on,color: Colors.white,),
                            // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                            Text('Sydney, Australia',
                              style: TextStyle(
                                color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                              ),),
                          ],
                        ),
                        Image.asset('assets/image/more op.png',width:22.aw,height: 16.ah,),
                      ],
                    ),
                    SizedBox(height: 60.ah),
                    Text('Circle'.tr,
                      style: TextStyle(
                          color: HexColor('#FFFFFF'),fontWeight: FontWeight.w700,fontSize:16.fSize,
                          height:1.5
                      ),
                    ),
                    SizedBox(height:10.ah),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          height: 24.ah,
                          width: 24.aw,
                          decoration: BoxDecoration(
                            // borderRadius: BorderRadius.all(Radius.circular(35)),
                              color: Color(0x305B5B5B),
                              shape: BoxShape.circle,
                              image: DecorationImage(
                                fit: BoxFit.fill,
                                image: AssetImage('assets/image/Ellipse 1.png'),
                              )),
                          // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                        ),
                        // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                        Text('Kriston',
                          style: TextStyle(
                            color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                          ),),
                        Text('125K views',
                          style: TextStyle(
                            color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                          ),),
                        Text('3 days ago',
                          style: TextStyle(
                            color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                          ),),

                        SizedBox(width: 5.aw),
                        Image.asset('assets/image/like.png',width:21.aw,height:21.ah,),
                        SizedBox(width: 5.aw),
                        Image.asset('assets/image/cooment.png',width:21.aw,height:21.ah,),
                        SizedBox(width: 5.aw),
                        Image.asset('assets/image/share.png',width:22.aw,height:21.ah,),
                        SizedBox(width: 5.aw),
                        Image.asset('assets/image/bookmark.png',width:22.aw,height:21.ah,),

                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class MyBlogsList extends StatelessWidget {
  const MyBlogsList({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      shrinkWrap: true,
      scrollDirection: Axis.vertical,
      itemCount: 10,
      padding: EdgeInsets.only(bottom: 10),
      itemBuilder: (context, index) {
        return  Padding(
          padding: const EdgeInsets.only(bottom: 10,right: 5),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    height: 144.ah,width: 144.aw,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        image: DecorationImage(
                            image: AssetImage('assets/image/Frame 21150 (2).png')
                        )
                    ),
                  ),
                  SizedBox(width:5.aw,),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            height: 20.ah,width: 60.aw,
                            decoration: BoxDecoration(
                                border: Border.all(
                                    color: Colors.black,
                                    width: 0.3
                                ),
                                borderRadius: BorderRadius.circular(5),
                                color: Colors.grey.shade300
                            ),
                            child:  Center(
                              child: Text('Cooking'.tr,
                                style: TextStyle(
                                    color: Colors.grey,fontWeight: FontWeight.w500,fontSize:10.fSize
                                ),
                              ),
                            ),
                          ),

                        ],
                      ),
                      SizedBox(height: 5.ah),
                      Text('lect'.tr,
                        style: TextStyle(
                            color: Colors.black,fontWeight: FontWeight.w600,fontSize:20.fSize
                        ),
                      ),
                      SizedBox(height: 5.ah),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            height: 32.ah,
                            width: 32.aw,
                            decoration: BoxDecoration(
                              // borderRadius: BorderRadius.all(Radius.circular(35)),
                                color: Color(0x305B5B5B),
                                shape: BoxShape.circle,
                                image: DecorationImage(
                                  fit: BoxFit.fill,
                                  image: AssetImage('assets/image/Frame 427320834.png'),
                                )),
                            // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                          ),
                          SizedBox(width: 10.aw),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text('Naila Iman',
                                style: TextStyle(
                                  color: Colors.black,fontWeight: FontWeight.w600,fontSize:14.fSize,
                                ),),
                              Text('Kriston.3 weeks'.tr,
                                style: TextStyle(
                                  color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize,
                                ),),
                            ],
                          ),

                        ],
                      ),
                    ],
                  ),

                ],
              ),
              Image.asset('assets/image/more option.png',height: 16.ah,width: 4.aw,),

            ],
          ),
        );
      },
    );
  }
}
