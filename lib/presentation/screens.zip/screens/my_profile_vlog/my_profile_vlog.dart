import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:frenly_file/presentation/screens/follower_screen/follower_screen.dart';
import 'package:frenly_file/presentation/screens/following_screen/followingscreen.dart';
import 'package:frenly_file/presentation/screens/my_profile_vlog/my_profile_vlg.dart';
import 'package:frenly_file/presentation/screens/user_blog/profile_user_blog.dart';
import 'package:frenly_file/core/utils/size_utils.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:get/get.dart';
import '../../dashboard_screen/dashboard_screen.dart';
import '../../home_screen/home_screen.dart';
import '../../user_profile_screen/my_profile_screen.dart';
import '../../user_profile_screen/user_profile_screen.dart';
import '../aaa/new.dart';
import '../message_screen/message_screen.dart';
import '../user_photo/profile_user_photos.dart';
import '../video_player_screen/video_player_screen.dart';


class My_Profile_Vlog extends StatefulWidget {
  const My_Profile_Vlog({super.key});

  @override
  State<My_Profile_Vlog> createState() => _My_Profile_VlogState();
}

class _My_Profile_VlogState extends State<My_Profile_Vlog> {
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }
  List  _items =[

    HomeScreen(),
    //SearchVlog_screen(),
    New(),
    My_Profile_Vlog(),
    Message_Screen(),
    MyProfileScreen(),

    //  MyStatefulWidget(),
    // Home_Pages()
    //TextIncrease()
    //Staggerd()

  ];
  List<bool> active = [false, false, ];

  List<String> follow_Unfollow = [
    "Follow",
    "Unfollow",
  ];
  var selectone;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: HexColor('#E8E8E8'),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Stack(
              children: [
                Padding(
                  padding:  EdgeInsets.only(left: 10,right: 10,top: 235),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Brett Pit',
                                style: TextStyle(
                                    color: Colors.black,fontWeight: FontWeight.w600,fontSize:25
                                ),
                              ),
                              Text('brittie',
                                style: TextStyle(
                                    color: Colors.black54,fontWeight: FontWeight.w700,fontSize:15
                                ),
                              ),

                            ],
                          ),
                          InkWell(
                            onTap: () {
                              active[0] = !active[0];
                            setState(() {
                              follow_Unfollow[0] = "Follow".tr;
                            },);
                          },
                            child: Container(
                              height: 34.ah,width: 98.aw,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(4),
                                  color:  active[0] ? Colors.red : HexColor('#001649'),
                                  //HexColor('#001649')
                              ),
                              child:  Center(
                                child: Text(active[0] ?'Unfollow'.tr:'Follow'.tr,
                                  style: TextStyle(
                                      color: active[0] ? Colors.white : Colors.white,
                                      fontWeight: FontWeight.w500,fontSize:14.fSize
                                  ),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),

                      SizedBox(height: 10.ah),
                      Text('MyNamePro'.tr,
                        style: TextStyle(height: 1.5,
                          color: Colors.grey,fontWeight: FontWeight.w400,fontSize:16.fSize,
                        ),
                      ),

                      SizedBox(height: 15.ah),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text('18',
                                style: TextStyle(
                                  color: Colors.black,fontWeight: FontWeight.w600,fontSize:16.fSize,
                                ),
                              ),

                              Text('Posts'.tr,
                                style: TextStyle(
                                  color: Colors.grey,fontWeight: FontWeight.w500,fontSize:16.fSize,
                                ),
                              ),
                            ],
                          ),

                          InkWell(
                            onTap: () {
                              Navigator.push(context, MaterialPageRoute(builder: (context) => Followers_Screen(),));
                            },
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Text('517K',
                                  style: TextStyle(
                                    color: Colors.black,fontWeight: FontWeight.w600,fontSize:16.fSize,
                                  ),
                                ),

                                Text('Follower'.tr,
                                  style: TextStyle(
                                    color: Colors.grey,fontWeight: FontWeight.w500,fontSize:16.fSize,
                                  ),
                                ),
                              ],
                            ),
                          ),

                          InkWell(
                            onTap: () {
                              Navigator.push(context, MaterialPageRoute(builder: (context) => FollowingScreen()));
                            },
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Text('5.3k',
                                  style: TextStyle(
                                    color: Colors.black,fontWeight: FontWeight.w600,fontSize:16.fSize,
                                  ),
                                ),

                                Text('Following'.tr,
                                  style: TextStyle(
                                    color: Colors.grey,fontWeight: FontWeight.w500,fontSize:16.fSize,
                                  ),
                                ),
                              ],
                            ),
                          ),

                          Image.asset('assets/image/msg btn.png',height: 42.ah,width: 42.aw,fit: BoxFit.contain,)
                        ],
                      ),

                      SizedBox(height: 15.ah),
                      Container(
                        height: 52.ah,width:MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10)
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(4.0),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [

                              Container(
                                height: 40.ah,width:112.aw,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(8),
                                    color: HexColor('#001649')
                                ),
                                child:  Center(
                                  child: Text('vlog'.tr,
                                    style: TextStyle(
                                        color: Colors.white,fontWeight: FontWeight.w600,fontSize:18.fSize
                                    ),
                                  ),
                                ),
                              ),

                              InkWell(
                                onTap: () {
                                  Navigator.push(context, MaterialPageRoute(builder: (context) =>Profile_User_Blog()));
                                },
                                child: Container(
                                  height: 40.ah,width:112.aw,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(8),
                                    // color: HexColor('#001649')
                                  ),
                                  child:  Center(
                                    child: Text('Blogs'.tr,
                                      style: TextStyle(
                                          color: Colors.grey,fontWeight: FontWeight.w500,fontSize:18.fSize
                                      ),),

                                  ),
                                ),
                              ),

                              InkWell(
                                onTap: () {
                                  Navigator.push(context, MaterialPageRoute(builder: (context) =>Profile_User_Photos()));
                                },
                                child: Container(
                                  height: 40.ah,width:112.aw,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(8),
                                    // color: HexColor('#001649')
                                  ),
                                  child:  Center(
                                    child: Text('Photo'.tr,
                                      style: TextStyle(
                                          color: Colors.grey,fontWeight: FontWeight.w500,fontSize:18.fSize
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      SizedBox(height:20.ah),
                      InkWell(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => VideoPlayer()));
                        },
                        child: Stack(
                          alignment: Alignment.topLeft,
                          children: [
                            Container(
                              height: 196.ah,width:MediaQuery.of(context).size.width,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(25),
                                // color: Colors.grey,
                                image: DecorationImage(
                                    alignment: Alignment.center,fit: BoxFit.fill,
                                    image: AssetImage('assets/image/Frame 21150.png')
                                ),

                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left:10,right: 15,top: 10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Icon(Icons.location_on,color: Colors.white,),
                                          // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                          Text('Sydney, Australia',
                                            style: TextStyle(
                                              color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                            ),),
                                        ],
                                      ),
                                      Image.asset('assets/image/more op.png',width:22.aw,height: 16.ah,),
                                    ],
                                  ),
                                  SizedBox(height: 60.ah),
                                  Text('Circle'.tr,
                                    style: TextStyle(
                                        color: HexColor('#FFFFFF'),fontWeight: FontWeight.w700,fontSize:16.fSize,
                                        height:1.5
                                    ),
                                  ),
                                  SizedBox(height:10.ah),
                                  Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            height: 24.ah,
                                            width: 24.aw,
                                            decoration: BoxDecoration(
                                              // borderRadius: BorderRadius.all(Radius.circular(35)),
                                                color: Color(0x305B5B5B),
                                                shape: BoxShape.circle,
                                                image: DecorationImage(
                                                  fit: BoxFit.fill,
                                                  image: AssetImage('assets/image/Ellipse 1.png'),
                                                )),
                                            // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                                          ),
                                          // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                          Text('   Kriston',
                                            style: TextStyle(
                                              color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                            ),),
                                          Text('  125K views',
                                            style: TextStyle(
                                              color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                            ),),
                                          Text('  3 weeks ago',
                                            style: TextStyle(
                                              color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                            ),),

                                        ],
                                      ),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment. spaceBetween,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Image.asset('assets/image/Unionnn.png',width:21.aw,height:21.ah,),
                                          SizedBox(width: 5.aw),
                                          Image.asset('assets/image/rename.png',width:22.aw,height:21.ah,),
                                          SizedBox(width: 5.aw),
                                          Image.asset('assets/image/bookmark.png',width:22.aw,height:21.ah,),

                                        ],
                                      )

                                    ],
                                  ),
                                ],
                              ),
                            ),

                          ],
                        ),
                      ),

                      SizedBox(height:20.ah),
                      Stack(
                        alignment: Alignment.topLeft,
                        children: [
                          Container(
                            height: 196.ah,width:MediaQuery.of(context).size.width,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(25),
                              // color: Colors.grey,
                              image: DecorationImage(
                                  alignment: Alignment.center,fit: BoxFit.fill,
                                  image: AssetImage('assets/image/Frame 21150.png')
                              ),

                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(left:10,right: 15,top: 10),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Icon(Icons.location_on,color: Colors.white,),
                                        // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                        Text('Sydney, Australia',
                                          style: TextStyle(
                                            color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                          ),),
                                      ],
                                    ),
                                    Image.asset('assets/image/more op.png',width:22.aw,height: 16.ah,),
                                  ],
                                ),
                                SizedBox(height: 60.ah),
                                Text('Circle'.tr,
                                  style: TextStyle(
                                      color: HexColor('#FFFFFF'),fontWeight: FontWeight.w700,fontSize:16.fSize,
                                      height:1.5
                                  ),
                                ),
                                SizedBox(height:10.ah),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          height: 24.ah,
                                          width: 24.aw,
                                          decoration: BoxDecoration(
                                            // borderRadius: BorderRadius.all(Radius.circular(35)),
                                              color: Color(0x305B5B5B),
                                              shape: BoxShape.circle,
                                              image: DecorationImage(
                                                fit: BoxFit.fill,
                                                image: AssetImage('assets/image/Ellipse 1.png'),
                                              )),
                                          // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                                        ),
                                        // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                        Text('   Kriston',
                                          style: TextStyle(
                                            color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                          ),),
                                        Text('  125K views',
                                          style: TextStyle(
                                            color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                          ),),
                                        Text('  3 weeks ago',
                                          style: TextStyle(
                                            color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                          ),),

                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment. spaceBetween,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Image.asset('assets/image/Unionnn.png',width:21.aw,height:21.ah,),
                                        SizedBox(width: 5.aw),
                                        Image.asset('assets/image/rename.png',width:22.aw,height:21.ah,),
                                        SizedBox(width: 5.aw),
                                        Image.asset('assets/image/bookmark.png',width:22.aw,height:21.ah,),
                                      ],
                                    )
                                  ],
                                ),
                              ],
                            ),
                          ),

                        ],
                      ),


                      SizedBox(height:20.ah),
                      Stack(
                        alignment: Alignment.topLeft,
                        children: [
                          Container(
                            height: 196.ah,width:MediaQuery.of(context).size.width,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(25),
                              // color: Colors.grey,
                              image: DecorationImage(
                                  alignment: Alignment.center,fit: BoxFit.fill,
                                  image: AssetImage('assets/image/Frame 21150.png')
                              ),

                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(left:10,right: 15,top: 10),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Icon(Icons.location_on,color: Colors.white,),
                                        // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                        Text('Sydney, Australia',
                                          style: TextStyle(
                                            color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                          ),),
                                      ],
                                    ),
                                    Image.asset('assets/image/more op.png',width:22.aw,height: 16.ah,),
                                  ],
                                ),
                                SizedBox(height: 60.ah),
                                Text('Circle'.tr,
                                  style: TextStyle(
                                      color: HexColor('#FFFFFF'),fontWeight: FontWeight.w700,fontSize:16.fSize,
                                      height:1.5
                                  ),
                                ),
                                SizedBox(height:10.ah),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          height: 24.ah,
                                          width: 24.aw,
                                          decoration: BoxDecoration(
                                            // borderRadius: BorderRadius.all(Radius.circular(35)),
                                              color: Color(0x305B5B5B),
                                              shape: BoxShape.circle,
                                              image: DecorationImage(
                                                fit: BoxFit.fill,
                                                image: AssetImage('assets/image/Ellipse 1.png'),
                                              )),
                                          // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                                        ),
                                        // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                        Text('   Kriston',
                                          style: TextStyle(
                                            color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                          ),),
                                        Text('  125K views',
                                          style: TextStyle(
                                            color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                          ),),
                                        Text('  3 weeks ago',
                                          style: TextStyle(
                                            color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                          ),),
                                      ],
                                    ),

                                    Row(
                                      mainAxisAlignment: MainAxisAlignment. spaceBetween,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Image.asset('assets/image/Unionnn.png',width:21.aw,height:21.ah,),
                                        SizedBox(width: 5.aw),
                                        Image.asset('assets/image/rename.png',width:22.aw,height:21.ah,),
                                        SizedBox(width: 5.aw),
                                        Image.asset('assets/image/bookmark.png',width:22.aw,height:21.ah,),

                                      ],
                                    )

                                  ],
                                ),
                              ],
                            ),
                          ),

                        ],
                      ),

                      SizedBox(height:20.ah),

                    ],
                  ),
                ),

                Container(
                  height: MediaQuery.of(context).size.width,
                  width: MediaQuery.of(context).size.width,),

                Container(
                  width:MediaQuery.of(context).size.width,
                  height: 229.ah,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                        bottomRight: Radius.circular(25),bottomLeft: Radius.circular(25)
                    ),
                    image: DecorationImage(
                      image: AssetImage('assets/image/Frame 21141.png'),
                      fit: BoxFit.fill,
                    ),
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.all(30.0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Image.asset('assets/image/arrow.png',height: 20.ah,width: 20.aw),

                      InkWell(
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context) => MyProfileVlog()));
                          },
                          child: Image.asset('assets/image/ic_settings_24px.png',height: 20.ah,width: 20.aw)),
                    ],
                  ),
                ),
                Positioned(
                    top: 135.ah,
                    left: 120.aw,
                    child: Center(
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Container(
                            width: 148.aw,
                            height: 148.ah,
                            //color: Colors.redAccent,
                            decoration: ShapeDecoration(
                              color: Colors.white,
                              shape: CircleBorder(),
                            )
                          ),

                          Container(
                              width: 140.aw,
                              height: 140.ah,
                              decoration: ShapeDecoration(
                                color: Colors.grey,
                                shape: CircleBorder(),
                                image: DecorationImage(
                                    fit: BoxFit.cover,
                                    image:
                                    //NetworkImage("${firestore.currentUser!.photoURL}"),
                                    AssetImage('assets/image/nick-andreka-XJWm6jERxcc-unsplash.jpg')
                                ),
                              )
                          ),
                        ],
                      )
                    )
                ),
              ],
            ),
          ],
        ),
      ),
      bottomNavigationBar: ClipRRect(
        borderRadius: BorderRadius.circular(50),
        child: Padding(
          padding: const EdgeInsets.only(left: 7,right: 7,bottom: 7),
          child: Container(
            height: 61.ah,
            decoration: BoxDecoration(
              border: Border.all(
                width: 1.5,color: Colors.grey,
              ),
              borderRadius: BorderRadius.circular(80),
              color: Color(0xff001649),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: <Widget>[
                IconButton(
                  icon: Icon(Icons.home,color: Colors.white,),
                  onPressed: () => DashBoardScreen(),
                ),
                // This is necessary to create space in the center
                IconButton(
                  icon:Image.asset('assets/image/Icon.png',height: 21.ah,width: 21.aw,color: Colors.white,),

                  // Icon(Icons.notifications),
                  onPressed: () => _onItemTapped(1),
                ),
                IconButton(
                  icon:Container(
                    height: 43.ah,
                    width: 43.aw,
                    decoration: BoxDecoration(
                      // borderRadius: BorderRadius.all(Radius.circular(35)),
                      color:Colors.white,
                      shape: BoxShape.circle,
                    ),
                    child:Center(child: Image.asset('assets/image/Union (1).png',height: 19.ah,width: 19.aw,)),
                    // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                  ),
                  // Image.asset('assets/image/plus.png'),
                  onPressed: () => _onItemTapped(2),
                ),
                IconButton(
                  icon:Image.asset('assets/image/Icon (1).png',height: 21.ah,width: 21.aw,color: Colors.white,),
                  onPressed: () => _onItemTapped(3),
                ),
                IconButton(
                  icon:Image.asset('assets/image/Vector.png',height: 21.ah,width: 21.aw,color: Colors.white,),
                  onPressed: () => _onItemTapped(4),
                ),
                // Image.asset('assets/image/Vector.png',height: 21.ah,width: 21.aw,color: Colors.white,)
              ],
            ),
          ),
        ),
      ),

     /* floatingActionButton:  Padding(
        padding: const EdgeInsets.all(15.0),
        child: Container(
          height: 61.ah,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(80),
            color: Color(0xff001649),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: <Widget>[
              IconButton(
                icon: InkWell(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => Demo_deshboardPage()));
                  },
                    child: Icon(Icons.home,color: Colors.white,)),
                onPressed: () => _onItemTapped(0),
              ),
              // This is necessary to create space in the center
              IconButton(
                icon:Image.asset('assets/image/Icon.png',height: 21.ah,width: 21.aw,color: Colors.white,),

                // Icon(Icons.notifications),
                onPressed: () => _onItemTapped(1),
              ),
              IconButton(
                icon:Container(
                  height: 43.ah,
                  width: 43.aw,
                  decoration: BoxDecoration(
                    // borderRadius: BorderRadius.all(Radius.circular(35)),
                    color:Colors.white,
                    shape: BoxShape.circle,
                  ),
                  child:Center(child: Image.asset('assets/image/Union (1).png',height: 19.ah,width: 19.aw,)),
                  // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                ),
                // Image.asset('assets/image/plus.png'),
                onPressed: () => _onItemTapped(2),
              ),
              IconButton(
                icon:Image.asset('assets/image/Icon (1).png',height: 21.ah,width: 21.aw,color: Colors.white,),
                onPressed: () => _onItemTapped(3),
              ),
              IconButton(
                icon:Image.asset('assets/image/Vector.png',height: 21.ah,width: 21.aw,color: Colors.white,),
                onPressed: () => _onItemTapped(4),
              ),
              // Image.asset('assets/image/Vector.png',height: 21.ah,width: 21.aw,color: Colors.white,)
            ],
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
*/
    );

    /*Scaffold(
    //  backgroundColor: Colors.grey.shade400,
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              alignment: Alignment.bottomCenter,
              children: [
                Container(
                  width: MediaQuery.of(context).size.width,
                  height: 217.ah,
                  decoration: BoxDecoration(
                      color: Colors.red,
                      image: DecorationImage(
                          alignment: Alignment.center,
                          fit: BoxFit.fill,
                          image: AssetImage('assets/image/girl.png')
                      ),
                      borderRadius:BorderRadius.only(
                          bottomRight: Radius.circular(25),
                          bottomLeft: Radius.circular(25)
                      )
        
                  ),
                ),
                // Align(
                //   alignment: Alignment.bottomCenter,
                //   child: Container(
                //     height: 150.ah,width: 150.aw,
                //     decoration: BoxDecoration(
                //       borderRadius: BorderRadius.all(Radius.circular(100)),
                //       //shape: BoxShape.circle,
                //       color: Colors.green,
                //
                //     ),
                //   ),
                // ),
        
              ],
            ),
        
            Padding(
              padding: const EdgeInsets.only(left: 10,right: 10,top: 20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Brett Pit',
                            style: TextStyle(
                                color: Colors.black,fontWeight: FontWeight.w600,fontSize:25
                            ),
                          ),
                          Text('bretiie',
                            style: TextStyle(
                                color: Colors.black54,fontWeight: FontWeight.w700,fontSize:15
                            ),
                          ),
        
                        ],
                      ),
                      Container(
                        height: 34.ah,width: 98.aw,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4),
                            color: HexColor('#001649')
                        ),
                        child:  Center(
                          child: Text('Follow',
                            style: TextStyle(
                                color: Colors.white,fontWeight: FontWeight.w500,fontSize:14.fSize
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
        
                  SizedBox(height: 10.ah),
                  Text('My name is Brett Pit and I enjoy meeting new \nMovies role into new',
                    style: TextStyle(height: 1.5,
                      color: Colors.grey,fontWeight: FontWeight.w400,fontSize:16.fSize,
                    ),
                  ),
        
                  SizedBox(height: 15.ah),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text('18',
                            style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w600,fontSize:16.fSize,
                            ),
                          ),
        
                          Text('Posts',
                            style: TextStyle(
                              color: Colors.grey,fontWeight: FontWeight.w500,fontSize:16.fSize,
                            ),
                          ),
                        ],
                      ),
        
                      Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text('517K',
                            style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w600,fontSize:16.fSize,
                            ),
                          ),
        
                          Text('Follower',
                            style: TextStyle(
                              color: Colors.grey,fontWeight: FontWeight.w500,fontSize:16.fSize,
                            ),
                          ),
                        ],
                      ),
        
                      Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text('5.3M',
                            style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w600,fontSize:16.fSize,
                            ),
                          ),
        
                          Text('Share',
                            style: TextStyle(
                              color: Colors.grey,fontWeight: FontWeight.w500,fontSize:16.fSize,
                            ),
                          ),
                        ],
                      ),
        
                    ],
                  ),
                  
                  SizedBox(height: 15.ah),
                  Container(
                    height: 52.ah,width: 358.aw,
                    decoration: BoxDecoration(
                      color: Colors.grey,
                      borderRadius: BorderRadius.circular(10)
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Container(
                            height: 40.ah,width:112.aw,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                color: HexColor('#001649')
                            ),
                            child:  Center(
                              child: Text('Vlogs',
                                style: TextStyle(
                                    color: Colors.white,fontWeight: FontWeight.w600,fontSize:18.fSize
                                ),
                              ),
                            ),
                          ),
        
                          Container(
                            height: 40.ah,width:112.aw,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                               // color: HexColor('#001649')
                            ),
                            child:  Center(
                              child: Text('Vlogs',
                                style: TextStyle(
                                    color: Colors.white,fontWeight: FontWeight.w500,fontSize:18.fSize
                                ),
                              ),
                            ),
                          ),
        
                          Container(
                            height: 40.ah,width:112.aw,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                               // color: HexColor('#001649')
                            ),
                            child:  Center(
                              child: Text('Vlogs',
                                style: TextStyle(
                                    color: Colors.white,fontWeight: FontWeight.w500,fontSize:18.fSize
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
        
                  SizedBox(height:20.ah),
                  Stack(
                    alignment: Alignment.topLeft,
                    children: [
                      Container(
                        height: 196.ah,width: 362.aw,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(25),
                          // color: Colors.grey,
                          image: DecorationImage(
                              alignment: Alignment.center,fit: BoxFit.fill,
                              image: AssetImage('assets/image/Frame 21150.png')
                          ),
        
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left:10,right: 15,top: 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Icon(Icons.location_on,color: Colors.white,),
                                    // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                    Text('Sydney, Australia',
                                      style: TextStyle(
                                        color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                      ),),
                                  ],
                                ),
                                Image.asset('assets/image/more op.png',width:22.aw,height: 16.ah,),
                              ],
                            ),
                            SizedBox(height: 60.ah),
                            Text('Circular Quay port are hubs of waterside '
                                '\nlife, with the arched Harbour Bridge',
                              style: TextStyle(
                                  color: HexColor('#FFFFFF'),fontWeight: FontWeight.w700,fontSize:16.fSize,
                                  height:1.5
                              ),
                            ),
                            SizedBox(height:10.ah),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      height: 24.ah,
                                      width: 24.aw,
                                      decoration: BoxDecoration(
                                        // borderRadius: BorderRadius.all(Radius.circular(35)),
                                          color: Color(0x305B5B5B),
                                          shape: BoxShape.circle,
                                          image: DecorationImage(
                                            fit: BoxFit.fill,
                                            image: AssetImage('assets/image/Ellipse 1.png'),
                                          )),
                                      // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                                    ),
                                    // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                    Text('   Kriston',
                                      style: TextStyle(
                                        color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                      ),),
                                    Text('  125K views',
                                      style: TextStyle(
                                        color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                      ),),
                                    Text('  3 weeks ago',
                                      style: TextStyle(
                                        color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                      ),),
        
                                  ],
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment. spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Image.asset('assets/image/Unionnn.png',width:21.aw,height:21.ah,),
                                    SizedBox(width: 5.aw),
                                    Image.asset('assets/image/rename.png',width:22.aw,height:21.ah,),
                                    SizedBox(width: 5.aw),
                                    Image.asset('assets/image/bookmark.png',width:22.aw,height:21.ah,),
        
                                  ],
                                )
        
                              ],
                            ),
                          ],
                        ),
                      ),
        
                    ],
                  ),
        
                  SizedBox(height:20.ah),
                  Stack(
                    alignment: Alignment.topLeft,
                    children: [
                      Container(
                        height: 196.ah,width: 362.aw,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(25),
                          // color: Colors.grey,
                          image: DecorationImage(
                              alignment: Alignment.center,fit: BoxFit.fill,
                              image: AssetImage('assets/image/Frame 21150.png')
                          ),

                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left:10,right: 15,top: 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Icon(Icons.location_on,color: Colors.white,),
                                    // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                    Text('Sydney, Australia',
                                      style: TextStyle(
                                        color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                      ),),
                                  ],
                                ),
                                Image.asset('assets/image/more op.png',width:22.aw,height: 16.ah,),
                              ],
                            ),
                            SizedBox(height: 60.ah),
                            Text('Circular Quay port are hubs of waterside '
                                '\nlife, with the arched Harbour Bridge',
                              style: TextStyle(
                                  color: HexColor('#FFFFFF'),fontWeight: FontWeight.w700,fontSize:16.fSize,
                                  height:1.5
                              ),
                            ),
                            SizedBox(height:10.ah),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      height: 24.ah,
                                      width: 24.aw,
                                      decoration: BoxDecoration(
                                        // borderRadius: BorderRadius.all(Radius.circular(35)),
                                          color: Color(0x305B5B5B),
                                          shape: BoxShape.circle,
                                          image: DecorationImage(
                                            fit: BoxFit.fill,
                                            image: AssetImage('assets/image/Ellipse 1.png'),
                                          )),
                                      // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                                    ),
                                    // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                    Text('   Kriston',
                                      style: TextStyle(
                                        color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                      ),),
                                    Text('  125K views',
                                      style: TextStyle(
                                        color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                      ),),
                                    Text('  3 weeks ago',
                                      style: TextStyle(
                                        color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                      ),),

                                  ],
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment. spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Image.asset('assets/image/Unionnn.png',width:21.aw,height:21.ah,),
                                    SizedBox(width: 5.aw),
                                    Image.asset('assets/image/rename.png',width:22.aw,height:21.ah,),
                                    SizedBox(width: 5.aw),
                                    Image.asset('assets/image/bookmark.png',width:22.aw,height:21.ah,),

                                  ],
                                )

                              ],
                            ),
                          ],
                        ),
                      ),

                    ],
                  ),


                  SizedBox(height:20.ah),
                  Stack(
                    alignment: Alignment.topLeft,
                    children: [
                      Container(
                        height: 196.ah,width: 362.aw,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(25),
                          // color: Colors.grey,
                          image: DecorationImage(
                              alignment: Alignment.center,fit: BoxFit.fill,
                              image: AssetImage('assets/image/Frame 21150.png')
                          ),

                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left:10,right: 15,top: 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Icon(Icons.location_on,color: Colors.white,),
                                    // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                    Text('Sydney, Australia',
                                      style: TextStyle(
                                        color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                      ),),
                                  ],
                                ),
                                Image.asset('assets/image/more op.png',width:22.aw,height: 16.ah,),
                              ],
                            ),
                            SizedBox(height: 60.ah),
                            Text('Circular Quay port are hubs of waterside '
                                '\nlife, with the arched Harbour Bridge',
                              style: TextStyle(
                                  color: HexColor('#FFFFFF'),fontWeight: FontWeight.w700,fontSize:16.fSize,
                                  height:1.5
                              ),
                            ),
                            SizedBox(height:10.ah),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      height: 24.ah,
                                      width: 24.aw,
                                      decoration: BoxDecoration(
                                        // borderRadius: BorderRadius.all(Radius.circular(35)),
                                          color: Color(0x305B5B5B),
                                          shape: BoxShape.circle,
                                          image: DecorationImage(
                                            fit: BoxFit.fill,
                                            image: AssetImage('assets/image/Ellipse 1.png'),
                                          )),
                                      // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                                    ),
                                    // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                    Text('   Kriston',
                                      style: TextStyle(
                                        color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                      ),),
                                    Text('  125K views',
                                      style: TextStyle(
                                        color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                      ),),
                                    Text('  3 weeks ago',
                                      style: TextStyle(
                                        color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                      ),),

                                  ],
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment. spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Image.asset('assets/image/Unionnn.png',width:21.aw,height:21.ah,),
                                    SizedBox(width: 5.aw),
                                    Image.asset('assets/image/rename.png',width:22.aw,height:21.ah,),
                                    SizedBox(width: 5.aw),
                                    Image.asset('assets/image/bookmark.png',width:22.aw,height:21.ah,),

                                  ],
                                )

                              ],
                            ),
                          ],
                        ),
                      ),

                    ],
                  ),

                  SizedBox(height:20.ah),
        
                ],
              ),
            )
          ],
        ),
      ),
    );*/
  }
}
