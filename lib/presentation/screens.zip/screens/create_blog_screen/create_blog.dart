import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:frenly_file/presentation/screens/edit_blog_screen/edit_blog_screen.dart';
import 'package:frenly_file/core/utils/size_utils.dart';
import '../../../core/constants/my_textfield.dart';
import 'package:get/get.dart';
class Create_Blog_Screen extends StatefulWidget {
  const Create_Blog_Screen({super.key});

  @override
  State<Create_Blog_Screen> createState() => _Create_Blog_ScreenState();
}

class _Create_Blog_ScreenState extends State<Create_Blog_Screen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

        title: Row(
          children: [
            Text('Create Blog'.tr,
              style: TextStyle(
                  color: Colors.black,fontWeight: FontWeight.w600,fontSize:20.fSize
              ),
            ),
          ],
        ),
        leading: Padding(
          padding:  EdgeInsets.only(left: 35.h),
          child: InkWell(
              onTap: () {
                Navigator.pop(context);
              },
              child: Icon(Icons.arrow_back_sharp)),
        ),
        backgroundColor: Colors.white,
        shadowColor: Colors.white,
        surfaceTintColor: Colors.white,

        elevation:3,
      ),

      body: Padding(
        padding: const EdgeInsets.only(left:20,right:20,top: 20),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Stack(
                alignment: Alignment.bottomRight,
                children: [
                  Container(
                    height: 185.ah,width: MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(25),
                      // color: Colors.grey,
                      image: DecorationImage(
                        // alignment: Alignment.center,
                          fit: BoxFit.fill,
                          image: AssetImage('assets/image/Frame 21150 (3).png')
                      ),),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Image.asset('assets/image/edit.png',height: 38.ah,width: 38.aw,fit: BoxFit.fill,),
                  ),],),

              SizedBox(height: 20.ah),
              Padding(
                padding: const EdgeInsets.only(left:10),
                child: Text('Title'.tr,
                  style: TextStyle(
                      color: Colors.black,fontWeight: FontWeight.w700,fontSize: 15.fSize
                  ),
                ),
              ),

              SizedBox(height: 10.ah,),
              primaryTextfield2(
                  hintText: 'lect'.tr,
                  controller: null
              ),

              SizedBox(height: 20.ah),
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: Text('Body'.tr,
                  style: TextStyle(
                      color: Colors.black,fontWeight: FontWeight.w700,fontSize: 15.fSize
                  ),),
              ),

              SizedBox(height: 10.ah,),
              primaryTextfield5(
                  hintText: 'Sowe'.tr,
                  controller: null),


              Center(
                child: CustomPrimaryBtn1(
                  title:'Postt'.tr,
                  isLoading: false,
                  onTap: () {
                    //Navigator.push(context, MaterialPageRoute(builder: (context) => Demo_deshboardPage()));
                    Navigator.push(context, MaterialPageRoute(builder: (context) => EditBlog_Screen()));
                  },
                ),
              ),

              //SizedBox(height: 50.ah),
            ],
          ),
        ),
      ),
    );
  }
}
