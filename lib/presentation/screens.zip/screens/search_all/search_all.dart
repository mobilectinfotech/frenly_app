// import 'dart:async';
//
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:frenly_file/core/utils/size_utils.dart';
//
// class Search_All extends StatefulWidget {
//   const Search_All({super.key});
//
//   @override
//   State<Search_All> createState() => _Search_AllState();
// }
// const colors = [
//   Color(0xFF001649),
//   Color(0xFF001649),
//   Color(0xFF001649),
//   Color(0xFF001649),
//   Color(0xFF001649),
// ];
// class _Search_AllState extends State<Search_All> {
//
//   late TabController tabController;
//   int _tabIndex = 0;
//   late var timer;
//   void initState() {
// // TODO: implement initState
//     super.initState();
//     if (mounted) {
//       TabBar(tabs: [],);
//       timer = new Timer.periodic(Duration(seconds: 60), (Timer t) => setState(() {}));
//     }
//   }
//   @override
//   void dispose() {
//     timer.cancel();
//     super.dispose();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return DefaultTabController(
//       length: 4,
//       child: Scaffold(
//         body: Column(
//           children: [
//             SizedBox(height: 50.ah,),
//             Container(
//               height:52.ah,
//               margin: const EdgeInsets.all(10),
//               decoration: BoxDecoration(
//                 borderRadius: const BorderRadius.all(Radius.circular(10)),
//                 //border: Border.all(width: 2),
//               ),
//               child: TabBar(
//                 indicatorWeight: 2,
//                 //controller: tabController,
//
//                 // indicator: BoxDecoration(
//                 //   borderRadius: BorderRadius.circular(20.0,),
//                 //   color: colors[_tabIndex],
//                 // ),
//
//               //  indicatorColor: Colors.transparent,
//                 //indicatorPadding: EdgeInsets.zero,
//                 //indicatorWeight: double.minPositive,
//
//                 labelStyle: const TextStyle(
//                     color: Colors.green,
//                     fontSize: 14,
//                     fontWeight: FontWeight.w600),
//                 //indicatorColor: Colors.green,
//
//                 unselectedLabelColor: Colors.red,
//                 //splashBorderRadius: BorderRadius.circular(20),
//                 padding: EdgeInsets.all(10),
//
//                 tabs: [
//
//                   Tab(
//                     //icon: Icon(Icons.chat_bubble),
//                     child: Container(
//                       //color: Colors.red,
//                       height: 50,
//                       width: 100,
//                       child: Center(child: Text('Vlog')),
//                     ),
//                   ),
//
//                   Tab(
//                     child: Container(
//                       //color: Colors.blue,
//                       height: 50,
//                       width: 100,
//                       child: Center(child: Text('Blog')),
//                     ),
//                   ),
//
//                   Tab(
//                     child: Container(
//                       //color: Colors.blue,
//                       height: 50,
//                       width: 100,
//                       child: Center(child: Text('Photo')),
//                     ),
//                   ),
//
//                   Tab(
//                     child: Container(
//                       //color: Colors.blue,
//                       height: 50,
//                       width: 100,
//                       child: Center(child: Text('Profile')),
//                     ),
//                   ),
//                 ],),
//             ),
//
//             Expanded(
//               child:  TabBarView(
//                 children: [
//                   ListView(
//                     children: [
//                       Container(
//                         child: Center(child: Text('bn')),
//                       ),
//                     ],
//                   ),
//
//                 /*  Center(
//                     child:  Container(
//                       height: 300,
//                       width: 300,
//                       child: Center(child: Text("one")),
//                       color: Colors.red,
//                     ),
//                   ),*/
//
//                   Center(
//                     child:  Container(
//                       height: 300,
//                       width: 300,
//                       child: Center(child: Text("Two")),
//                       color: Colors.blue,
//                     ),
//                   ),
//
//                   Center(
//                     child: Container(
//                       height: 300,
//                       width: 300,
//                       child: Center(child: Text("Three")),
//                       color: Colors.green,
//                     ),
//                   ),
//
//                   Center(
//                     child:  Container(
//                       height: 300,
//                       width: 300,
//                       child: Center(child: Text("one")),
//                       color: Colors.red,
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
