import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'datacontroller.dart';
import 'package:dio/dio.dart';

class DdataController extends GetxController {
  RxBool isLoadingDdata = false.obs;
  RxString inrest = "".obs;
  DATAMODEL? datamodel;

  @override
  void onInit() {
    super.onInit();
    Getadata();
  }

  Future<void> Getadata() async {
    isLoadingDdata(true);
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var token = prefs.get('token');
    var headers = {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Authorization': 'Bearer $token'
    };
    var data = {'family_id': '1'};
    print('Authorization===>"$token');
    var dio = Dio();
    var response = await dio.request(
      'http://3.104.197.136:4000/user/getFamilyMembers',
      options: Options(
        method: 'GET',
        headers: headers,
      ),
      data: data,
    );

    if (response.statusCode == 200) {
      datamodel = DATAMODEL.fromJson(response.data);
      print("datamodel===>${datamodel!.productInfo?.length}");
      isLoadingDdata.value = false;
    } else {
      print(response.statusMessage);
    }
  }
}
