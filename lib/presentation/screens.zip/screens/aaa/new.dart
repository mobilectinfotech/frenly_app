import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:frenly_file/core/utils/size_utils.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:get/get.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import '../create_password/create_password.dart';

class New extends StatefulWidget {
  const New({super.key});

  @override
  State<New> createState() => _NewState();
}

class _NewState extends State<New> {
  List<bool> active = [false, false, ];

  List<String> follow_Unfollow = [
    "Follow",
    "Unfollow",
  ];

  var selectone;
  late TabController tabController;
  int _tabIndex = 0;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length:4,
      child: Scaffold(
        backgroundColor: Colors.white,
        body: Padding(
          padding: const EdgeInsets.only(top:55),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
           // mainAxisSize: MainAxisSize.min,
            children: [

              Padding(
                padding: const EdgeInsets.only(left: 10,right: 10),
                child: Card(
                  color: Colors.white,
                  shadowColor: Colors.black,
                  surfaceTintColor: Colors.black,
                  child: Container(
                    // width: 293,
                    width: MediaQuery.of(context).size.width,
                    height:45,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: Color(0xFFe9eaec),
                      borderRadius: BorderRadius.circular(14),

                    ),
                    child: TextField(
                      cursorColor: Color(0xFF000000),
                      style: TextStyle(color: Colors.black),
                      decoration: InputDecoration(
                          prefixIcon: //Image.asset('assets/images/seearch.png',),
                          Icon(Icons.search, color: Colors.black,),
                          hintText:"Search".tr,
                          hintStyle: TextStyle(color:Colors.grey,fontSize:19.fSize,fontWeight: FontWeight.w500),
                          border: InputBorder.none),

                    ),
                  ),
                ),
              ),


              Container(
                height: 62.ah,
                width:MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                    color: Colors.white,
                    //color: Colors.black,
                    borderRadius: BorderRadius.circular(10)
                ),
                child: TabBar(
                  automaticIndicatorColorAdjustment: false,
                  indicatorColor: Colors.black,

                 // labelColor: Colors.blue,
                  //overlayColor: MaterialStateColor[Colors.purple],
                //  indicatorWeight: 1,
                  dividerColor: Colors.transparent,

                  // indicator: BoxDecoration(
                  //   borderRadius: BorderRadius.circular(20.0,),
                  //   color: colors[_tabIndex],
                  // ),


                  labelStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 15,
                      fontWeight: FontWeight.w500),
                  unselectedLabelColor: Colors.grey,
                  padding: EdgeInsets.all(10),
              
                  //indicatorColor: Colors.blueGrey,
                  // overlayColor: MaterialStateProperty.resolveWith<Color?>(
                  //       (Set<MaterialState> states) {
                  //     if (states.contains(MaterialState.hovered))
                  //       return Colors.red; //<-- SEE HERE
                  //     return null;
                  //   },
                  // ),
              
                  tabs: [
                    Tab(
                      //icon: Icon(Icons.chat_bubble),
                      child: Container(
                        height: 40,
                        width:MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                           //color: HexColor('#001649')
                        ),
                        child:  Center(
                          child: Text('Vlogs'.tr,
                            //style: TextStyle(color: Colors.grey,fontWeight: FontWeight.w600,fontSize:18.fSize),
                          ),
                        ),
                      ),
                    ),
              
                    Tab(
                      child: Container(
                        height: 40.ah,width:112.aw,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          // color: HexColor('#001649')
                        ),
                        child:  Center(
                          child: Text('Blogs'.tr,
                            // style: TextStyle(color: Colors.grey,fontWeight: FontWeight.w500,fontSize:18.fSize),
                          ),
                        ),),
                    ),
              
                    Tab(
                      child: Container(
                        height: 40.ah,width:112.aw,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          // color: HexColor('#001649')
                        ),
                        child:  Center(
                          child: Text('Photos'.tr,
                            //style: TextStyle(color: Colors.grey,fontWeight: FontWeight.w500,fontSize:18.fSize),
                          ),
                        ),
                      ),
                    ),

                    Tab(
                      //icon: Icon(Icons.chat_bubble),
                      child: Container(
                        height: 40,
                        width:MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          // color: HexColor('#001649')
                        ),
                        child:  Center(
                          child: Text('Profiles'.tr,
                            //style: TextStyle(color: Colors.grey,fontWeight: FontWeight.w600,fontSize:18.fSize),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              Expanded(
                child:  Padding(
                  padding: const EdgeInsets.only(left: 10,right: 10,),
                  child: TabBarView(
                    children: [

                      Vlogslist(),

                      Serchbloglist(),

                      GridView.builder(
                          itemCount: 18,
                          padding: EdgeInsets.only(bottom: 10,top: 10),
                          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 2,mainAxisExtent: 173,
                              mainAxisSpacing: 7,crossAxisSpacing: 7,),
                          itemBuilder: (context, index) {
                            return Container(
                              height: 158.ah,width: 173.aw,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(15),
                                  // color: Colors.green,
                                  image: DecorationImage(
                                      image: AssetImage('assets/image/girrrls.png'),
                                      fit: BoxFit.cover
                                  )
                              ),
                            );
                          }),

                      AccountList()
                    ],
                  ),
                ),
              ),

            ],
          ),
        ),
      ),
    );
  }
}

class Vlogslist extends StatelessWidget {
  const Vlogslist({super.key});

  @override
  Widget build(BuildContext context) {
    return  ListView.builder(
      shrinkWrap: true,
      scrollDirection: Axis.vertical,
      itemCount: 10,
      padding: EdgeInsets.only(bottom: 10),
      itemBuilder: (context, index) {
        return Padding(
          padding: const EdgeInsets.only(top: 10),
          child: Stack(
            alignment: Alignment.topLeft,
            children: [
              Container(
                height: 194.ah,width:MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(25),
                  // color: Colors.grey,
                  image: DecorationImage(
                      alignment: Alignment.center,fit: BoxFit.fill,
                      image: AssetImage('assets/image/Frame 21150.png')
                  ),

                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left:10,right: 15,top: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Icon(Icons.location_on,color: Colors.white,),
                            // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                            Text('Sydney, Australia',
                              style: TextStyle(
                                color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                              ),),
                          ],
                        ),
                        Image.asset('assets/image/more op.png',width:22.aw,height: 16.ah,),
                      ],
                    ),
                    SizedBox(height: 60.ah),
                    Text('Circle'.tr,
                      style: TextStyle(
                          color: HexColor('#FFFFFF'),fontWeight: FontWeight.w700,fontSize:16.fSize,
                          height:1.5
                      ),
                    ),
                    SizedBox(height:10.ah),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          height: 24.ah,
                          width: 24.aw,
                          decoration: BoxDecoration(
                            // borderRadius: BorderRadius.all(Radius.circular(35)),
                              color: Color(0x305B5B5B),
                              shape: BoxShape.circle,
                              image: DecorationImage(
                                fit: BoxFit.fill,
                                image: AssetImage('assets/image/Ellipse 1.png'),
                              )),
                          // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                        ),
                        // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                        Text('Kriston',
                          style: TextStyle(
                            color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                          ),),
                        Text('125K views',
                          style: TextStyle(
                            color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                          ),),
                        Text('3 days ago',
                          style: TextStyle(
                            color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                          ),),

                        SizedBox(width: 5.aw),
                          Image.asset('assets/image/like.png',width:21.aw,height:21.ah,),
                          SizedBox(width: 5.aw),
                          Image.asset('assets/image/cooment.png',width:21.aw,height:21.ah,),
                          SizedBox(width: 5.aw),
                          Image.asset('assets/image/share.png',width:22.aw,height:21.ah,),
                          SizedBox(width: 5.aw),
                          Image.asset('assets/image/bookmark.png',width:22.aw,height:21.ah,),

                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class Serchbloglist extends StatelessWidget {
  const Serchbloglist({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      shrinkWrap: true,
      scrollDirection: Axis.vertical,
      itemCount: 10,
      padding: EdgeInsets.only(bottom: 10),
      itemBuilder: (context, index) {
        return  Padding(
          padding: const EdgeInsets.only(top: 10,right: 5),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    height: 144.ah,width: 144.aw,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        image: DecorationImage(
                            image: AssetImage('assets/image/Frame 21150 (2).png')
                        )
                    ),
                  ),
                  SizedBox(width:5.aw,),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            height: 20.ah,width: 60.aw,
                            decoration: BoxDecoration(
                                border: Border.all(
                                    color: Colors.black,
                                    width: 0.3
                                ),
                                borderRadius: BorderRadius.circular(5),
                                color: Colors.grey.shade300
                            ),
                            child:  Center(
                              child: Text('Cooking'.tr,
                                style: TextStyle(
                                    color: Colors.grey,fontWeight: FontWeight.w500,fontSize:10.fSize
                                ),
                              ),
                            ),
                          ),

                        ],
                      ),
                      SizedBox(height: 5.ah),
                      Text('lect'.tr,
                        style: TextStyle(
                            color: Colors.black,fontWeight: FontWeight.w600,fontSize:20.fSize
                        ),
                      ),
                      SizedBox(height: 5.ah),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            height: 32.ah,
                            width: 32.aw,
                            decoration: BoxDecoration(
                              // borderRadius: BorderRadius.all(Radius.circular(35)),
                                color: Color(0x305B5B5B),
                                shape: BoxShape.circle,
                                image: DecorationImage(
                                  fit: BoxFit.fill,
                                  image: AssetImage('assets/image/Frame 427320834.png'),
                                )),
                            // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                          ),
                          SizedBox(width: 10.aw),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text('Naila Iman',
                                style: TextStyle(
                                  color: Colors.black,fontWeight: FontWeight.w600,fontSize:14.fSize,
                                ),),
                              Text('Kriston.3 weeks'.tr,
                                style: TextStyle(
                                  color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize,
                                ),),
                            ],
                          ),

                        ],
                      ),
                    ],
                  ),

                ],
              ),
              Image.asset('assets/image/more option.png',height: 16.ah,width: 4.aw,),

            ],
          ),
        );
      },
    );
  }
}

class AccountList extends StatelessWidget {
  const AccountList({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      shrinkWrap: true,
      scrollDirection: Axis.vertical,
      itemCount: 10,
      padding: EdgeInsets.only(bottom: 10,),
      itemBuilder: (context, index) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                height: 62.ah,
                width: 62.aw,
                decoration: BoxDecoration(
                  // borderRadius: BorderRadius.all(Radius.circular(35)),
                    color: Color(0x305B5B5B),
                    shape: BoxShape.circle,
                    image: DecorationImage(
                      fit: BoxFit.fill,
                      image: AssetImage('assets/image/Ellipse 1.png'),
                    )),
                // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
              ),
              SizedBox(width: 10.aw),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text('Jessie Alvarado',
                    style: TextStyle(
                      color: Colors.black,fontWeight: FontWeight.w700,fontSize:17.fSize,
                    ),),
                  Text('jessie5204',
                    style: TextStyle(
                      color: Colors.grey,fontWeight: FontWeight.w500,fontSize:15.fSize,
                    ),),
                ],
              ),


            ],
          ),
        );
      },
    );
  }
}

class Bott extends StatefulWidget {
  const Bott({super.key});

  @override
  State<Bott> createState() => _BottState();
}

class _BottState extends State<Bott> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: Container(
        height: 80,
        padding: EdgeInsets.all(8),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(50),
          child: CurvedNavigationBar(
              height: 50,
              backgroundColor: Colors.grey,
              color: Colors.white,
             // buttonBackgroundColor: Colors.grey.shade300,
             // onTap: OnTapped,
              items: <Widget>[
                Icon(Icons.home),
                Icon(Icons.search),
                Icon(Icons.settings),
                Icon(Icons.person)
              ]),

        ),

      ),
    );
  }
}

class BottomNavBarDemo extends StatefulWidget {
  @override
  _BottomNavBarDemoState createState() => _BottomNavBarDemoState();
}

class _BottomNavBarDemoState extends State<BottomNavBarDemo> {
  int _selectedIndex = 0;

  static const List<Widget> _widgetOptions = <Widget>[
    Text('Home Page'),
    Text('Search Page'),
    Text('Setting Page'),
    Text('Profile Page'),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Bottom Navigation Bar Demo'),
      ),
      body: Center(
        child: _widgetOptions.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: ClipRRect(
        borderRadius: BorderRadius.circular(80),
        child: BottomNavigationBar(
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              backgroundColor: Colors.red,
              icon: Icon(Icons.home),
              label: 'Home',

            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.search),
              label: 'Search',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.settings),
              label: 'Setting',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person),
              label: 'Profile',
            ),
          ],
          currentIndex: _selectedIndex,

          unselectedItemColor: Colors.black,
          selectedItemColor: Colors.blue,
          backgroundColor: Colors.red,
          onTap: _onItemTapped,
        ),
      ),
    );
  }
}