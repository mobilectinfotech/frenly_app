import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'datcontroller.dart';
import 'package:cached_network_image/cached_network_image.dart';

class GetDataScreen extends StatefulWidget {
  const GetDataScreen({super.key});

  @override
  State<GetDataScreen> createState() => _GetDataScreenState();
}

class _GetDataScreenState extends State<GetDataScreen> {

  DdataController ddataController = Get.put(DdataController());

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: Obx(() => ddataController.isLoadingDdata.value?Center(child: CircularProgressIndicator()):
       ddataController.datamodel!.productInfo!.isEmpty?Center(child: Text("No Data Found")):
        ListView.builder(
          itemCount:ddataController.datamodel!.productInfo!.length,
        itemBuilder: (BuildContext context, int index) {

            return Column(
              children: [
                Container(
                  height: 100,
                  width: 100,
                  child: CachedNetworkImage(
                    imageUrl: ddataController.datamodel!.productInfo![index].productImage.toString(),
                  )
                ),

               // Text('${ddataController.datamodel!.productInfo![index].productName}'),
                SizedBox(height: 20),
                //Text('${ddataController.datamodel!.productInfo![index].productName.toString()}')
              ],
            );
        },
      )
      )
    );
  }
}

