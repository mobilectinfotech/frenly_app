import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:frenly_file/presentation/screens/search_vlog/search_vlog.dart';
import 'package:frenly_file/core/utils/size_utils.dart';
import 'package:get/get.dart';
import '../../dashboard_screen/dashboard_screen.dart';
import '../search_accounts/search_account.dart';
import '../search_photos/search_photo_screen.dart';
import '../search_places/search_place.dart';

class SearchBlog_screen extends StatefulWidget {
  const SearchBlog_screen({super.key});

  @override
  State<SearchBlog_screen> createState() => _SearchBlog_screenState();
}

class _SearchBlog_screenState extends State<SearchBlog_screen> {
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.only(left: 10,right: 10,top:63),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Card(
                color: Colors.white,
                shadowColor: Colors.black,
                surfaceTintColor: Colors.black,
                child: Container(
                  // width: 293,
                  width: MediaQuery.of(context).size.width,
                  height:45,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: Color(0xFFe9eaec),
                    borderRadius: BorderRadius.circular(14),
                    //         boxShadow: [
                    //       BoxShadow(
                    //       color: Colors.white70,
                    //         offset: const Offset(
                    //           5.0,
                    //           5.0,
                    //         ),
                    //         blurRadius: 10.0,
                    //         spreadRadius: 2.0,
                    //       ), //BoxShadow
                    // BoxShadow(
                    //   color: Colors.white,
                    //   offset: const Offset(0.0, 0.0),
                    //   blurRadius: 0.0,
                    //   spreadRadius: 0.0,
                    // ), //BoxShadow
                    // ],

                    //BoxDecoration
                  ),
                  child: TextField(
                    cursorColor: Color(0xFF000000),
                    style: TextStyle(color: Colors.black),
                    decoration: InputDecoration(
                        prefixIcon: //Image.asset('assets/images/seearch.png',),
                        Icon(Icons.search, color: Colors.black,),
                        hintText: "Search".tr,
                        hintStyle: TextStyle(color:Colors.grey,fontSize:19.fSize,fontWeight: FontWeight.w500),
                        border: InputBorder.none),

                  ),
                ),
              ),
              SizedBox(height: 20.ah),
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  InkWell(
                    onTap: () {
                         Navigator.push(context, MaterialPageRoute(builder: (context) => SearchVlog_screen()));
                    },
                    child: Container(
                      padding: EdgeInsets.only(bottom: 3),
                      child: Text(
                        'Vlogs'.tr,
                        style: TextStyle(
                          color: Color(0xFF9C9C9C),
                          fontSize: 14.fSize,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w500,
                          height: 1.ah,

                          letterSpacing:1.ah,

                        ),),
                    ),
                  ),
                  SizedBox(width: 22.aw,),

                  Container(
                    padding: EdgeInsets.only(bottom: 3),
                    decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Colors.black, width: 1.0,))),
                    child: Text(
                      'Blogs'.tr,
                      style: TextStyle(
                        color: Color(0xFF9C9C9C),
                        fontSize: 14.fSize,
                        fontFamily: 'Inter',
                        fontWeight: FontWeight.w500,
                        height: 1,
                        //decorationColor: Colors.black,
                       // decoration: TextDecoration.underline,
                       // decorationThickness: 2,
                        //decorationStyle: TextDecorationStyle.solid,
                        letterSpacing: 0.65,
                      ),
                    ),
                  ),

                  SizedBox(width: 22.aw,),

                  InkWell(
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => SearchPhoto_Screen()));
                    },
                    child: Container(
                      padding: EdgeInsets.only(bottom: 3),
                      child: Text(
                        'Photos'.tr,
                        style: TextStyle(
                          color: Color(0xFF9C9C9C),
                          fontSize: 14.fSize,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w500,
                          height: 1,
                          letterSpacing: 0.65,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 22.aw,),

                  InkWell(
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => SearchAccount_Screen()));
                    },
                    child: Container(
                      padding: EdgeInsets.only(bottom: 3),
                      child: Text(
                        'Profiles'.tr,
                        style: TextStyle(
                          color: Color(0xFF9C9C9C),
                          fontSize: 14.fSize,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w500,
                          height: 1,
                          letterSpacing: 0.65,
                        ),
                      ),
                    ),
                  ),

                  /*SizedBox(width: 22.aw,),
                  InkWell(
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => SearchPlace_Screen()));
                    },
                    child: Container(
                      padding: EdgeInsets.only(bottom: 3),
                      child: Text(
                        'Places'.tr,
                        style: TextStyle(
                          color: Color(0xFF7F7F7F),
                          fontSize: 14.fSize,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w500,
                          height: 1,
                          letterSpacing: 0.65,
                        ),
                      ),
                    ),
                  )*/

                ],
              ),

              SizedBox(height: 25.ah),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        height: 144.ah,width: 144.aw,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(15),
                          image: DecorationImage(
                              image: AssetImage('assets/image/Frame 21150 (2).png')
                          )
                        ),
                      ),
                      SizedBox(width:5.aw,),
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                height: 20.ah,width: 60.aw,
                                decoration: BoxDecoration(
                                  border: Border.all(
                                    color: Colors.black,
                                    width: 0.3
                                  ),
                                    borderRadius: BorderRadius.circular(5),
                                    color: Colors.grey.shade300
                                ),
                                child:  Center(
                                  child: Text('Cooking'.tr,
                                    style: TextStyle(
                                        color: Colors.grey,fontWeight: FontWeight.w500,fontSize:10.fSize
                                    ),
                                  ),
                                ),
                              ),

                            ],
                          ),
                          SizedBox(height: 5.ah),
                          Text('letme'.tr,
                            style: TextStyle(
                                color: Colors.black,fontWeight: FontWeight.w600,fontSize:20.fSize
                            ),
                          ),
                          SizedBox(height: 5.ah),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                height: 32.ah,
                                width: 32.aw,
                                decoration: BoxDecoration(
                                  // borderRadius: BorderRadius.all(Radius.circular(35)),
                                    color: Color(0x305B5B5B),
                                    shape: BoxShape.circle,
                                    image: DecorationImage(
                                      fit: BoxFit.fill,
                                      image: AssetImage('assets/image/Frame 427320834.png'),
                                    )),
                                // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                              ),
                              SizedBox(width: 10.aw),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text('Naila Iman',
                                    style: TextStyle(
                                      color: Colors.black,fontWeight: FontWeight.w600,fontSize:14.fSize,
                                    ),),
                                  Text('Kriston.3 weeks'.tr,
                                    style: TextStyle(
                                      color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize,
                                    ),),
                                ],
                              ),

                            ],
                          ),
                        ],
                      ),

                    ],
                  ),
                  Image.asset('assets/image/more option.png',height: 16.ah,width: 4.aw,),

                ],
              ),

              SizedBox(height: 25.ah),


              SizedBox(height: 25.ah),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        height: 144.ah,width: 144.aw,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15),
                            image: DecorationImage(
                                image: AssetImage('assets/image/Frame 21150 (2).png')
                            )
                        ),
                      ),
                      SizedBox(width:5.aw,),
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                height: 20.ah,width: 60.aw,
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        color: Colors.black,
                                        width: 0.3
                                    ),
                                    borderRadius: BorderRadius.circular(5),
                                    color: Colors.grey.shade300
                                ),
                                child:  Center(
                                  child: Text('Cooking'.tr,
                                    style: TextStyle(
                                        color: Colors.grey,fontWeight: FontWeight.w500,fontSize:10.fSize
                                    ),
                                  ),
                                ),
                              ),

                            ],
                          ),
                          SizedBox(height: 5.ah),
                          Text('letme'.tr,
                            style: TextStyle(
                                color: Colors.black,fontWeight: FontWeight.w600,fontSize:20.fSize
                            ),
                          ),
                          SizedBox(height: 5.ah),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                height: 32.ah,
                                width: 32.aw,
                                decoration: BoxDecoration(
                                  // borderRadius: BorderRadius.all(Radius.circular(35)),
                                    color: Color(0x305B5B5B),
                                    shape: BoxShape.circle,
                                    image: DecorationImage(
                                      fit: BoxFit.fill,
                                      image: AssetImage('assets/image/Frame 427320834.png'),
                                    )),
                                // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                              ),
                              SizedBox(width: 10.aw),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text('Naila Iman',
                                    style: TextStyle(
                                      color: Colors.black,fontWeight: FontWeight.w600,fontSize:14.fSize,
                                    ),),
                                  Text('Kriston.3 weeks'.tr,
                                    style: TextStyle(
                                      color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize,
                                    ),),
                                ],
                              ),

                            ],
                          ),
                        ],
                      ),

                    ],
                  ),
                  Image.asset('assets/image/more option.png',height: 16.ah,width: 4.aw,),

                ],
              ),

              SizedBox(height: 25.ah),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        height: 144.ah,width: 144.aw,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15),
                            image: DecorationImage(
                                image: AssetImage('assets/image/Frame 21150 (2).png')
                            )
                        ),
                      ),
                      SizedBox(width:5.aw,),
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                height: 20.ah,width: 60.aw,
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        color: Colors.black,
                                        width: 0.3
                                    ),
                                    borderRadius: BorderRadius.circular(5),
                                    color: Colors.grey.shade300
                                ),
                                child:  Center(
                                  child: Text('Cooking'.tr,
                                    style: TextStyle(
                                        color: Colors.grey,fontWeight: FontWeight.w500,fontSize:10.fSize
                                    ),
                                  ),
                                ),
                              ),

                            ],
                          ),
                          SizedBox(height: 5.ah),
                          Text('letme'.tr,
                            style: TextStyle(
                                color: Colors.black,fontWeight: FontWeight.w600,fontSize:20.fSize
                            ),
                          ),
                          SizedBox(height: 5.ah),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                height: 32.ah,
                                width: 32.aw,
                                decoration: BoxDecoration(
                                  // borderRadius: BorderRadius.all(Radius.circular(35)),
                                    color: Color(0x305B5B5B),
                                    shape: BoxShape.circle,
                                    image: DecorationImage(
                                      fit: BoxFit.fill,
                                      image: AssetImage('assets/image/Frame 427320834.png'),
                                    )),
                                // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                              ),
                              SizedBox(width: 10.aw),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text('Naila Iman',
                                    style: TextStyle(
                                      color: Colors.black,fontWeight: FontWeight.w600,fontSize:14.fSize,
                                    ),),
                                  Text('Kriston.3 weeks'.tr,
                                    style: TextStyle(
                                      color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize,
                                    ),),
                                ],
                              ),

                            ],
                          ),
                        ],
                      ),

                    ],
                  ),
                  Image.asset('assets/image/more option.png',height: 16.ah,width: 4.aw,),

                ],
              ),

              SizedBox(height: 25.ah),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        height: 144.ah,width: 144.aw,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15),
                            image: DecorationImage(
                                image: AssetImage('assets/image/Frame 21150 (2).png')
                            )
                        ),
                      ),
                      SizedBox(width:5.aw,),
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                height: 20.ah,width: 60.aw,
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        color: Colors.black,
                                        width: 0.3
                                    ),
                                    borderRadius: BorderRadius.circular(5),
                                    color: Colors.grey.shade300
                                ),
                                child:  Center(
                                  child: Text('Cooking'.tr,
                                    style: TextStyle(
                                        color: Colors.grey,fontWeight: FontWeight.w500,fontSize:10.fSize
                                    ),
                                  ),
                                ),
                              ),

                            ],
                          ),
                          SizedBox(height: 5.ah),
                          Text('letme'.tr,
                            style: TextStyle(
                                color: Colors.black,fontWeight: FontWeight.w600,fontSize:20.fSize
                            ),
                          ),
                          SizedBox(height: 5.ah),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                height: 32.ah,
                                width: 32.aw,
                                decoration: BoxDecoration(
                                  // borderRadius: BorderRadius.all(Radius.circular(35)),
                                    color: Color(0x305B5B5B),
                                    shape: BoxShape.circle,
                                    image: DecorationImage(
                                      fit: BoxFit.fill,
                                      image: AssetImage('assets/image/Frame 427320834.png'),
                                    )),
                                // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                              ),
                              SizedBox(width: 10.aw),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text('Naila Iman',
                                    style: TextStyle(
                                      color: Colors.black,fontWeight: FontWeight.w600,fontSize:14.fSize,
                                    ),),
                                  Text('Kriston.3 weeks'.tr,
                                    style: TextStyle(
                                      color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize,
                                    ),),
                                ],
                              ),

                            ],
                          ),
                        ],
                      ),

                    ],
                  ),
                  Image.asset('assets/image/more option.png',height: 16.ah,width: 4.aw,),

                ],
              ),

            ],
          ),
        ),
      ),
      floatingActionButton:  Padding(
        padding: const EdgeInsets.all(15.0),
        child: Container(
          height: 61.ah,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(80),
            color: Color(0xff001649),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: <Widget>[
              IconButton(
                icon: InkWell(
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => DashBoardScreen()));
                    },
                    child: Icon(Icons.home,color: Colors.white,)),
                onPressed: () => _onItemTapped(0),
              ),
              // This is necessary to create space in the center
              IconButton(
                icon:Image.asset('assets/image/Icon.png',height: 21.ah,width: 21.aw,color: Colors.white,),

                // Icon(Icons.notifications),
                onPressed: () => _onItemTapped(1),
              ),
              IconButton(
                icon:Container(
                  height: 43.ah,
                  width: 43.aw,
                  decoration: BoxDecoration(
                    // borderRadius: BorderRadius.all(Radius.circular(35)),
                    color:Colors.white,
                    shape: BoxShape.circle,
                  ),
                  child:Center(child: Image.asset('assets/image/Union (1).png',height: 19.ah,width: 19.aw,)),
                  // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                ),
                // Image.asset('assets/image/plus.png'),
                onPressed: () => _onItemTapped(2),
              ),
              IconButton(
                icon:Image.asset('assets/image/Icon (1).png',height: 21.ah,width: 21.aw,color: Colors.white,),
                onPressed: () => _onItemTapped(3),
              ),
              IconButton(
                icon:Image.asset('assets/image/Vector.png',height: 21.ah,width: 21.aw,color: Colors.white,),
                onPressed: () => _onItemTapped(4),
              ),
              // Image.asset('assets/image/Vector.png',height: 21.ah,width: 21.aw,color: Colors.white,)
            ],
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
}
