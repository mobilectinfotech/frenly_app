import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:frenly_file/core/utils/size_utils.dart';
import '../../dashboard_screen/dashboard_screen.dart';
import '../onboard/onboard.dart';
import '../search_accounts/search_account.dart';
import '../search_blogs/search_blogs.dart';
import '../search_photos/search_photo_screen.dart';
import '../search_vlog/search_vlog.dart';
import 'package:get/get.dart';

class SearchPlace_Screen extends StatefulWidget {
  const SearchPlace_Screen({super.key});

  @override
  State<SearchPlace_Screen> createState() => _SearchPlace_ScreenState();
}

class _SearchPlace_ScreenState extends State<SearchPlace_Screen> {
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.only(left: 15,right: 15,top:63),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Card(
              color: Colors.white,
              shadowColor: Colors.black,
              surfaceTintColor: Colors.black,
              child: Container(
                // width: 293,
                width: MediaQuery.of(context).size.width,
                height:45,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: Color(0xFFe9eaec),
                  borderRadius: BorderRadius.circular(14),
                  //         boxShadow: [
                  //       BoxShadow(
                  //       color: Colors.white70,
                  //         offset: const Offset(
                  //           5.0,
                  //           5.0,
                  //         ),
                  //         blurRadius: 10.0,
                  //         spreadRadius: 2.0,
                  //       ), //BoxShadow
                  // BoxShadow(
                  //   color: Colors.white,
                  //   offset: const Offset(0.0, 0.0),
                  //   blurRadius: 0.0,
                  //   spreadRadius: 0.0,
                  // ), //BoxShadow
                  // ],

                  //BoxDecoration
                ),
                child: TextField(
                  cursorColor: Color(0xFF000000),
                  style: TextStyle(color: Colors.black),
                  decoration: InputDecoration(
                      prefixIcon: //Image.asset('assets/images/seearch.png',),
                      Icon(Icons.search, color: Colors.black,),
                      hintText: "Search".tr,
                      hintStyle: TextStyle(color:Colors.grey,fontSize:19.fSize,fontWeight: FontWeight.w500),
                      border: InputBorder.none),

                ),
              ),
            ),
            SizedBox(height: 20.ah),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                InkWell(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => OnBoard()));

                  },
                  child: Text(
                    'Vlogs'.tr,
                    style: TextStyle(
                      color: Color(0xFF9C9C9C),
                      fontSize: 14.fSize,
                      fontFamily: 'Inter',
                      fontWeight: FontWeight.w500,
                      height: 1.ah,
                      letterSpacing:1.ah,

                    ),),
                ),
                SizedBox(width: 22.aw,),

                InkWell(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => SearchBlog_screen()));
                  },
                  child: Text(
                    'Blogs'.tr,
                    style: TextStyle(
                      color: Color(0xFF9C9C9C),
                      fontSize: 14.fSize,
                      fontFamily: 'Inter',
                      fontWeight: FontWeight.w500,
                      height: 1,
                      letterSpacing: 0.65,
                    ),
                  ),
                ),

                SizedBox(width: 22.aw,),

                InkWell(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => SearchPhoto_Screen()));
                  },
                  child: Text(
                    'Photos'.tr,
                    style: TextStyle(
                      color: Color(0xFF9C9C9C),
                      fontSize: 14.fSize,
                      fontFamily: 'Inter',
                      fontWeight: FontWeight.w500,
                      height: 1,
                      letterSpacing: 0.65,
                    ),
                  ),
                ),
                SizedBox(width: 22.aw,),

                InkWell(
                  onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => SearchAccount_Screen()));
                  },
                  child: Text(
                    'Profiles'.tr,
                    style: TextStyle(
                      color: Color(0xFF9C9C9C),
                      fontSize: 14.fSize,
                      fontFamily: 'Inter',
                      fontWeight: FontWeight.w500,
                      height: 1,
                      letterSpacing: 0.65,
                    ),
                  ),
                ),
                SizedBox(width: 22.aw,),

                InkWell(
                  onTap: () {
                   // Navigator.push(context, MaterialPageRoute(builder: (context) => SearchPlace_Screen()));
                  },
                  child: Container(
                    padding: EdgeInsets.only(bottom: 3),
                    decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Colors.black, width: 1.0,))),
                    child: Text(
                      'Places'.tr,
                      style: TextStyle(
                        color: Color(0xFF7F7F7F),
                        fontSize: 14.fSize,
                        fontFamily: 'Inter',
                        fontWeight: FontWeight.w500,
                        height: 1,
                        // decorationColor: Colors.black,
                        // decoration: TextDecoration.underline,
                        // decorationThickness: 2,
                        // decorationStyle: TextDecorationStyle.solid,
                        letterSpacing: 0.65,
                      ),
                    ),
                  ),
                )
              ],
            ),

            SearchPlace_list(),
            
          ],
        ),
      ),
      floatingActionButton:  Padding(
        padding: const EdgeInsets.all(15.0),
        child: Container(
          height: 61.ah,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(80),
            color: Color(0xff001649),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: <Widget>[
              IconButton(
                icon: InkWell(
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => DashBoardScreen()));
                    },
                    child: Icon(Icons.home,color: Colors.white,)),
                onPressed: () => _onItemTapped(0),
              ),
              // This is necessary to create space in the center
              IconButton(
                icon:Image.asset('assets/image/Icon.png',height: 21.ah,width: 21.aw,color: Colors.white,),

                // Icon(Icons.notifications),
                onPressed: () => _onItemTapped(1),
              ),
              IconButton(
                icon:Container(
                  height: 43.ah,
                  width: 43.aw,
                  decoration: BoxDecoration(
                    // borderRadius: BorderRadius.all(Radius.circular(35)),
                    color:Colors.white,
                    shape: BoxShape.circle,
                  ),
                  child:Center(
                      child: Image.asset('assets/image/Union (1).png',height: 19.ah,width: 19.aw,)),
                  // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                ),
                // Image.asset('assets/image/plus.png'),
                onPressed: () => _onItemTapped(2),
              ),
              IconButton(
                icon:Image.asset('assets/image/Icon (1).png',height: 21.ah,width: 21.aw,color: Colors.white,),
                onPressed: () => _onItemTapped(3),
              ),
              IconButton(
                icon:Image.asset('assets/image/Vector.png',height: 21.ah,width: 21.aw,color: Colors.white,),
                onPressed: () => DashBoardScreen(),
              ),
              // Image.asset('assets/image/Vector.png',height: 21.ah,width: 21.aw,color: Colors.white,)
            ],
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
}


class SearchPlace_list extends StatelessWidget {
  const SearchPlace_list({super.key});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        width: MediaQuery.of(context).size.width,
        height: 105.ah,
        child: ListView.builder(
          shrinkWrap: true,
          scrollDirection: Axis.vertical,
          itemCount: 10,
          itemBuilder: (context, index) {
            return Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    height: 54.ah,
                    width: 54.aw,
                    decoration: BoxDecoration(
                      // borderRadius: BorderRadius.all(Radius.circular(35)),
                        color: Colors.white,
                        shape: BoxShape.circle,
                        border: Border.all(
                          width: 0.5,color: Colors.black
                        )

                        // image: DecorationImage(
                        //   fit: BoxFit.fill,
                        //   image: AssetImage('assets/image/Frame 427320834.png'),
                        // )

                    ),
                    child: Center(child: Image.asset('assets/image/location-outline.png',height: 21.ah,width: 15.aw,color: Colors.black,fit: BoxFit.fill,)),
                    // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                  ),
                  SizedBox(width: 10.aw),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text('Jessie Alvarado',
                        style: TextStyle(
                          color: Colors.black,fontWeight: FontWeight.w700,fontSize:17.fSize,
                        ),),
                      Text('jessie5204',
                        style: TextStyle(
                          color: Colors.grey,fontWeight: FontWeight.w500,fontSize:15.fSize,
                        ),),
                    ],
                  ),

                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
