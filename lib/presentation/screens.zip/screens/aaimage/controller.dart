import 'package:get/get.dart';
import 'package:http/http.dart' as http;

class ProfileController extends GetxController {
  Future<void> editProfile(String name, String email) async {
    try {
      var url = Uri.parse('https://example.com/api/edit_profile_screen');
      var response = await http.post(
        url,
        body: {'name': name, 'email': email},
        // You can add headers or other parameters as needed
      );

      if (response.statusCode == 200) {
        // Handle success
        print('Profile updated successfully');
      } else {
        // Handle error
        print('Failed to update profile');
      }
    } catch (e) {
      // Handle exception
      print('Error: $e');
    }
  }
}
