import 'package:flutter/material.dart';
import 'package:frenly_file/core/constants/my_textfield.dart';
import 'package:frenly_file/presentation/screens/aaimage/controller.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
/*class EditProfilePage extends StatelessWidget {
  final ProfileController profileController = Get.put(ProfileController());

  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Edit Profile'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextFormField(
              controller: nameController,
              decoration: InputDecoration(labelText: 'Name'),
            ),
            SizedBox(height: 20),
            TextFormField(
              controller: emailController,
              decoration: InputDecoration(labelText: 'Email'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () async {
                await profileController.editProfile(
                  nameController.text,
                  emailController.text,
                );
              },
              child: Text('Save'),
            ),
          ],
        ),
      ),
    );
  }
}*/



class SharedPreferencesDemo extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('SharedPreferences Demo'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            primaryTextfield1(
              hintText: 'john smith',
              controller:null,
              // validator:Validator.validateFullName,
            ),
            ElevatedButton(
              onPressed: () async {
                await saveDataa();
              },
              child: Text('Save Data'),
            ),
            ElevatedButton(
              onPressed: () async {
                await readData();
              },
              child: Text('Read Data'),
            ),
            ElevatedButton(
              onPressed: () async {
                await deleteData();
              },
              child: Text('Delete Data'),
            ),
          ],
        ),
      ),
    );
  }

  // Future<void> saveData() async {
  //   SharedPreferences prefs = await SharedPreferences.getInstance();
  //   await prefs.setString('key', 'value');
  // }

  Future<void> saveDataa() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString('username', 'JohnDoe');
    prefs.setInt('age', 30);
    prefs.setBool('isLogged', true);
  }

  Future<void> readData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? value = prefs.getString('key');
    if (value != null) {
      print('Value: $value');
    } else {
      print('Value not found');
    }
  }

  Future<void> deleteData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove('key');
  }
}
