import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:frenly_file/presentation/screens/saved_blog/saved_blog.dart';
import 'package:frenly_file/presentation/screens/saved_people_profile/saved_people_profile.dart';
import 'package:frenly_file/presentation/screens/saved_vlogs/saved_vlogs.dart';
import 'package:frenly_file/core/utils/size_utils.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:get/get.dart';

class SavedPhoto_Screen extends StatefulWidget {
  const SavedPhoto_Screen({super.key});

  @override
  State<SavedPhoto_Screen> createState() => _SavedPhoto_ScreenState();
}

class _SavedPhoto_ScreenState extends State<SavedPhoto_Screen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        surfaceTintColor: Colors.white,
        backgroundColor: Colors.white,
        title: Row(
          children: [
            Text('Fashion'.tr,
              style: TextStyle(
                  color: Colors.black,fontWeight: FontWeight.w700,fontSize:32.fSize
              ),
            ),
          ],
        ),
        leading: Padding(
          padding:  EdgeInsets.only(left: 15.h),
          child: InkWell(
              onTap: () {
                Navigator.pop(context);
              },
              child: Icon(Icons.arrow_back_sharp)),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              height: 36.ah,
              width: 36.aw,
              decoration: BoxDecoration(
                // borderRadius: BorderRadius.all(Radius.circular(35)),
                  color: Color(0x305B5B5B),
                  shape: BoxShape.circle,
                  image: DecorationImage(
                    fit: BoxFit.fill,
                    image: AssetImage('assets/image/Ellipse 1.png'),
                  )),
              // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
            ),
          ),
        ],
      ),

      body: Padding(
        padding: const EdgeInsets.only(left: 10,right: 10,top:20),
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                height: 52.ah,width: 358.aw,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10)
                ),
                child: Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      InkWell(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => Save_Vlogs_Screen()));
                        },
                        child: Container(
                          height: 40.ah,width:83.aw,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                            // color: HexColor('#001649')
                          ),
                          child:  Center(
                            child: Text('Vlogs'.tr,
                              style: TextStyle(
                                  color: Colors.grey,fontWeight: FontWeight.w600,fontSize:18.fSize
                              ),
                            ),
                          ),
                        ),
                      ),

                      InkWell(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => Saved_Blog_screen()));
                        },
                        child: Container(
                          height: 40.ah,width:83.aw,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                            //color: HexColor('#001649')
                          ),
                          child:  Center(
                            child: Text('Blogs'.tr,
                              style: TextStyle(
                                  color: Colors.grey,fontWeight: FontWeight.w500,fontSize:18.fSize
                              ),
                            ),
                          ),
                        ),
                      ),

                      Container(
                        height: 40.ah,width:83.aw,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          color: HexColor('#001649')
                        ),
                        child:  Center(
                          child: Text('Photos'.tr,
                            style: TextStyle(
                                color: Colors.white,fontWeight: FontWeight.w500,fontSize:18.fSize
                            ),
                          ),
                        ),
                      ),

                      InkWell(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => SavedPeople_profile()));
                        },
                        child: Container(
                          height: 40.ah,width:83.aw,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                              //color: HexColor('#001649')
                          ),
                          child:  Center(
                            child: Text('Profiles'.tr,
                              style: TextStyle(
                                  color: Colors.grey,fontWeight: FontWeight.w500,fontSize:18.fSize
                              ),),

                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              //SizedBox(height: 10.ah),
             // Text('Vlogs', style: TextStyle(color: Colors.black,fontWeight: FontWeight.w600,fontSize: 24.fSize),),

              SizedBox(height: 20.ah),
             // SavedBlog()
               Expanded(
            child: GridView.builder(
                itemCount: 18,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,mainAxisExtent: 120,
                    mainAxisSpacing: 5,crossAxisSpacing: 5
                ),
                itemBuilder: (context, index) {
                  return Container(
                    height: 120.ah,width: 120.aw,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        // color: Colors.green,
                        image: DecorationImage(
                            image: AssetImage('assets/image/girrrls.png'),
                            fit: BoxFit.cover
                        )
                    ),
                  );
                }),
          ),
            ]
        ),
      ),
    );
  }
}

