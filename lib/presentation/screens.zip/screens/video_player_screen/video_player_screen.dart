import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:frenly_file/presentation/screens/full_screen/full_screen_page.dart';
import 'package:frenly_file/core/utils/size_utils.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:get/get.dart';

import '../../dashboard_screen/dashboard_screen.dart';

class VideoPlayer extends StatefulWidget {
  const VideoPlayer({super.key});

  @override
  State<VideoPlayer> createState() => _VideoPlayerState();
}

class _VideoPlayerState extends State<VideoPlayer> {
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  List<bool> active = [false, false, ];
  List<String> follow_Unfollow = [
    "Follow",
    "Unfollow",
  ];
  var selectone;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.only(left:15,right:15,top: 50),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              InkWell(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => FullScreenPage()));
                },
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: 217.ah,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      image: DecorationImage(
                          alignment: Alignment.center,
                          fit: BoxFit.fill,
                          image: AssetImage('assets/image/Frame 21150 (1).png')
                      ),
                      borderRadius:BorderRadius.only(
                        topLeft: Radius.circular(25),
                          topRight: Radius.circular(25),
                          bottomRight: Radius.circular(25),
                          bottomLeft: Radius.circular(25)
                      )

                  ),
                ),
              ),
          
              SizedBox(height: 20.ah),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Container(
                        height: 46.ah,
                        width: 46.aw,
                        decoration: BoxDecoration(
                          // borderRadius: BorderRadius.all(Radius.circular(35)),
                            color: Color(0x305B5B5B),
                            shape: BoxShape.circle,
                            image: DecorationImage(
                              fit: BoxFit.fill,
                              image: AssetImage('assets/image/Ellipse 1.png'),
                            )),
                        // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                      ),
                      SizedBox(width: 10),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('lect'.tr,
                            style: TextStyle(
                                color: Colors.black,fontWeight: FontWeight.w600,fontSize:16.fSize
                            ),
                          ),

                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [

                              // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                              Text('Kriston',
                                style: TextStyle(
                                  color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize,
                                ),),
                              Text('  125K views',
                                style: TextStyle(
                                  color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize,
                                ),),
                              Text('3 week',
                                style: TextStyle(
                                  color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize,
                                ),),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                  InkWell(
                    onTap: () {
                      showModalBottomSheet(
                          context: context,
                          backgroundColor: Colors.white,
                          builder: (context) {
                            return Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                SizedBox(height: 15.ah),
                                ListTile(
                                  leading: Image.asset('assets/image/share (1).png',height:38.ah,width:38.aw,fit: BoxFit.fill,),
                                  title: Text('Share'.tr,
                                    style: TextStyle(
                                        color: Colors.black,fontWeight: FontWeight.w600,fontSize:16
                                    ),),
                                  onTap: () {
                                    Navigator.pop(context);
                                  },
                                ),

                                ListTile(
                                  leading: Image.asset('assets/image/delete (1).png',height:38.ah,width:38.aw,fit: BoxFit.fill,),
                                  title: Text('Delete'.tr,
                                    style: TextStyle(
                                        color: Colors.black,fontWeight: FontWeight.w600,fontSize:16
                                    ),),
                                  onTap: () {
                                    Navigator.pop(context);
                                  },
                                ),
                              ],
                            );
                          });
                    },
                      child: Image.asset('assets/image/more option.png',height: 16.ah,width: 10.aw,)),
                ],
              ),
          
              SizedBox(height: 20.ah),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text('517K',
                        style: TextStyle(
                            color: Colors.black,fontWeight: FontWeight.w700,fontSize:16.fSize
                        ),
                      ),
                      SizedBox(width: 10.aw),
                      Text('Followers'.tr,
                        style: TextStyle(
                            color: Colors.grey,fontWeight: FontWeight.w600,fontSize:16.fSize
                        ),
                      ),
                    ],
                  ),
                  Image.asset('assets/image/Vector (3).png',width:19.aw,height:17.ah,color: Colors.black,fit: BoxFit.fill),

                  Image.asset('assets/image/Uniiion.png',width:21.aw,height:21.ah,color: Colors.black,fit: BoxFit.fill,),
                  //SizedBox(width: 5.aw),
                  Image.asset('assets/image/Vector (2).png',width:14.aw,height:18.ah,color: Colors.black,fit: BoxFit.fill),

                  // SizedBox(width: 5.aw),
                  InkWell(
                    onTap: () {
                      active[0] = !active[0];
                      setState(() {
                        follow_Unfollow[0] = "Follow".tr;
                      },
                      );
                    },
                    child: Container(
                      height: 34.ah,width: 98.aw,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(4),
                        color:  active[0] ? Colors.red : HexColor('#001649'),
                        //HexColor('#001649')
                      ),
                      child:  Center(
                        child: Text(active[0] ?'Unfollow'.tr:'Follow'.tr,
                          style: TextStyle(
                              color: active[0] ? Colors.white : Colors.white,
                              fontWeight: FontWeight.w500,fontSize:14.fSize
                          ),
                        ),
                      ),
                    ),
                  )
          
                ],
              ),
          
              SizedBox(height: 20.ah),
             /* Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: 223.ah,width: 115.aw,
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(7),
                        border: Border.all(
                          //color: HexColor('#FFFFFF'),
                            color: Colors.black12,
                            width:1
                        )
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                            height: 100.ah,width: 100.aw,
                            decoration: ShapeDecoration(
                                color: Colors.white,
                                shape: CircleBorder(),
                                image: DecorationImage(
                                    image: AssetImage('assets/image/girrrls.png'),
                                    fit: BoxFit.cover
                                )
                            )
                        ),
                        SizedBox(height:2.ah),
                        Text('Rose celebs',
                          style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w500,fontSize:13.fSize
                          ),
                        ),

                        SizedBox(height:2.ah),
                        Text('rose_ce',
                          style: TextStyle(
                              color: Colors.grey,fontWeight: FontWeight.w600,fontSize:12.fSize
                          ),
                        ),

                        SizedBox(height:2.ah),
                        Text('27M',
                          style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w500,fontSize:12.fSize
                          ),
                        ),


                        SizedBox(height:10.ah),
                        InkWell(
                          onTap:  () {
                            active[0] = !active[0];
                            // setState(() {
                            //   follow_Unfollow[0] = "Follow ";
                            // },);
                          },
                          child: Container(
                            height: 24.ah,width: 98.aw,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4),
                              color: active[0] ? Colors.red : HexColor('#001649'),
                            ),
                            child:  Center(
                              child: Text(active[0] ?'Unfollow'.tr:'Follow'.tr,
                                style: TextStyle(
                                    color: active[0] ? Colors.white : Colors.white,
                                    fontWeight: FontWeight.w500,fontSize:14.fSize
                                ),
                              ),
                            ),
                          ),
                        )

                      ],
                    ),
                  ),

                  Container(
                    height: 223.ah,width: 115.aw,
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(7),
                        border: Border.all(
                          //color: HexColor('#FFFFFF'),
                            color: Colors.black12,
                            width:1
                        )
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                            height: 100.ah,width: 100.aw,
                            decoration: ShapeDecoration(
                                color: Colors.white,
                                shape: CircleBorder(),
                                image: DecorationImage(
                                    image: AssetImage('assets/image/girrrls.png'),
                                    fit: BoxFit.cover
                                )
                            )
                        ),
                        SizedBox(height:2.ah),
                        Text('Rose celebs',
                          style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w500,fontSize:13.fSize
                          ),
                        ),

                        SizedBox(height:2.ah),
                        Text('rose_ce',
                          style: TextStyle(
                              color: Colors.grey,fontWeight: FontWeight.w600,fontSize:12.fSize
                          ),
                        ),

                        SizedBox(height:2.ah),
                        Text('27M',
                          style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w500,fontSize:12.fSize
                          ),
                        ),


                        SizedBox(height:10.ah),
                        InkWell(
                          onTap:  () {
                            active[0] = !active[0];
                            // setState(() {
                            //   follow_Unfollow[0] = "Follow ";
                            // },);
                          },
                          child: Container(
                            height: 24.ah,width: 98.aw,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4),
                              color: active[0] ? Colors.red : HexColor('#001649'),
                            ),
                            child:  Center(
                              child: Text(active[0] ?'Unfollow'.tr:'Follow'.tr,
                                style: TextStyle(
                                    color: active[0] ? Colors.white : Colors.white,
                                    fontWeight: FontWeight.w500,fontSize:14.fSize
                                ),
                              ),
                            ),
                          ),
                        )

                      ],
                    ),
                  ),

                  Container(
                    height: 223.ah,width: 115.aw,
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(7),
                        border: Border.all(
                          //color: HexColor('#FFFFFF'),
                            color: Colors.black12,
                            width:1
                        )
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                            height: 100.ah,width: 100.aw,
                            decoration: ShapeDecoration(
                                color: Colors.white,
                                shape: CircleBorder(),
                                image: DecorationImage(
                                    image: AssetImage('assets/image/girrrls.png'),
                                    fit: BoxFit.cover
                                )
                            )
                        ),
                        SizedBox(height:2.ah),
                        Text('Rose celebs',
                          style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w500,fontSize:13.fSize
                          ),
                        ),

                        SizedBox(height:2.ah),
                        Text('rose_ce',
                          style: TextStyle(
                              color: Colors.grey,fontWeight: FontWeight.w600,fontSize:12.fSize
                          ),
                        ),

                        SizedBox(height:2.ah),
                        Text('27M',
                          style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w500,fontSize:12.fSize
                          ),
                        ),


                        SizedBox(height:10.ah),
                        InkWell(
                          onTap:  () {
                            active[0] = !active[0];
                            // setState(() {
                            //   follow_Unfollow[0] = "Follow ";
                            // },);
                          },
                          child: Container(
                            height: 24.ah,width: 98.aw,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4),
                              color: active[0] ? Colors.red : HexColor('#001649'),
                            ),
                            child:  Center(
                              child: Text(active[0] ?'Unfollow'.tr:'Follow'.tr,
                                style: TextStyle(
                                    color: active[0] ? Colors.white : Colors.white,
                                    fontWeight: FontWeight.w500,fontSize:14.fSize
                                ),
                              ),
                            ),
                          ),
                        )

                      ],
                    ),
                  ),

                 *//* Container(
                    height: 223.ah,width: 115.aw,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(7),
                        border: Border.all(
                          //color: HexColor('#FFFFFF'),
                            color: Colors.black12,
                            width:1
                        )
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Container(
                          height: 109.ah,width: 120.aw,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(100),
                              // color: Colors.green,
                              image: DecorationImage(
                                  image: AssetImage('assets/image/Frame 1752.png')
                              )
                          ),
                        ),
                        Text('Brett Pit',
                          style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w500,fontSize:13.fSize
                          ),
                        ),
                        Text('bretiie',
                          style: TextStyle(
                              color: Colors.grey,fontWeight: FontWeight.w600,fontSize:12.fSize
                          ),
                        ),
                        Text('27M',
                          style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w500,fontSize:12.fSize
                          ),
                        ),

                        Container(
                          height: 24.ah,width: 98.aw,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4),
                              color: HexColor('#001649')
                          ),
                          child:  Center(
                            child: Text('Follow'.tr,
                              style: TextStyle(
                                  color: Colors.white,fontWeight: FontWeight.w500,fontSize:14.fSize
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 1.ah)

                      ],
                    ),
                  ),
          
                  Container(
                    height: 223.ah,width: 115.aw,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(7),
                        border: Border.all(
                          //color: HexColor('#FFFFFF'),
                            color: Colors.black12,
                            width:1
                        )
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Container(
                          height: 109.ah,width: 120.aw,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(100),
                              // color: Colors.green,
                              image: DecorationImage(
                                  image: AssetImage('assets/image/Frame 1752.png')
                              )
                          ),
                        ),
                        Text('Brett Pit',
                          style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w500,fontSize:13.fSize
                          ),
                        ),
                        Text('bretiie',
                          style: TextStyle(
                              color: Colors.grey,fontWeight: FontWeight.w600,fontSize:12.fSize
                          ),
                        ),
                        Text('27M',
                          style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w500,fontSize:12.fSize
                          ),
                        ),
          
                        Container(
                          height: 24.ah,width: 98.aw,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4),
                              color: HexColor('#001649')
                          ),
                          child:  Center(
                            child: Text('Follow'.tr,
                              style: TextStyle(
                                  color: Colors.white,fontWeight: FontWeight.w500,fontSize:14.fSize
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 1.ah)
          
                      ],
                    ),
                  ),
          
                  Container(
                    height: 223.ah,width: 115.aw,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(7),
                        border: Border.all(
                          //color: HexColor('#FFFFFF'),
                            color: Colors.black12,
                            width:1
                        )
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Container(
                          height: 109.ah,width: 120.aw,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(100),
                              // color: Colors.green,
                              image: DecorationImage(
                                  image: AssetImage('assets/image/Frame 1752.png')
                              )
                          ),
                        ),
                        Text('Brett Pit',
                          style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w500,fontSize:13.fSize
                          ),
                        ),
                        Text('bretiie',
                          style: TextStyle(
                              color: Colors.grey,fontWeight: FontWeight.w600,fontSize:12.fSize
                          ),
                        ),
                        Text('27M',
                          style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w500,fontSize:12.fSize
                          ),
                        ),
          
                        Container(
                          height: 24.ah,width: 98.aw,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4),
                              color: HexColor('#001649')
                          ),
                          child:  Center(
                            child: Text('Follow'.tr,
                              style: TextStyle(
                                  color: Colors.white,fontWeight: FontWeight.w500,fontSize:14.fSize
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 1.ah)
          
                      ],
                    ),
                  ),
          *//*
                ],
              ),*/

              Discover1(),
          
              SizedBox(height: 20.ah),
              Stack(
                alignment: Alignment.topLeft,
                children: [
                  Container(
                    height: 196.ah,width:MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(25),
                      // color: Colors.grey,
                      image: DecorationImage(
                          alignment: Alignment.center,fit: BoxFit.fill,
                          image: AssetImage('assets/image/Frame 21150.png')
                      ),
          
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left:10,right: 15,top: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Icon(Icons.location_on,color: Colors.white,),
                                // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                Text('Sydney, Australia',
                                  style: TextStyle(
                                    color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                  ),),
                              ],
                            ),
                            Image.asset('assets/image/more op.png',width:22.aw,height: 16.ah,),
                          ],
                        ),
                        SizedBox(height: 60.ah),
                        Text('Circle'.tr,
                          style: TextStyle(
                              color: HexColor('#FFFFFF'),fontWeight: FontWeight.w700,fontSize:16.fSize,
                              height:1.5
                          ),
                        ),
                        SizedBox(height:10.ah),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  height: 24.ah,
                                  width: 24.aw,
                                  decoration: BoxDecoration(
                                    // borderRadius: BorderRadius.all(Radius.circular(35)),
                                      color: Color(0x305B5B5B),
                                      shape: BoxShape.circle,
                                      image: DecorationImage(
                                        fit: BoxFit.fill,
                                        image: AssetImage('assets/image/Ellipse 1.png'),
                                      )),
                                  // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                                ),
                                // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                Text('   Kriston',
                                  style: TextStyle(
                                    color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                  ),),
                                Text('  125K views',
                                  style: TextStyle(
                                    color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                  ),),
                                Text('  3 weeks ago',
                                  style: TextStyle(
                                    color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                  ),),
          
                              ],
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment. spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Image.asset('assets/image/Unionnn.png',width:21.aw,height:21.ah,),
                                SizedBox(width: 5.aw),
                                Image.asset('assets/image/rename.png',width:22.aw,height:21.ah,),
                                SizedBox(width: 5.aw),
                                Image.asset('assets/image/bookmark.png',width:22.aw,height:21.ah,),
                              ],
                            )
                          ],
                        ),
                      ],
                    ),
                  ),
          
                ],
              ),

              SizedBox(height: 20.ah),
              Stack(
                alignment: Alignment.topLeft,
                children: [
                  Container(
                    height: 196.ah,width:MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(25),
                      // color: Colors.grey,
                      image: DecorationImage(
                          alignment: Alignment.center,fit: BoxFit.fill,
                          image: AssetImage('assets/image/Frame 21150.png')
                      ),

                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left:10,right: 15,top: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Icon(Icons.location_on,color: Colors.white,),
                                // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                Text('Sydney, Australia',
                                  style: TextStyle(
                                    color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                  ),),
                              ],
                            ),
                            Image.asset('assets/image/more op.png',width:22.aw,height: 16.ah,),
                          ],
                        ),
                        SizedBox(height: 60.ah),
                        Text('Circle'.tr,
                          style: TextStyle(
                              color: HexColor('#FFFFFF'),fontWeight: FontWeight.w700,fontSize:16.fSize,
                              height:1.5
                          ),
                        ),
                        SizedBox(height:10.ah),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  height: 24.ah,
                                  width: 24.aw,
                                  decoration: BoxDecoration(
                                    // borderRadius: BorderRadius.all(Radius.circular(35)),
                                      color: Color(0x305B5B5B),
                                      shape: BoxShape.circle,
                                      image: DecorationImage(
                                        fit: BoxFit.fill,
                                        image: AssetImage('assets/image/Ellipse 1.png'),
                                      )),
                                  // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                                ),
                                // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                Text('   Kriston',
                                  style: TextStyle(
                                    color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                  ),),
                                Text('  125K views',
                                  style: TextStyle(
                                    color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                  ),),
                                Text('  3 week',
                                  style: TextStyle(
                                    color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                  ),),

                              ],
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment. spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Image.asset('assets/image/Unionnn.png',width:21.aw,height:21.ah,),
                                SizedBox(width: 5.aw),
                                Image.asset('assets/image/rename.png',width:22.aw,height:21.ah,),
                                SizedBox(width: 5.aw),
                                Image.asset('assets/image/bookmark.png',width:22.aw,height:21.ah,),

                              ],
                            )

                          ],
                        ),
                      ],
                    ),
                  ),

                ],
              ),

            ],
          ),
        ),
      ),
      floatingActionButton:  Padding(
        padding: const EdgeInsets.all(15.0),
        child: Container(
          height: 61.ah,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(80),
            color: Color(0xff001649),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: <Widget>[
              IconButton(
                icon: InkWell(
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => DashBoardScreen()));
                    },
                    child: Icon(Icons.home,color: Colors.white,)),
                onPressed: () => _onItemTapped(0),
              ),
              // This is necessary to create space in the center
              IconButton(
                icon:Image.asset('assets/image/Icon.png',height: 21.ah,width: 21.aw,color: Colors.white,),

                // Icon(Icons.notifications),
                onPressed: () => _onItemTapped(1),
              ),
              IconButton(
                icon:Container(
                  height: 43.ah,
                  width: 43.aw,
                  decoration: BoxDecoration(
                    // borderRadius: BorderRadius.all(Radius.circular(35)),
                    color:Colors.white,
                    shape: BoxShape.circle,
                  ),
                  child:Center(child: Image.asset('assets/image/Union (1).png',height: 19.ah,width: 19.aw,)),
                  // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                ),
                // Image.asset('assets/image/plus.png'),
                onPressed: () => _onItemTapped(2),
              ),
              IconButton(
                icon:Image.asset('assets/image/Icon (1).png',height: 21.ah,width: 21.aw,color: Colors.white,),
                onPressed: () => _onItemTapped(3),
              ),
              IconButton(
                icon:Image.asset('assets/image/Vector.png',height: 21.ah,width: 21.aw,color: Colors.white,),
                onPressed: () => _onItemTapped(4),
              ),
              // Image.asset('assets/image/Vector.png',height: 21.ah,width: 21.aw,color: Colors.white,)
            ],
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,

    );
  }
}

class Discover1 extends StatelessWidget {
  Discover1({super.key});

  List<bool> active = [false, false, ];
  List<String> follow_Unfollow = [
    "Follow",
    "Unfollow",
  ];

  var selectone;
  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      height: 223.ah,
      child: ListView.builder(
        shrinkWrap: true,
        scrollDirection: Axis.horizontal,
        itemCount: 10,
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.all(3.0),
            child: Container(
              height: 223.ah,width: 120.aw,
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(7),
                  border: Border.all(
                    //color: HexColor('#FFFFFF'),
                      color: Colors.black12,
                      width:1
                  )
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                      height: 100.ah,width: 100.aw,
                      decoration: ShapeDecoration(
                          color: Colors.white,
                          shape: CircleBorder(),
                          image: DecorationImage(
                              image: AssetImage('assets/image/girrrls.png'),
                              fit: BoxFit.cover
                          )
                      )
                  ),
                  SizedBox(height:2.ah),
                  Text('Rose celebs',
                    style: TextStyle(
                        color: Colors.black,fontWeight: FontWeight.w500,fontSize:13.fSize
                    ),
                  ),

                  SizedBox(height:2.ah),
                  Text('rose_ce',
                    style: TextStyle(
                        color: Colors.grey,fontWeight: FontWeight.w600,fontSize:12.fSize
                    ),
                  ),

                  SizedBox(height:2.ah),
                  Text('27M',
                    style: TextStyle(
                        color: Colors.black,fontWeight: FontWeight.w500,fontSize:12.fSize
                    ),
                  ),


                  SizedBox(height:10.ah),
                  InkWell(
                    onTap:  () {
                      active[0] = !active[0];
                      // setState(() {
                      //   follow_Unfollow[0] = "Follow ";
                      // },);
                    },
                    child: Container(
                      height: 24.ah,width: 98.aw,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(4),
                        color: active[0] ? Colors.red : HexColor('#001649'),
                      ),
                      child:  Center(
                        child: Text(active[0] ?'Unfollow'.tr:'Follow'.tr,
                          style: TextStyle(
                              color: active[0] ? Colors.white : Colors.white,
                              fontWeight: FontWeight.w500,fontSize:14.fSize
                          ),
                        ),
                      ),
                    ),
                  )

                ],
              ),
            ),
          );
        },
      ),
    );


  }
}
