import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:frenly_file/presentation/screens/chat_screens/chat_screen.dart';
import 'package:frenly_file/core/utils/size_utils.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:get/get.dart';

class Message_Screen extends StatefulWidget {
  const Message_Screen({super.key});

  @override
  State<Message_Screen> createState() => _Message_ScreenState();
}

class _Message_ScreenState extends State<Message_Screen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: Padding(
        padding: const EdgeInsets.only(left: 15,right: 15,top:63),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                // mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Messages'.tr,
                    style: TextStyle(
                        color: Colors.black,fontWeight: FontWeight.w700,fontSize: 35
                    ),
                  ),
                  Container(
                    height: 36.ah,
                    width: 36.aw,
                    decoration: BoxDecoration(
                      // borderRadius: BorderRadius.all(Radius.circular(35)),
                        color: Color(0x305B5B5B),
                        shape: BoxShape.circle,
                        image: DecorationImage(
                          fit: BoxFit.fill,
                          image: AssetImage('assets/image/Ellipse 1.png'),
                        )),
                    // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                  ),
          
                ],
              ),
             // Message_list()
          
              SizedBox(height: 10.ah),
              InkWell(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => Chat_Screen()));
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Stack(
                          children: [
                            Container(
                              height: 62.ah,
                              width: 62.aw,
                              decoration: BoxDecoration(
                                // borderRadius: BorderRadius.all(Radius.circular(35)),
                                  color: Color(0x305B5B5B),
                                  shape: BoxShape.circle,
                                  image: DecorationImage(
                                    fit: BoxFit.contain,
                                    image: AssetImage('assets/image/Ellipse 92.png'),
                                  )),
                              // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                            ),
                            Positioned(
                              right: 3,top:38,
                                child: Image.asset('assets/image/Ellipse 119.png',height: 18.ah,width: 18.aw,)
                            )
                          ],

                        ),
                        SizedBox(width: 10.aw),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Text('Cameron Williamson',
                              style: TextStyle(
                                color: Colors.black,fontWeight: FontWeight.w600,fontSize:18.fSize,
                              ),),
                            Text('jessie5204',
                              style: TextStyle(
                                color: Colors.grey,fontWeight: FontWeight.w500,fontSize:15.fSize,
                              ),),
                          ],
                        ),


                      ],
                    ),

                    Text('11: 57 pm',
                      style: TextStyle(
                        color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize,
                      ),),

                  ],
                ),
              ),
          
              SizedBox(height: 25.ah),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Stack(
                        children: [
                          Container(
                            height: 62.ah,
                            width: 62.aw,
                            decoration: BoxDecoration(
                              // borderRadius: BorderRadius.all(Radius.circular(35)),
                                color: Color(0x305B5B5B),
                                shape: BoxShape.circle,
                                image: DecorationImage(
                                  fit: BoxFit.contain,
                                  image: AssetImage('assets/image/Ellipse 92.png'),
                                )),
                            // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                          ),
                          Positioned(
                              right: 3,top:38,
                              child: Image.asset('assets/image/Ellipse 119.png',height: 18.ah,width: 18.aw,)
                          )
                        ],
          
                      ),
                      SizedBox(width: 10.aw),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text('Cameron Williamson',
                            style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w600,fontSize:18.fSize,
                            ),),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Image.asset('assets/image/send delivery status.png',width: 14.aw,height: 9.ah,fit: BoxFit.fill,),
                              SizedBox(width: 5.aw),
                              Text('YesI'.tr,
                                style: TextStyle(
                                  color: Colors.black,fontWeight: FontWeight.w500,fontSize:15.fSize,
                                ),),
                            ],
                          ),
                        ],
                      ),
          
          
                    ],
                  ),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Text('11: 57 pm',
                        style: TextStyle(
                          color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize,
                        ),),
                      SizedBox(height: 10.ah),
                      Container(
                        height: 20.ah,
                        width: 20.aw,
                        decoration: BoxDecoration(
                          // borderRadius: BorderRadius.all(Radius.circular(35)),
                           color: HexColor('#001649'),
                            shape: BoxShape.circle,
                        ),
                        child: Center(
                          child: Text('1',
                            style: TextStyle(
                              color: Colors.white,fontWeight: FontWeight.w500,fontSize:12.fSize,
                            ),),
                        ),
                        // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                      ),
                    ],
                  ),
          
                ],
              ),
          
              SizedBox(height: 25.ah),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        height: 62.ah,
                        width: 62.aw,
                        decoration: BoxDecoration(
                          // borderRadius: BorderRadius.all(Radius.circular(35)),
                            color: Color(0x305B5B5B),
                            shape: BoxShape.circle,
                            image: DecorationImage(
                              fit: BoxFit.fill,
                              image: AssetImage('assets/image/Ellipse 1.png'),
                            )),
                        // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                      ),
                      SizedBox(width: 10.aw),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text('Jessie Alvarado',
                            style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w700,fontSize:17.fSize,
                            ),),
                          Text('jessie5204',
                            style: TextStyle(
                              color: Colors.grey,fontWeight: FontWeight.w500,fontSize:15.fSize,
                            ),),
                        ],
                      ),
          
          
                    ],
                  ),
                  Text('11: 57 pm',
                    style: TextStyle(
                      color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize,
                    ),),
                ],
              ),
          
          
              SizedBox(height: 25.ah),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        height: 62.ah,
                        width: 62.aw,
                        decoration: BoxDecoration(
                          // borderRadius: BorderRadius.all(Radius.circular(35)),
                            color: Color(0x305B5B5B),
                            shape: BoxShape.circle,
                            image: DecorationImage(
                              fit: BoxFit.fill,
                              image: AssetImage('assets/image/Ellipse 1.png'),
                            )),
                        // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                      ),
                      SizedBox(width: 10.aw),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text('Jessie Alvarado',
                            style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w700,fontSize:17.fSize,
                            ),),
                          Text('jessie5204',
                            style: TextStyle(
                              color: Colors.grey,fontWeight: FontWeight.w500,fontSize:15.fSize,
                            ),),
                        ],
                      ),
          
          
                    ],
                  ),
                  Text('11: 57 pm',
                    style: TextStyle(
                      color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize,
                    ),),
                ],
              ),
          
          
              SizedBox(height: 25.ah),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Stack(
                        children: [
                          Container(
                            height: 62.ah,
                            width: 62.aw,
                            decoration: BoxDecoration(
                              // borderRadius: BorderRadius.all(Radius.circular(35)),
                                color: Color(0x305B5B5B),
                                shape: BoxShape.circle,
                                image: DecorationImage(
                                  fit: BoxFit.contain,
                                  image: AssetImage('assets/image/Ellipse 92.png'),
                                )),
                            // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                          ),
                          Positioned(
                              right: 3,top:38,
                              child: Image.asset('assets/image/Ellipse 119.png',height: 18.ah,width: 18.aw,)
                          )
                        ],

                      ),
                      SizedBox(width: 10.aw),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text('Cameron Williamson',
                            style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w600,fontSize:18.fSize,
                            ),),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Image.asset('assets/image/send delivery status.png',width: 14.aw,height: 9.ah,fit: BoxFit.fill,),
                              SizedBox(width: 5.aw),
                              Text('YesI'.tr,
                                style: TextStyle(
                                  color: Colors.black,fontWeight: FontWeight.w500,fontSize:15.fSize,
                                ),),
                            ],
                          ),
                        ],
                      ),


                    ],
                  ),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Text('11: 57 pm',
                        style: TextStyle(
                          color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize,
                        ),),
                      SizedBox(height: 10.ah),
                      Container(
                        height: 20.ah,
                        width: 20.aw,
                        decoration: BoxDecoration(
                          // borderRadius: BorderRadius.all(Radius.circular(35)),
                          color: HexColor('#001649'),
                          shape: BoxShape.circle,
                        ),
                        child: Center(
                          child: Text('1',
                            style: TextStyle(
                              color: Colors.white,fontWeight: FontWeight.w500,fontSize:12.fSize,
                            ),),
                        ),
                        // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                      ),
                    ],
                  ),

                ],
              ),
          
              SizedBox(height: 10.ah),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        height: 62.ah,
                        width: 62.aw,
                        decoration: BoxDecoration(
                          // borderRadius: BorderRadius.all(Radius.circular(35)),
                            color: Color(0x305B5B5B),
                            shape: BoxShape.circle,
                            image: DecorationImage(
                              fit: BoxFit.fill,
                              image: AssetImage('assets/image/Ellipse 1.png'),
                            )),
                        // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                      ),
                      SizedBox(width: 10.aw),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text('Jessie Alvarado',
                            style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w700,fontSize:17.fSize,
                            ),),
                          Text('jessie5204',
                            style: TextStyle(
                              color: Colors.grey,fontWeight: FontWeight.w500,fontSize:15.fSize,
                            ),),
                        ],
                      ),


                    ],
                  ),
                  Text('11: 57 pm',
                    style: TextStyle(
                      color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize,
                    ),),
                ],
              ),
          
              SizedBox(height: 25.ah),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        height: 62.ah,
                        width: 62.aw,
                        decoration: BoxDecoration(
                          // borderRadius: BorderRadius.all(Radius.circular(35)),
                            color: Color(0x305B5B5B),
                            shape: BoxShape.circle,
                            image: DecorationImage(
                              fit: BoxFit.fill,
                              image: AssetImage('assets/image/Ellipse 1.png'),
                            )),
                        // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                      ),
                      SizedBox(width: 10.aw),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text('Jessie Alvarado',
                            style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w700,fontSize:17.fSize,
                            ),),
                          Text('jessie5204',
                            style: TextStyle(
                              color: Colors.grey,fontWeight: FontWeight.w500,fontSize:15.fSize,
                            ),),
                        ],
                      ),
          
          
                    ],
                  ),
                  Text('11: 57 pm',
                    style: TextStyle(
                      color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize,
                    ),),
                ],
              ),
          
              SizedBox(height: 10.ah),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Stack(
                        children: [
                          Container(
                            height: 62.ah,
                            width: 62.aw,
                            decoration: BoxDecoration(
                              // borderRadius: BorderRadius.all(Radius.circular(35)),
                                color: Color(0x305B5B5B),
                                shape: BoxShape.circle,
                                image: DecorationImage(
                                  fit: BoxFit.contain,
                                  image: AssetImage('assets/image/Ellipse 92.png'),
                                )),
                            // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                          ),
                          Positioned(
                              right: 3,top:38,
                              child: Image.asset('assets/image/Ellipse 119.png',height: 18.ah,width: 18.aw,)
                          )
                        ],
          
                      ),
                      SizedBox(width: 10.aw),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text('Cameron Williamson',
                            style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w600,fontSize:18.fSize,
                            ),),
                          Text('jessie5204',
                            style: TextStyle(
                              color: Colors.grey,fontWeight: FontWeight.w500,fontSize:15.fSize,
                            ),),
                        ],
                      ),
          
          
                    ],
                  ),
          
                  Text('11: 57 pm',
                    style: TextStyle(
                      color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize,
                    ),),
          
                ],
              ),
          
              SizedBox(height: 25.ah),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        height: 62.ah,
                        width: 62.aw,
                        decoration: BoxDecoration(
                          // borderRadius: BorderRadius.all(Radius.circular(35)),
                            color: Color(0x305B5B5B),
                            shape: BoxShape.circle,
                            image: DecorationImage(
                              fit: BoxFit.fill,
                              image: AssetImage('assets/image/Ellipse 1.png'),
                            )),
                        // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                      ),
                      SizedBox(width: 10.aw),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text('Jessie Alvarado',
                            style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w700,fontSize:17.fSize,
                            ),),
                          Text('jessie5204',
                            style: TextStyle(
                              color: Colors.grey,fontWeight: FontWeight.w500,fontSize:15.fSize,
                            ),),
                        ],
                      ),
          
          
                    ],
                  ),
                  Text('11: 57 pm',
                    style: TextStyle(
                      color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize,
                    ),),
                ],
              ),
          
              SizedBox(height: 25.ah),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        height: 62.ah,
                        width: 62.aw,
                        decoration: BoxDecoration(
                          // borderRadius: BorderRadius.all(Radius.circular(35)),
                            color: Color(0x305B5B5B),
                            shape: BoxShape.circle,
                            image: DecorationImage(
                              fit: BoxFit.fill,
                              image: AssetImage('assets/image/Ellipse 1.png'),
                            )),
                        // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                      ),
                      SizedBox(width: 10.aw),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text('Jessie Alvarado',
                            style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w700,fontSize:17.fSize,
                            ),),
                          Text('jessie5204',
                            style: TextStyle(
                              color: Colors.grey,fontWeight: FontWeight.w500,fontSize:15.fSize,
                            ),),
                        ],
                      ),
          
          
                    ],
                  ),
                  Text('11: 57 pm',
                    style: TextStyle(
                      color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize,
                    ),),
                ],
              ),
          
              SizedBox(height: 25.ah),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        height: 62.ah,
                        width: 62.aw,
                        decoration: BoxDecoration(
                          // borderRadius: BorderRadius.all(Radius.circular(35)),
                            color: Color(0x305B5B5B),
                            shape: BoxShape.circle,
                            image: DecorationImage(
                              fit: BoxFit.fill,
                              image: AssetImage('assets/image/Ellipse 1.png'),
                            )),
                        // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                      ),
                      SizedBox(width: 10.aw),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text('Jessie Alvarado',
                            style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w700,fontSize:17.fSize,
                            ),),
                          Text('jessie5204',
                            style: TextStyle(
                              color: Colors.grey,fontWeight: FontWeight.w500,fontSize:15.fSize,
                            ),),
                        ],
                      ),
          
          
                    ],
                  ),
                  Text('11: 57 pm',
                    style: TextStyle(
                      color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize,
                    ),),
                ],
              ),

              SizedBox(height: 10.ah),
             // Message_list()
            ],
          ),
        ),
      ),
    );
  }
}


class Message_list extends StatelessWidget {
  const Message_list({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      shrinkWrap: true,
      scrollDirection: Axis.vertical,
      itemCount: 10,
      itemBuilder: (context, index) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                height: 62.ah,
                width: 62.aw,
                decoration: BoxDecoration(
                  // borderRadius: BorderRadius.all(Radius.circular(35)),
                    color: Color(0x305B5B5B),
                    shape: BoxShape.circle,
                    image: DecorationImage(
                      fit: BoxFit.fill,
                      image: AssetImage('assets/image/Ellipse 1.png'),
                    )),
                // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
              ),
              SizedBox(width: 10.aw),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text('Jessie Alvarado',
                    style: TextStyle(
                      color: Colors.black,fontWeight: FontWeight.w700,fontSize:17.fSize,
                    ),),
                  Text('jessie5204',
                    style: TextStyle(
                      color: Colors.grey,fontWeight: FontWeight.w500,fontSize:15.fSize,
                    ),),
                ],
              ),


            ],
          ),
        );
      },
    );
  }
}
