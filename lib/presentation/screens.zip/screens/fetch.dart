import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:frenly_file/presentation/screens/zget/get_model.dart';
import 'package:http/http.dart' as http;

class MyWidget extends StatefulWidget {
  @override
  _MyWidgetState createState() => _MyWidgetState();
}

class _MyWidgetState extends State<MyWidget> {

  var data = {
    'family_id': '1'
  };

  Future<void> fetchData() async {
    final response = await http.get(Uri.parse('http://3.104.197.136:4000/user/getFamilyMembers'));
    if (response.statusCode == 200) {
      setState(() {
        data = json.decode(response.body)['family_id'];
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          ElevatedButton(
            onPressed: fetchData,
            child: Text('Fetch Data'),
          ),
          SizedBox(height: 20),
          //Text(data),
        ],
      ),
    );
  }
}


class HomeeePage extends StatefulWidget {
  const HomeeePage({super.key});

  @override
  State<HomeeePage> createState() => _HomeeePageState();
}

class _HomeeePageState extends State<HomeeePage> {
 // List<UserModels> userData = [];
  List<FamilyMembersModel> familymembermodel = [];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder(
        future: getData(),
        builder: (context, snapshot) {
      //checking if snapshot has data
          if (snapshot.hasData) {
            return ListView.builder(
                itemCount: familymembermodel.length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: const EdgeInsets.all(8.0),
      //showing in the Listtile
                    child: ListTile(
                      title: Text('Name: ${familymembermodel[index].familyDetails.first.firstName}'),
                      subtitle: Text('last: ${familymembermodel[index].familyDetails.last.lastName}'),
                    ),
                  );
                });
          } else {
            return const Center(child:Text('No data')
            );
          }
        },
      ),
    );
  }

  //List<FamilyMembersModel> familymembermodel = [];

  Future<List<FamilyMembersModel>> getData() async {
    print('123');
    final response = await http.get(Uri.parse('http://3.104.197.136:4000/user/getFamilyMembers'));
    var data = jsonDecode(response.body.toString());
    print('345');

/*jsonDecode is a Dart function provided by dart:convert library used
 to convert JSON data,
 received from an API or read from a file, into Dart objects.
 It transforms JSON strings into Dart maps or lists*/

    if (response.statusCode == 200) {
      for (Map<String, dynamic> index in data) {
        familymembermodel.add(FamilyMembersModel.fromJson(index));
      }
      return familymembermodel;
    }
    return familymembermodel; //empty list
  }
}