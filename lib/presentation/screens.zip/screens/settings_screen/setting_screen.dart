import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:frenly_file/presentation/screens/all_categories/all_categories.dart';
import 'package:frenly_file/presentation/screens/edit_profile_screens/edit_profile.dart';
import 'package:frenly_file/presentation/screens/saved_blog/saved_blog.dart';
import 'package:frenly_file/presentation/screens/saved_people_profile/saved_people_profile.dart';
import 'package:frenly_file/presentation/screens/saved_photo/saved_photo.dart';
import 'package:frenly_file/presentation/screens/saved_vlogs/saved_vlogs.dart';
import 'package:frenly_file/presentation/screens/video_post_screen/video_post_screen.dart';
import 'package:frenly_file/core/utils/size_utils.dart';
import 'package:hexcolor/hexcolor.dart';
import '../../../core/constants/my_textfield.dart';
import '../../../toggle.dart';
import 'package:get/get.dart';

class Setting_Screen extends StatefulWidget {
  const Setting_Screen({super.key});

  @override
  State<Setting_Screen> createState() => _Setting_ScreenState();
}

class _Setting_ScreenState extends State<Setting_Screen> {
  bool _switchValue0 = true;
  bool _switchValue1 = true;
  bool _switchValue2 = true;
  bool _switchValue3 = true;
  bool _switchValue4 = true;
  bool isChecked = true;

  final List locale =[
    {'name':'ENGLISH','locale': Locale('en','US')},
    {'name':'SWEDISH','locale': Locale('swe','SE')},
   // {'name':'हिंदी','locale': Locale('hi','IN')},
  ];

  updateLanguage(Locale locale){
    Get.back();
    Get.updateLocale(locale);
  }
  buildLanguageDialog(BuildContext context){
    showDialog(context: context,
        builder: (builder){
          return AlertDialog(
            shadowColor: Colors.white,
            //elevation: 5,
            title: Text('Chooseyo'.tr,
              style: TextStyle(color: Colors.black,fontWeight: FontWeight.w500,fontSize:16.fSize
              ),),
            content: Container(
              width: double.maxFinite,
              child: ListView.separated(
                  shrinkWrap: true,
                  itemBuilder: (context,index){
                    return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: GestureDetector(child: Text(locale[index]['name']),onTap: (){
                        print(locale[index]['name']);
                        updateLanguage(locale[index]['locale']);
                      },),
                    );
                  }, separatorBuilder: (context,index){
                return Divider(
                  color: Colors.blue,
                );
              }, itemCount: locale.length
              ),
            ),
          );
        }
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Text('Settings'.tr,
              style: TextStyle(
                  color: Colors.black,fontWeight: FontWeight.w600,fontSize:20.fSize
              ),
            ),
          ],
        ),
        leading: Padding(
          padding:  EdgeInsets.only(left: 35.h),
          child: InkWell(
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => Edit_Profile(),));
            },
              child: Icon(Icons.arrow_back_sharp)),
        ),
        backgroundColor: Colors.white,
        shadowColor: Colors.white,
        surfaceTintColor: Colors.white,
        elevation:3,
      ),

      body: Padding(
        padding: const EdgeInsets.only(left: 15,right: 15,top:20),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                height:96.ah,
                width:MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                  color: HexColor('#E8E8E8'),
                  borderRadius: BorderRadius.circular(6)
                ),
                child: Padding(
                  padding: const EdgeInsets.only(left: 10,right: 10),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                        Text('Last'.tr,
                        style: TextStyle(color: Colors.black,fontWeight: FontWeight.w500,fontSize:16.fSize
                    ),),
                          Transform.scale(
                            scale: 0.4,
                            child: CupertinoSwitch(
                              activeColor: Colors.blueGrey,
                              trackColor: Colors.grey,
                                onLabelColor: Colors.brown,
                                offLabelColor: Colors.red,
                                 thumbColor: Color(0xff001649),
                              value: _switchValue0,
                              onChanged: (bool value) {
                                setState(() {
                                  _switchValue0 = value;
                                });
                              },
                            ),
                          ),
                          //Image.asset('assets/image/Toggle switch.png',width: 28.aw,height: 17.ah,),
                      ],),
          
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('CommentsonP'.tr,
                            style: TextStyle(color: Colors.black,fontWeight: FontWeight.w500,fontSize:16.fSize
                            ),),
                         // Image.asset('assets/image/Toggle switch (1).png',width: 28.aw,height: 17.ah,),
                          Transform.scale(
                            scale: 0.4,
                            child: CupertinoSwitch(
                              activeColor: Colors.blueGrey,
                              trackColor: Colors.grey,
                              onLabelColor: Colors.brown,
                              offLabelColor: Colors.red,
                              thumbColor: Color(0xff001649),
                              value: _switchValue1,
                              onChanged: (bool value) {
                                setState(() {
                                  _switchValue1 = value;
                                });
                              },
                            ),
                          ),
          
                        ],),
                    ],
                  ),
                ),
              ),
          
              SizedBox(height: 20.ah),
              Container(
                height:230.ah,
                width:MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                    color: HexColor('#E8E8E8'),
                    borderRadius: BorderRadius.circular(6)
                ),
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text('ACCOUNT'.tr,
                        style: TextStyle(color: Colors.grey,fontFamily: 'inter',fontWeight: FontWeight.w600,fontSize:16.fSize
                        ),),
          
                      InkWell(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => Save_Vlogs_Screen()));
                        },
                        child: Text('Saved Items'.tr,
                          style: TextStyle(color: Colors.black,fontWeight: FontWeight.w500,fontSize:16.fSize
                          ),),
                      ),
          
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Blocked List'.tr,
                            style: TextStyle(color: Colors.black,fontWeight: FontWeight.w500,fontSize:16.fSize
                            ),),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('128'.tr,
                                style: TextStyle(color: Colors.grey,fontWeight: FontWeight.w500,fontSize:16.fSize
                                ),),
                              SizedBox(width: 10.aw),
                              Text('Contacts'.tr,
                                style: TextStyle(color: Colors.grey,fontWeight: FontWeight.w500,fontSize:16.fSize
                                ),),
                            ],
                          ),
                        ],),

                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Languagegg'.tr,
                            style: TextStyle(color: Colors.black,fontWeight: FontWeight.w500,fontSize:16.fSize
                            ),),
          
                          InkWell(
                            onTap: () {
                              buildLanguageDialog(context);
                            },
                            child: Text('Eng'.tr,
                              style: TextStyle(color: Colors.grey,fontWeight: FontWeight.w500,fontSize:16.fSize
                              ),),
                          ),
                        ],),
          
                          Text('Delete Account'.tr,
                        style: TextStyle(color: Colors.black,fontWeight: FontWeight.w500,fontSize:16.fSize
                        ),),

                      InkWell(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => All_Categories()));
                        },
                        child: Text('AllCategory'.tr,
                          style: TextStyle(color: Colors.black,fontWeight: FontWeight.w500,fontSize:16.fSize
                          ),),
                      ),
                    ],
                  ),
                ),
              ),
          
              SizedBox(height: 20.ah),
              Container(
                height: 142.ah,
                width: MediaQuery.of(context).size.width,
                //width:351.aw ,
                decoration: BoxDecoration(
                    color: HexColor('#E8E8E8'),
                    borderRadius: BorderRadius.circular(6)
                ),
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text('NOTIFICATIONS'.tr,
                        style: TextStyle(color: Colors.grey,fontFamily: 'inter',fontWeight: FontWeight.w600,fontSize:16.fSize
                        ),),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Chat Notification'.tr,
                            style: TextStyle(color: Colors.black,fontWeight: FontWeight.w500,fontSize:16.fSize
                            ),),
                          //Image.asset('assets/image/Toggle switch.png',width: 28.aw,height: 17.ah,),
                          Transform.scale(
                            scale: 0.4,
                            child: CupertinoSwitch(
                              activeColor: Colors.blueGrey,
                              trackColor: Colors.grey,
                              onLabelColor: Colors.brown,
                              offLabelColor: Colors.red,
                              thumbColor: Color(0xff001649),
                              value: _switchValue3,
                              onChanged: (bool value) {
                                setState(() {
                                  _switchValue3 = value;
                                });
                              },
                            ),
                          ),
                        ],),
          
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Feedd'.tr,
                            style: TextStyle(color: Colors.black,fontWeight: FontWeight.w500,fontSize:16.fSize
                            ),),
                          //Image.asset('assets/image/Toggle switch (1).png',width: 28.aw,height: 17.ah,),
                         // SizedBox(width: 50.aw),
                          Transform.scale(
                            scale: 0.4,
                            child: CupertinoSwitch(
                              activeColor: Colors.blueGrey,
                              trackColor: Colors.grey,
                              onLabelColor: Colors.brown,
                              offLabelColor: Colors.red,
                              thumbColor: Color(0xff001649),
                              value: _switchValue4,
                              onChanged: (bool value) {
                                setState(() {
                                  _switchValue4 = value;
                                });
                              },
                            ),
                          ),
          
                        ],),
          
                    ],
                  ),
                ),
              ),
          
          
          
              SizedBox(height:30.ah,),
              Center(
                child: CustomPrimaryBtn1(
                  title: 'Logout'.tr,
                  isLoading: false,
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => Video_Post_Screen()));
                   // Navigator.push(context, MaterialPageRoute(builder: (context) => MyHomePage()));
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
