import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:frenly_file/core/utils/size_utils.dart';
import 'package:get/get.dart';
import '../../../core/constants/my_textfield.dart';
import '../create_blog_screen/create_blog.dart';

class Photo_post extends StatefulWidget {
  const Photo_post({super.key});

  @override
  State<Photo_post> createState() => _Photo_postState();
}

class _Photo_postState extends State<Photo_post> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(

        title: Row(
          children: [
            Text('Photo Post'.tr,
              style: TextStyle(
                  color: Colors.black,fontWeight: FontWeight.w600,fontSize:20.fSize
              ),
            ),
          ],
        ),
        leading: Padding(
          padding:  EdgeInsets.only(left: 35.h),
          child: InkWell(
              onTap: () {
                Navigator.pop(context);
              },
              child: Icon(Icons.arrow_back_sharp)),
        ),
        backgroundColor: Colors.white,
        shadowColor: Colors.white,
        surfaceTintColor: Colors.white,

        elevation:3,
      ),

      body: Padding(
        padding: const EdgeInsets.only(left:30,right:30,top: 20),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [

              Stack(
                alignment: Alignment.topRight,
                children: [
                  Container(
                    height: 330.ah,width: MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(25),
                      // color: Colors.grey,
                      image: DecorationImage(
                        // alignment: Alignment.center,
                          fit: BoxFit.fill,
                          image: AssetImage('assets/image/kateryna-hliznitsova-hcJBRRnqf2E-unsplash.jpg')
                      ),),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Image.asset('assets/image/Group 1618.png',height: 38.ah,width: 38.aw,fit: BoxFit.fill,),
                  ),
                ],),
               //Image.asset('assets/image/Frame 427320859.png',),

              SizedBox(height: 10.ah,),
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: Text('Caption'.tr,
                  style: TextStyle(
                      color: Colors.black,fontWeight: FontWeight.w700,fontSize: 15.fSize
                  ),
                ),
              ),

              SizedBox(height: 10.ah,),
              primaryTextfield4(
                  hintText:'Thisis'.tr,
                  controller: null
              ),

              Center(
                child: CustomPrimaryBtn1(
                  title: 'Upload'.tr,
                  isLoading: false,
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => Create_Blog_Screen()));
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
