import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:frenly_file/core/utils/size_utils.dart';
// import 'package:frenly_file/core/utils/size_utils.dart';


import 'package:get/get.dart';

class All_Categories extends StatefulWidget {
  const All_Categories({super.key});

  @override
  State<All_Categories> createState() => _All_CategoriesState();
}

class _All_CategoriesState extends State<All_Categories> {
  List<String> _list = [];

  bool? _isFood = false;
  bool? _isFashion = false;
  bool? _isTech = false;
  bool? _isScience = false;
  bool? _isGame = false;
  bool? _isFinance = false;
  bool? _isComedy = false;
  bool? _isSongs = false;
  bool? _isHollywood = false;
  bool? _isHumor = false;
  bool? _isAsian = false;
  bool? _isCode = false;
  bool? _isApps = false;
  bool? _isUIUX = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        surfaceTintColor: Colors.white,
        backgroundColor: Colors.white,
        shadowColor: Colors.white,
        title: Row(
          children: [
            Text('AllCategory'.tr,
              style: TextStyle(
                  color: Colors.black,fontWeight: FontWeight.w700,fontSize:32.fSize
              ),
            ),
          ],
        ),
        leading: Padding(
          padding:  EdgeInsets.only(left: 15.h),
          child: InkWell(
              onTap: () {
                Navigator.pop(context);
              },
              child: Icon(Icons.arrow_back_sharp)),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Image.asset('assets/image/delete.png',height: 20.ah,width: 20.aw,)

          ),
        ],
      ),
      body:Padding(
        padding: const EdgeInsets.only(right:20,top: 20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [

              Padding(
                padding: const EdgeInsets.only(left: 20),
                child: Text('NewCategory'.tr,
                  style: TextStyle(
                      color: Colors.black,fontWeight: FontWeight.w700,fontSize:20.fSize
                  ),),
              ),

              Expanded(
                child: ListView(
                  shrinkWrap: true,
                  physics: BouncingScrollPhysics(),
                  children: <Widget>[
                    ListTile(
                      title: Text("Food".tr),
                      leading: Checkbox(
                        value: _isFood,
                        onChanged: (bool? value) {
                          setState(() {
                            _isFood = value!;
                            String selectVal = "Food".tr;
                            value! ? _list.add(selectVal) : _list.remove(selectVal);
                          });
                        },
                      ),),
                    ListTile(
                      title: Text("Fashion".tr),
                      leading: Checkbox(
                        value: _isFashion,
                        onChanged: (bool? value) {
                          setState(() {
                            _isFashion = value!;
                            String selectVal = "Fashion".tr;
                            value! ? _list.add(selectVal) : _list.remove(selectVal);
                          });
                        },
                      ),
                    ),

                    ListTile(
                      title: Text("Tech".tr),
                      leading: Checkbox(
                        value: _isTech,
                        onChanged: (value) {
                          setState(() {
                            _isTech = value!;
                            String selectVal = "Tech";
                            value! ? _list.add(selectVal) : _list.remove(selectVal);
                          });
                        },
                      ),
                    ),

                    ListTile(
                      title: Text("Science".tr),
                      leading: Checkbox(
                        value: _isScience,
                        onChanged: (value) {
                          setState(() {
                            _isScience = value!;
                            String selectVal = "Science".tr;
                            value! ? _list.add(selectVal) : _list.remove(selectVal);
                          });
                        },
                      ),
                    ),

                    ListTile(
                      title: Text("Game".tr),
                      leading: Checkbox(
                        value: _isGame,
                        onChanged: (value) {
                          setState(() {
                            _isGame = value!;
                            String selectVal = "Game".tr;
                            value! ? _list.add(selectVal) : _list.remove(selectVal);
                          });
                        },
                      ),
                    ),

                    ListTile(
                      title: Text("Finance".tr),
                      leading: Checkbox(
                        value: _isFinance,
                        onChanged: (value) {
                          setState(() {
                            _isFinance = value!;
                            String selectVal = "Finance".tr;
                            value! ? _list.add(selectVal) : _list.remove(selectVal);
                          });
                        },
                      ),
                    ),

                    ListTile(
                      title: Text("Comedy".tr),
                      leading: Checkbox(
                        value: _isComedy,
                        onChanged: (value) {
                          setState(() {
                            _isComedy = value!;
                            String selectVal = "Comedy".tr;
                            value! ? _list.add(selectVal) : _list.remove(selectVal);
                          });
                        },
                      ),
                    ),

                    ListTile(
                      title: Text("Song".tr),
                      leading: Checkbox(
                        value: _isSongs,
                        onChanged: (value) {
                          setState(() {
                            _isSongs = value!;
                            String selectVal = "Songs".tr;
                            value! ? _list.add(selectVal) : _list.remove(selectVal);
                          });
                        },
                      ),
                    ),

                    ListTile(
                      title: Text("Hollywood".tr),
                      leading: Checkbox(
                        value: _isHollywood,
                        onChanged: (value) {
                          setState(() {
                            _isHollywood = value!;
                            String selectVal = "Hollywood".tr;
                            value! ? _list.add(selectVal) : _list.remove(selectVal);
                          });
                        },
                      ),
                    ),

                    ListTile(
                      title: Text("Humor".tr),
                      leading: Checkbox(
                        value: _isHumor,
                        onChanged: (value) {
                          setState(() {
                            _isHumor = value!;
                            String selectVal = "Humor".tr;
                            value! ? _list.add(selectVal) : _list.remove(selectVal);
                          });
                        },
                      ),
                    ),

                    ListTile(
                      title: Text("Asian".tr),
                      leading: Checkbox(
                        value: _isAsian,
                        onChanged: (value) {
                          setState(() {
                            _isAsian = value!;
                            String selectVal = "Asian".tr;
                            value! ? _list.add(selectVal) : _list.remove(selectVal);
                          });
                        },
                      ),
                    ),

                    ListTile(
                      title: Text("Code".tr),
                      leading: Checkbox(
                        value: _isCode,
                        onChanged: (value) {
                          setState(() {
                            _isCode = value!;
                            String selectVal = "Code".tr;
                            value! ? _list.add(selectVal) : _list.remove(selectVal);
                          });
                        },
                      ),
                    ),

                    ListTile(
                      title: Text("Apps".tr),
                      leading: Checkbox(
                        value: _isApps,
                        onChanged: (value) {
                          setState(() {
                            _isApps = value!;
                            String selectVal = "Apps";
                            value! ? _list.add(selectVal) : _list.remove(selectVal);
                          });
                        },
                      ),
                    ),

                    ListTile(
                      title: Text("UI/UX".tr),
                      leading: Checkbox(
                        value: _isUIUX,
                        onChanged: (value) {
                          setState(() {
                            _isUIUX = value!;
                            String selectVal = "UI/UX".tr;
                            value! ? _list.add(selectVal) : _list.remove(selectVal);
                          });
                        },
                      ),
                    ),
                  ],
                ),
              ),

              /*Center(
                  child: _list.isEmpty
                      ? Text("")
                      : RichText(
                      text: TextSpan(
                          text: "Selected Games:\n",
                          style: DefaultTextStyle.of(context).style,
                          children: <TextSpan>[
                            TextSpan(
                                text: '${_list.toString()} ',
                                style: TextStyle(fontSize: 16)),
                          ]))),*/

            ],)
      )
    );
  }
}
