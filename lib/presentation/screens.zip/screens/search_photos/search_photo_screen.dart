import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:frenly_file/core/utils/size_utils.dart';
import 'package:get/get.dart';
import '../../dashboard_screen/dashboard_screen.dart';
import '../search_accounts/search_account.dart';
import '../search_blogs/search_blogs.dart';
import '../search_places/search_place.dart';

class SearchPhoto_Screen extends StatefulWidget {
  const SearchPhoto_Screen({super.key});

  @override
  State<SearchPhoto_Screen> createState() => _SearchPhoto_ScreenState();
}

class _SearchPhoto_ScreenState extends State<SearchPhoto_Screen> {
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.only(left: 15,right: 15,top:63),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Card(
                color: Colors.white,
                shadowColor: Colors.black,
                surfaceTintColor: Colors.black,
                child: Container(
                  // width: 293,
                  width: MediaQuery.of(context).size.width,
                  height:45,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: Color(0xFFe9eaec),
                    borderRadius: BorderRadius.circular(14),
                    //         boxShadow: [
                    //       BoxShadow(
                    //       color: Colors.white70,
                    //         offset: const Offset(
                    //           5.0,
                    //           5.0,
                    //         ),
                    //         blurRadius: 10.0,
                    //         spreadRadius: 2.0,
                    //       ), //BoxShadow
                    // BoxShadow(
                    //   color: Colors.white,
                    //   offset: const Offset(0.0, 0.0),
                    //   blurRadius: 0.0,
                    //   spreadRadius: 0.0,
                    // ), //BoxShadow
                    // ],
          
                    //BoxDecoration
                  ),
                  child: TextField(
                    cursorColor: Color(0xFF000000),
                    style: TextStyle(color: Colors.black),
                    decoration: InputDecoration(
                        prefixIcon: //Image.asset('assets/images/seearch.png',),
                        Icon(Icons.search, color: Colors.black,),
                        hintText: "Search".tr,
                        hintStyle: TextStyle(color:Colors.grey,fontSize:19.fSize,fontWeight: FontWeight.w500),
                        border: InputBorder.none),
          
                  ),
                ),
              ),
              SizedBox(height: 20.ah),
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Container(
                    padding: EdgeInsets.only(bottom: 3),
                    child: Text(
                      'Vlogs'.tr,
                      style: TextStyle(
                        color: Color(0xFF9C9C9C),
                        fontSize: 14.fSize,
                        fontFamily: 'Inter',
                        fontWeight: FontWeight.w500,
                        height: 1.ah,
                        letterSpacing:1.ah,

                      ),),
                  ),
                  SizedBox(width: 22.aw,),

                  InkWell(
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => SearchBlog_screen()));
                    },
                    child: Container(
                      padding: EdgeInsets.only(bottom: 3),
                      child: Text(
                        'Blogs'.tr,
                        style: TextStyle(
                          color: Color(0xFF9C9C9C),
                          fontSize: 14.fSize,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w500,
                          height: 1,
                          letterSpacing: 0.65,
                        ),
                      ),
                    ),
                  ),

                  SizedBox(width: 22.aw,),

                  InkWell(
                    onTap: () {
                     // Navigator.push(context, MaterialPageRoute(builder: (context) => SearchPhoto_Screen()));
                    },
                    child: Container(
                      padding: EdgeInsets.only(bottom: 3),
                      decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Colors.black, width: 1.0,))),
                      child: Text(
                        'Photos'.tr,
                        style: TextStyle(
                          color: Color(0xFF9C9C9C),
                          fontSize: 14.fSize,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w500,
                          height: 1,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 22.aw,),

                  InkWell(
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => SearchAccount_Screen()));
                    },
                    child: Container(
                      padding: EdgeInsets.only(bottom: 3),
                      child: Text(
                        'Profiles'.tr,
                        style: TextStyle(
                          color: Color(0xFF9C9C9C),
                          fontSize: 14.fSize,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w500,
                          height: 1,
                          letterSpacing: 0.65,
                        ),
                      ),
                    ),
                  ),

                 /* SizedBox(width: 22.aw,),
                  InkWell(
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => SearchPlace_Screen()));
                    },
                    child: Container(
                      padding: EdgeInsets.only(bottom: 3),
                      child: Text(
                        'Places'.tr,
                        style: TextStyle(
                          color: Color(0xFF7F7F7F),
                          fontSize: 14.fSize,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w500,
                          height: 1,
                          letterSpacing: 0.65,
                        ),
                      ),
                    ),
                  )*/

                ],
              ),
          
              SizedBox(height: 20.ah),
              // Expanded(
              //     child: SrcPhoto()
              // ),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Image.asset('assets/image/Frame 21150 (2).png',width: 173.aw,height: 158.ah,fit: BoxFit.fill),
                  Image.asset('assets/image/Frame 21150 (2).png',width: 173.aw,height: 158.ah,fit: BoxFit.fill),
                ],
              ),
              SizedBox(height: 10.ah),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Image.asset('assets/image/Frame 21150 (2).png',width: 173.aw,height: 158.ah,fit: BoxFit.fill),
                  Image.asset('assets/image/Frame 21150 (2).png',width: 173.aw,height: 158.ah,fit: BoxFit.fill),
          
                ],
              ),
              SizedBox(height: 10.ah),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Image.asset('assets/image/Frame 21150 (2).png',width: 173.aw,height: 158.ah,fit: BoxFit.fill),
                  Image.asset('assets/image/Frame 21150 (2).png',width: 173.aw,height: 158.ah,fit: BoxFit.fill),
                ],
              ),
              SizedBox(height: 10.ah),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Image.asset('assets/image/Frame 21150 (2).png',width: 173.aw,height: 158.ah,fit: BoxFit.fill),
                  Image.asset('assets/image/Frame 21150 (2).png',width: 173.aw,height: 158.ah,fit: BoxFit.fill),

                ],
              ),
              SizedBox(height: 10.ah),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Image.asset('assets/image/Frame 21150 (2).png',width: 173.aw,height: 158.ah,fit: BoxFit.fill),
                  Image.asset('assets/image/Frame 21150 (2).png',width: 173.aw,height: 158.ah,fit: BoxFit.fill),
                ],
              ),
              SizedBox(height: 10.ah),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Image.asset('assets/image/Frame 21150 (2).png',width: 173.aw,height: 158.ah,fit: BoxFit.fill),
                  Image.asset('assets/image/Frame 21150 (2).png',width: 173.aw,height: 158.ah,fit: BoxFit.fill),

                ],
              ),
            ],
          ),
        ),
      ),
      floatingActionButton:  Padding(
        padding: const EdgeInsets.all(15.0),
        child: Container(
          height: 61.ah,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(80),
            color: Color(0xff001649),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: <Widget>[
              IconButton(
                icon: InkWell(
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => DashBoardScreen()));
                    },
                    child: Icon(Icons.home,color: Colors.white,)),
                onPressed: () => _onItemTapped(0),
              ),
              // This is necessary to create space in the center
              IconButton(
                icon:Image.asset('assets/image/Icon.png',height: 21.ah,width: 21.aw,color: Colors.white,),

                // Icon(Icons.notifications),
                onPressed: () => _onItemTapped(1),
              ),
              IconButton(
                icon:Container(
                  height: 43.ah,
                  width: 43.aw,
                  decoration: BoxDecoration(
                    // borderRadius: BorderRadius.all(Radius.circular(35)),
                    color:Colors.white,
                    shape: BoxShape.circle,
                  ),
                  child:Center(child: Image.asset('assets/image/Union (1).png',height: 19.ah,width: 19.aw,)),
                  // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                ),
                // Image.asset('assets/image/plus.png'),
                onPressed: () => _onItemTapped(2),
              ),
              IconButton(
                icon:Image.asset('assets/image/Icon (1).png',height: 21.ah,width: 21.aw,color: Colors.white,),
                onPressed: () => _onItemTapped(3),
              ),
              IconButton(
                icon:Image.asset('assets/image/Vector.png',height: 21.ah,width: 21.aw,color: Colors.white,),
                onPressed: () => _onItemTapped(4),
              ),
              // Image.asset('assets/image/Vector.png',height: 21.ah,width: 21.aw,color: Colors.white,)
            ],
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
}


class SrcPhoto extends StatelessWidget {
  const SrcPhoto({super.key});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GridView.builder(
          itemCount: 18,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,mainAxisExtent: 120,
              mainAxisSpacing: 5,crossAxisSpacing: 5
          ),
          itemBuilder: (context, index) {
            return Container(
              height: 120.ah,width: 120.aw,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  // color: Colors.green,
                  image: DecorationImage(
                      image: AssetImage('assets/image/girrrls.png'),
                      fit: BoxFit.cover
                  )
              ),
            );
          }
          ),
    );
  }
}
