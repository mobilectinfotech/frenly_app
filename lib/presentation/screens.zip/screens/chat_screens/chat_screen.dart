import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:frenly_file/presentation/screens/share_screen/sharescreen.dart';
import 'package:frenly_file/core/utils/size_utils.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:get/get.dart';

import '../../../core/constants/my_textfield.dart';

class Chat_Screen extends StatefulWidget {
  const Chat_Screen({super.key});

  @override
  State<Chat_Screen> createState() => _Chat_ScreenState();
}

class _Chat_ScreenState extends State<Chat_Screen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 20),
            child: InkWell(
                onTap: () {
                  showModalBottomSheet(
                      context: context,
                      backgroundColor: Colors.white,
                      builder: (context) {
                        return Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            SizedBox(height: 15.ah),
                            ListTile(
                              leading: Image.asset('assets/image/delete (1).png',height:38.ah,width:38.aw,fit: BoxFit.fill,),
                              title: Text('Clearchat'.tr,
                                style: TextStyle(
                                    color: Colors.black,fontWeight: FontWeight.w600,fontSize:16
                                ),),
                              onTap: () {
                                Navigator.pop(context);
                              },
                            ),

                            ListTile(
                              leading: Image.asset('assets/image/delete (1).png',height:38.ah,width:38.aw,fit: BoxFit.fill,),
                              title: Text('Deletecht'.tr,
                                style: TextStyle(
                                    color: Colors.black,fontWeight: FontWeight.w600,fontSize:16
                                ),),
                              onTap: () {
                                Navigator.pop(context);
                              },
                            ),

                            ListTile(
                              leading: Image.asset('assets/image/delete (1).png',height:38.ah,width:38.aw,fit: BoxFit.fill,),
                              title: Text('Block'.tr,
                                style: TextStyle(
                                    color: Colors.black,fontWeight: FontWeight.w600,fontSize:16
                                ),),
                              onTap: () {
                                Navigator.pop(context);
                              },
                            ),

                            ListTile(
                              leading: Image.asset('assets/image/share (1).png',height:38.ah,width:38.aw,fit: BoxFit.fill,),
                              title: Text('Share'.tr,
                                style: TextStyle(
                                    color: Colors.black,fontWeight: FontWeight.w600,fontSize:16
                                ),),
                              onTap: () {
                                Navigator.push(context, MaterialPageRoute(builder: (context) => Share_Screen()));
                              },
                            ),
                          ],
                        );
                      }
                      );
                },
                child: Container(
                    width: 30.aw,
                    height: 20.ah,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      image: DecorationImage(
                          image: AssetImage('assets/image/more option.png'),
                        fit: BoxFit.contain
                      )
                    ),
                   // child: Image.asset('assets/image/more option.png',height: 16.ah,width: 15.aw,)
                )
            ),
          ),
        ],
         title: Row(
           children: [
             Container(
               height: 36.ah,
               width: 36.aw,
               decoration: BoxDecoration(
                 // borderRadius: BorderRadius.all(Radius.circular(35)),
                   color: Color(0x305B5B5B),
                   shape: BoxShape.circle,
                   border: Border.all(
                     color: Colors.black,
                     width: 1.5
                   ),
                   image: DecorationImage(
                     fit: BoxFit.fill,
                     image: AssetImage('assets/image/Ellipse 1.png'),
                   )),
               // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
             ),
             SizedBox(width: 5.aw),
             Text('Leila',
               style: TextStyle(
                 color: Colors.black,fontWeight: FontWeight.w600,fontSize:14.fSize,
               ),),
             // Text('Last Seen 10 min ago',
             //   style: TextStyle(
             //     color: Colors.black,fontWeight: FontWeight.w500,fontSize:12.fSize,
             //   ),),
           ],
         ),
        leading: Padding(
          padding:  EdgeInsets.only(left: 20.h),
          child: InkWell(
            onTap: () {
              Navigator.pop(context);
            },
              child: Icon(Icons.arrow_back_sharp)),
        ),
        backgroundColor: Colors.white,
        shadowColor: Colors.white,
        surfaceTintColor: Colors.white,

        elevation:3,
      ),

      body: Padding(
        padding: const EdgeInsets.only(left: 15,right: 15,top:35),
        child: SingleChildScrollView(
          child: Column(
            // crossAxisAlignment: CrossAxisAlignment.start,
            // mainAxisSize: MainAxisSize.min,
            // mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 296.aw, height: 50.ah,
                       decoration: BoxDecoration(
                         color: HexColor("#001649"),
                         borderRadius: BorderRadius.only(
                           bottomRight: Radius.circular(20),
                           topLeft: Radius.circular(20), topRight: Radius.circular(20),
                         )
                       ),
                        child: Center(
                          child: Text('Uses'.tr,
                            style: TextStyle(
                                color: Colors.white,fontWeight: FontWeight.w400,fontSize:16.fSize
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 10.ah),
                      Text('4.30 AM',
                        style: TextStyle(
                            color: Colors.grey,fontWeight: FontWeight.w400,fontSize:12.fSize
                        ),
                      ),
                    ],
                  ),
                ],
              ),
          
              SizedBox(height: 20.ah),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 254.aw, height: 113.ah,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                          image: DecorationImage(
                              image: AssetImage('assets/image/placeholder.png')
                          )
                        ),
          
                      ),
                      SizedBox(height: 10.ah),
                      Text('     4.31 AM',
                        style: TextStyle(
                            color: Colors.grey,fontWeight: FontWeight.w400,fontSize:12.fSize
                        ),
                      ),
                    ],
                  ),
                ],
              ),
          
              SizedBox(height: 20.ah),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    crossAxisAlignment: CrossAxisAlignment.end,
                   // mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                       // alignment: Alignment.centerLeft,
                        width: 125.aw, height: 50.ah,
                        decoration: BoxDecoration(
                            color: HexColor("#EDEDED"),
                            borderRadius: BorderRadius.only(
                              bottomRight: Radius.circular(20),bottomLeft: Radius.circular(20),
                              topLeft: Radius.circular(20),
                            )
                        ),
                        child: Center(
                          child: Text('Not bad ya',
                            style: TextStyle(
                                color: Colors.black,fontWeight: FontWeight.w400,fontSize:16.fSize
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 10.ah),
                      Text('4.30 AM',
                        style: TextStyle(
                            color: Colors.grey,fontWeight: FontWeight.w400,fontSize:12.fSize
                        ),
                      ),
                    ],
                  ),
                ],
              ),
          
              SizedBox(height: 20.ah),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 296.aw, height: 50.ah,
                        decoration: BoxDecoration(
                            color: HexColor("#001649"),
                            borderRadius: BorderRadius.only(
                              bottomRight: Radius.circular(20),
                              topLeft: Radius.circular(20), topRight: Radius.circular(20),
                            )
                        ),
                        child: Center(
                          child: Text('Uses'.tr,
                            style: TextStyle(
                                color: Colors.white,fontWeight: FontWeight.w400,fontSize:16.fSize
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 10.ah),
                      Text('4.30 AM',
                        style: TextStyle(
                            color: Colors.grey,fontWeight: FontWeight.w400,fontSize:12.fSize
                        ),
                      ),
                    ],
                  ),
                ],
              ),
          
              SizedBox(height: 20.ah),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    // mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        // alignment: Alignment.centerLeft,
                        width: 125.aw, height: 56.ah,
                        decoration: BoxDecoration(
                            color: HexColor("#EDEDED"),
                            borderRadius: BorderRadius.only(
                              bottomRight: Radius.circular(20),bottomLeft: Radius.circular(20),
                              topLeft: Radius.circular(20),
                            )
                        ),
                        child: Center(
                          child: Text('I am here \njust near u',
                            style: TextStyle(
                                color: Colors.black,fontWeight: FontWeight.w400,fontSize:16.fSize
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 10.ah),
                      Text('4.30 AM',
                        style: TextStyle(
                            color: Colors.grey,fontWeight: FontWeight.w400,fontSize:12.fSize
                        ),
                      ),
                    ],
                  ),
                ],
              ),

              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 296.aw, height: 50.ah,
                        decoration: BoxDecoration(
                            color: HexColor("#001649"),
                            borderRadius: BorderRadius.only(
                              bottomRight: Radius.circular(20),
                              topLeft: Radius.circular(20), topRight: Radius.circular(20),
                            )
                        ),
                        child: Center(
                          child: Text('Uses'.tr,
                            style: TextStyle(
                                color: Colors.white,fontWeight: FontWeight.w400,fontSize:16.fSize
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 10.ah),
                      Text('4.30 AM',
                        style: TextStyle(
                            color: Colors.grey,fontWeight: FontWeight.w400,fontSize:12.fSize
                        ),
                      ),
                    ],
                  ),
                ],
              ),

              SizedBox(height: 20.ah),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 254.aw, height: 113.ah,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            image: DecorationImage(
                                image: AssetImage('assets/image/placeholder.png')
                            )
                        ),

                      ),
                      SizedBox(height: 10.ah),
                      Text('     4.31 AM',
                        style: TextStyle(
                            color: Colors.grey,fontWeight: FontWeight.w400,fontSize:12.fSize
                        ),
                      ),
                    ],
                  ),
                ],
              ),

              SizedBox(height: 20.ah),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    // mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        // alignment: Alignment.centerLeft,
                        width: 125.aw, height: 50.ah,
                        decoration: BoxDecoration(
                            color: HexColor("#EDEDED"),
                            borderRadius: BorderRadius.only(
                              bottomRight: Radius.circular(20),bottomLeft: Radius.circular(20),
                              topLeft: Radius.circular(20),
                            )
                        ),
                        child: Center(
                          child: Text('Not bad ya',
                            style: TextStyle(
                                color: Colors.black,fontWeight: FontWeight.w400,fontSize:16.fSize
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 10.ah),
                      Text('4.30 AM',
                        style: TextStyle(
                            color: Colors.grey,fontWeight: FontWeight.w400,fontSize:12.fSize
                        ),
                      ),
                    ],
                  ),
                ],
              ),

              SizedBox(height: 20.ah),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 296.aw, height: 50.ah,
                        decoration: BoxDecoration(
                            color: HexColor("#001649"),
                            borderRadius: BorderRadius.only(
                              bottomRight: Radius.circular(20),
                              topLeft: Radius.circular(20), topRight: Radius.circular(20),
                            )
                        ),
                        child: Center(
                          child: Text('Uses'.tr,
                            style: TextStyle(
                                color: Colors.white,fontWeight: FontWeight.w400,fontSize:16.fSize
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 10.ah),
                      Text('4.30 AM',
                        style: TextStyle(
                            color: Colors.grey,fontWeight: FontWeight.w400,fontSize:12.fSize
                        ),
                      ),
                    ],
                  ),
                ],
              ),

              SizedBox(height: 20.ah),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    // mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        // alignment: Alignment.centerLeft,
                        width: 125.aw, height: 56.ah,
                        decoration: BoxDecoration(
                            color: HexColor("#EDEDED"),
                            borderRadius: BorderRadius.only(
                              bottomRight: Radius.circular(20),bottomLeft: Radius.circular(20),
                              topLeft: Radius.circular(20),
                            )
                        ),
                        child: Center(
                          child: Text('I am here \njust near u',
                            style: TextStyle(
                                color: Colors.black,fontWeight: FontWeight.w400,fontSize:16.fSize
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 10.ah),
                      Text('4.30 AM',
                        style: TextStyle(
                            color: Colors.grey,fontWeight: FontWeight.w400,fontSize:12.fSize
                        ),
                      ),
                    ],
                  ),
                ],
              ),

              SizedBox(height: 20.ah),


            ],
          ),
        ),
      ),

      bottomNavigationBar: Padding(
        padding:  EdgeInsets.only(left: 15.h,right: 15.h,bottom: 20.v),
        child:primaryTextfield7(
            hintText: 'Type message...', controller: null,
            suffix: Icon(Icons.add,color: Colors.red,size: 30,)


        ),


        /*Container(
          height: 58.ah,width: 350.aw,
          decoration: BoxDecoration(
            border: Border.all(
              color: Colors.black,width: 1,
            ),
            borderRadius: BorderRadius.circular(39),
          ),
          child: Padding(
            padding: const EdgeInsets.all(5.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Image.asset('assets/image/vet.png',width: 28.aw,height: 28.ah,fit: BoxFit.contain,),
                    SizedBox(width: 5.aw),
                    Text('Typee'.tr,
                      style: TextStyle(
                          color: Colors.grey,fontWeight: FontWeight.w500,fontSize:16.fSize
                      ),
                    ),],
                ),
                Image.asset('assets/image/Group 2235.png',height: 46.ah,width: 46.aw,fit: BoxFit.contain,),

              ],
            ),
          ),
        ),*/
      ),

    );
  }
}

//
// Row(
// mainAxisAlignment: MainAxisAlignment.end,
// crossAxisAlignment: CrossAxisAlignment.end,
// mainAxisSize: MainAxisSize.min,
// children: [
// Text(''),
// Column(
// mainAxisAlignment: MainAxisAlignment.end,
// crossAxisAlignment: CrossAxisAlignment.end,
// mainAxisSize: MainAxisSize.min,
// children: [
// Container(
// // alignment: Alignment.centerLeft,
// width: 125.aw, height: 50.ah,
// decoration: BoxDecoration(
// color: HexColor("#EDEDED"),
// borderRadius: BorderRadius.only(
// bottomRight: Radius.circular(20),bottomLeft: Radius.circular(20),
// topLeft: Radius.circular(20),
// )
// ),
// child: Center(
// child: Text('Not bad ya',
// style: TextStyle(
// color: Colors.black,fontWeight: FontWeight.w400,fontSize:16.fSize
// ),
// ),
// ),
// ),
//
// SizedBox(height: 10.ah),
// Text('4.30 AM',
// style: TextStyle(
// color: Colors.grey,fontWeight: FontWeight.w400,fontSize:12.fSize
// ),
// ),
// ],
// ),
// ],
// ),