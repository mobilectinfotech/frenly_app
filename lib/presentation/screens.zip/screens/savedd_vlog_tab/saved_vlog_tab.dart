import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:frenly_file/core/utils/size_utils.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:get/get.dart';

import '../create_password/create_password.dart';

class Saved_Tab_bar extends StatefulWidget {
  const Saved_Tab_bar({super.key});

  @override
  State<Saved_Tab_bar> createState() => _Saved_Tab_barState();
}

class _Saved_Tab_barState extends State<Saved_Tab_bar> {


  List<bool> active = [false, false, ];

  List<String> follow_Unfollow = [
    "Follow",
    "Unfollow",
  ];

  var selectone;
  late TabController tabController;
  int _tabIndex = 0;
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length:4,
      child: Scaffold(
        backgroundColor: HexColor('#E8E8E8'),
        body: Padding(
          padding:  EdgeInsets.only(left: 10.h,right: 10.h,top: 75.v),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              TabBar(
                automaticIndicatorColorAdjustment: false,
                indicatorColor: Colors.transparent,
                indicatorWeight: 2,
                dividerColor: Colors.transparent,
                indicator: BoxDecoration(
                  borderRadius: BorderRadius.circular(8.0,),
                  color: colors[_tabIndex],
                ),

                labelStyle: const TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w500),
                unselectedLabelColor: Colors.grey,

                padding: EdgeInsets.all(10),

                //indicatorColor: Colors.blueGrey,
                // overlayColor: MaterialStateProperty.resolveWith<Color?>(
                //       (Set<MaterialState> states) {
                //     if (states.contains(MaterialState.hovered))
                //       return Colors.red; //<-- SEE HERE
                //     return null;
                //   },
                // ),

                tabs: [
                  Tab(
                    //icon: Icon(Icons.chat_bubble),
                    child: Container(
                      height: 40.ah,
                      //width:MediaQuery.of(context).size.width,
                      width:83.aw,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                         //color: HexColor('#001649')
                      ),
                      child:  Center(
                        child: Text('Vlogs'.tr,
                         // style: TextStyle(color: Colors.white,fontWeight: FontWeight.w500,fontSize:16.fSize),
                        ),
                      ),
                    ),
                  ),

                  Tab(
                    child: Container(
                      height: 40.ah,width:112.aw,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        // color: HexColor('#001649')
                      ),
                      child:  Center(
                        child: Text('Blogs'.tr,
                          // style: TextStyle(color: Colors.grey,fontWeight: FontWeight.w500,fontSize:18.fSize),
                        ),
                      ),),
                  ),

                  Tab(
                    child: Container(
                      height: 40.ah,width:112.aw,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        // color: HexColor('#001649')
                      ),
                      child:  Center(
                        child: Text('Photos'.tr,
                          //style: TextStyle(color: Colors.grey,fontWeight: FontWeight.w500,fontSize:18.fSize),
                        ),
                      ),
                    ),
                  ),

                  Tab(
                    child: Container(
                      height: 40.ah,width:112.aw,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        // color: HexColor('#001649')
                      ),
                      child:  Center(
                        child: Text('Profile'.tr,
                          //style: TextStyle(color: Colors.grey,fontWeight: FontWeight.w500,fontSize:18.fSize),
                        ),
                      ),
                    ),
                  ),
                ],
              ),

              Expanded(
                child:  Padding(
                  padding:  EdgeInsets.only(left: 10.h,right: 10.h),
                  child: TabBarView(
                    children: [
                      SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Stack(
                              alignment: Alignment.topLeft,
                              children: [
                                Container(
                                  height: 196.ah,width:MediaQuery.of(context).size.width,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(25),
                                    // color: Colors.grey,
                                    image: DecorationImage(
                                        alignment: Alignment.center,fit: BoxFit.fill,
                                        image: AssetImage('assets/image/Frame 21150.png')
                                    ),

                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(left:10,right: 15,top: 10),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Row(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Icon(Icons.location_on,color: Colors.white,),
                                              // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                              Text('Sydney, Australia',
                                                style: TextStyle(
                                                  color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                                ),),
                                            ],
                                          ),
                                          Image.asset('assets/image/more op.png',width:22.aw,height: 16.ah,),
                                        ],
                                      ),
                                      SizedBox(height: 60.ah),
                                      Text('Circle'.tr,
                                        style: TextStyle(
                                            color: HexColor('#FFFFFF'),fontWeight: FontWeight.w700,fontSize:16.fSize,
                                            height:1.5
                                        ),
                                      ),
                                      SizedBox(height:10.ah),
                                      Row(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                height: 24.ah,
                                                width: 24.aw,
                                                decoration: BoxDecoration(
                                                  // borderRadius: BorderRadius.all(Radius.circular(35)),
                                                    color: Color(0x305B5B5B),
                                                    shape: BoxShape.circle,
                                                    image: DecorationImage(
                                                      fit: BoxFit.fill,
                                                      image: AssetImage('assets/image/Ellipse 1.png'),
                                                    )),
                                                // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                                              ),
                                              // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                              Text('   Kriston',
                                                style: TextStyle(
                                                  color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                                ),),
                                              Text('  125K views',
                                                style: TextStyle(
                                                  color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                                ),),
                                              Text('  3 weeks ago',
                                                style: TextStyle(
                                                  color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                                ),),

                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment. spaceBetween,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Image.asset('assets/image/Unionnn.png',width:21.aw,height:21.ah,),
                                              SizedBox(width: 5.aw),
                                              Image.asset('assets/image/rename.png',width:22.aw,height:21.ah,),
                                              SizedBox(width: 5.aw),
                                              Image.asset('assets/image/bookmark.png',width:22.aw,height:21.ah,),

                                            ],
                                          )

                                        ],
                                      ),
                                    ],
                                  ),
                                ),

                              ],
                            ),

                            SizedBox(height: 15.ah),
                            Stack(
                              alignment: Alignment.topLeft,
                              children: [
                                Container(
                                  height: 196.ah,width:MediaQuery.of(context).size.width,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(25),
                                    // color: Colors.grey,
                                    image: DecorationImage(
                                        alignment: Alignment.center,fit: BoxFit.fill,
                                        image: AssetImage('assets/image/Frame 21150.png')
                                    ),

                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(left:10,right: 15,top: 10),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Row(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Icon(Icons.location_on,color: Colors.white,),
                                              // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                              Text('Sydney, Australia',
                                                style: TextStyle(
                                                  color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                                ),),
                                            ],
                                          ),
                                          Image.asset('assets/image/more op.png',width:22.aw,height: 16.ah,),
                                        ],
                                      ),
                                      SizedBox(height: 60.ah),
                                      Text('Circle'.tr,
                                        style: TextStyle(
                                            color: HexColor('#FFFFFF'),fontWeight: FontWeight.w700,fontSize:16.fSize,
                                            height:1.5
                                        ),
                                      ),
                                      SizedBox(height:10.ah),
                                      Row(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                height: 24.ah,
                                                width: 24.aw,
                                                decoration: BoxDecoration(
                                                  // borderRadius: BorderRadius.all(Radius.circular(35)),
                                                    color: Color(0x305B5B5B),
                                                    shape: BoxShape.circle,
                                                    image: DecorationImage(
                                                      fit: BoxFit.fill,
                                                      image: AssetImage('assets/image/Ellipse 1.png'),
                                                    )),
                                                // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                                              ),
                                              // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                              Text('   Kriston',
                                                style: TextStyle(
                                                  color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                                ),),
                                              Text('  125K views',
                                                style: TextStyle(
                                                  color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                                ),),
                                              Text('  3 weeks ago',
                                                style: TextStyle(
                                                  color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                                ),),

                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment. spaceBetween,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Image.asset('assets/image/Unionnn.png',width:21.aw,height:21.ah,),
                                              SizedBox(width: 5.aw),
                                              Image.asset('assets/image/rename.png',width:22.aw,height:21.ah,),
                                              SizedBox(width: 5.aw),
                                              Image.asset('assets/image/bookmark.png',width:22.aw,height:21.ah,),

                                            ],
                                          )
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),

                            SizedBox(height: 15.ah),
                            Stack(
                              alignment: Alignment.topLeft,
                              children: [
                                Container(
                                  height: 196.ah,width:MediaQuery.of(context).size.width,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(25),
                                    // color: Colors.grey,
                                    image: DecorationImage(
                                        alignment: Alignment.center,fit: BoxFit.fill,
                                        image: AssetImage('assets/image/Frame 21150.png')
                                    ),

                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(left:10,right: 15,top: 10),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Row(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Icon(Icons.location_on,color: Colors.white,),
                                              // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                              Text('Sydney, Australia',
                                                style: TextStyle(
                                                  color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                                ),),
                                            ],
                                          ),
                                          Image.asset('assets/image/more op.png',width:22.aw,height: 16.ah,),
                                        ],
                                      ),
                                      SizedBox(height: 60.ah),
                                      Text('Circle'.tr,
                                        style: TextStyle(
                                            color: HexColor('#FFFFFF'),fontWeight: FontWeight.w700,fontSize:16.fSize,
                                            height:1.5
                                        ),
                                      ),
                                      SizedBox(height:10.ah),
                                      Row(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                height: 24.ah,
                                                width: 24.aw,
                                                decoration: BoxDecoration(
                                                  // borderRadius: BorderRadius.all(Radius.circular(35)),
                                                    color: Color(0x305B5B5B),
                                                    shape: BoxShape.circle,
                                                    image: DecorationImage(
                                                      fit: BoxFit.fill,
                                                      image: AssetImage('assets/image/Ellipse 1.png'),
                                                    )),
                                                // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                                              ),
                                              // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                              Text('   Kriston',
                                                style: TextStyle(
                                                  color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                                ),),
                                              Text('  125K views',
                                                style: TextStyle(
                                                  color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                                ),),
                                              Text('  3 weeks ago',
                                                style: TextStyle(
                                                  color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                                ),),

                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment. spaceBetween,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Image.asset('assets/image/Unionnn.png',width:21.aw,height:21.ah,),
                                              SizedBox(width: 5.aw),
                                              Image.asset('assets/image/rename.png',width:22.aw,height:21.ah,),
                                              SizedBox(width: 5.aw),
                                              Image.asset('assets/image/bookmark.png',width:22.aw,height:21.ah,),

                                            ],
                                          )

                                        ],
                                      ),
                                    ],
                                  ),
                                ),

                              ],
                            ),
                            SizedBox(height: 15.ah),

                          ],
                        ),
                      ),

                      SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [

                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      height: 144.ah,width: 144.aw,
                                      decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(15),
                                          image: DecorationImage(
                                              image: AssetImage('assets/image/Frame 21150 (2).png')
                                          )
                                      ),
                                    ),
                                    SizedBox(width:5.aw,),
                                    Column(
                                      mainAxisSize: MainAxisSize.min,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Container(
                                              height: 20.ah,width: 60.aw,
                                              decoration: BoxDecoration(
                                                  border: Border.all(
                                                      color: Colors.black,
                                                      width: 0.3
                                                  ),
                                                  borderRadius: BorderRadius.circular(5),
                                                  color: Colors.grey.shade300
                                              ),
                                              child:  Center(
                                                child: Text('Cooking'.tr,
                                                  style: TextStyle(
                                                      color: Colors.grey,fontWeight: FontWeight.w500,fontSize:10.fSize
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                        SizedBox(height: 5.ah),
                                        Text('letmeee'.tr,
                                          style: TextStyle(
                                              color: Colors.black,fontWeight: FontWeight.w600,fontSize:20.fSize
                                          ),
                                        ),
                                        SizedBox(height: 5.ah),
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              height: 32.ah,
                                              width: 32.aw,
                                              decoration: BoxDecoration(
                                                // borderRadius: BorderRadius.all(Radius.circular(35)),
                                                  color: Color(0x305B5B5B),
                                                  shape: BoxShape.circle,
                                                  image: DecorationImage(
                                                    fit: BoxFit.fill,
                                                    image: AssetImage('assets/image/Frame 427320834.png'),
                                                  )),
                                              // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                                            ),
                                            SizedBox(width: 10.aw),
                                            Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              mainAxisAlignment: MainAxisAlignment.center,
                                              children: [
                                                Text('Naila Iman',
                                                  style: TextStyle(
                                                    color: Colors.black,fontWeight: FontWeight.w600,fontSize:14.fSize,
                                                  ),),
                                                Text('Kriston.3 weeks'.tr,
                                                  style: TextStyle(
                                                    color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize,
                                                  ),),
                                              ],
                                            ),

                                          ],
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                Image.asset('assets/image/more option.png',height: 16.ah,width: 4.aw,),

                              ],
                            ),

                            SizedBox(height: 15.ah),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      height: 144.ah,width: 144.aw,
                                      decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(15),
                                          image: DecorationImage(
                                              image: AssetImage('assets/image/Frame 21150 (2).png')
                                          )
                                      ),
                                    ),
                                    SizedBox(width:5.aw,),
                                    Column(
                                      mainAxisSize: MainAxisSize.min,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Container(
                                              height: 20.ah,width: 60.aw,
                                              decoration: BoxDecoration(
                                                  border: Border.all(
                                                      color: Colors.black,
                                                      width: 0.3
                                                  ),
                                                  borderRadius: BorderRadius.circular(5),
                                                  color: Colors.grey.shade300
                                              ),
                                              child:  Center(
                                                child: Text('Cooking'.tr,
                                                  style: TextStyle(
                                                      color: Colors.grey,fontWeight: FontWeight.w500,fontSize:10.fSize
                                                  ),
                                                ),
                                              ),
                                            ),

                                          ],
                                        ),
                                        SizedBox(height: 5.ah),
                                        Text('letme'.tr,
                                          style: TextStyle(
                                              color: Colors.black,fontWeight: FontWeight.w600,fontSize:20.fSize
                                          ),
                                        ),
                                        SizedBox(height: 5.ah),
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              height: 32.ah,
                                              width: 32.aw,
                                              decoration: BoxDecoration(
                                                // borderRadius: BorderRadius.all(Radius.circular(35)),
                                                  color: Color(0x305B5B5B),
                                                  shape: BoxShape.circle,
                                                  image: DecorationImage(
                                                    fit: BoxFit.fill,
                                                    image: AssetImage('assets/image/Frame 427320834.png'),
                                                  )),
                                              // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                                            ),
                                            SizedBox(width: 10.aw),
                                            Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              mainAxisAlignment: MainAxisAlignment.center,
                                              children: [
                                                Text('Naila Iman',
                                                  style: TextStyle(
                                                    color: Colors.black,fontWeight: FontWeight.w600,fontSize:14.fSize,
                                                  ),),
                                                Text('Kriston.3 weeks'.tr,
                                                  style: TextStyle(
                                                    color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize,
                                                  ),),
                                              ],
                                            ),

                                          ],
                                        ),
                                      ],
                                    ),

                                  ],
                                ),
                                Image.asset('assets/image/more option.png',height: 16.ah,width: 4.aw,),

                              ],
                            ),

                            SizedBox(height: 15.ah),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      height: 144.ah,width: 144.aw,
                                      decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(15),
                                          image: DecorationImage(
                                              image: AssetImage('assets/image/Frame 21150 (2).png')
                                          )
                                      ),
                                    ),
                                    SizedBox(width:5.aw,),
                                    Column(
                                      mainAxisSize: MainAxisSize.min,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Container(
                                              height: 20.ah,width: 60.aw,
                                              decoration: BoxDecoration(
                                                  border: Border.all(
                                                      color: Colors.black,
                                                      width: 0.3
                                                  ),
                                                  borderRadius: BorderRadius.circular(5),
                                                  color: Colors.grey.shade300
                                              ),
                                              child:  Center(
                                                child: Text('Cooking'.tr,
                                                  style: TextStyle(
                                                      color: Colors.grey,fontWeight: FontWeight.w500,fontSize:10.fSize
                                                  ),
                                                ),
                                              ),
                                            ),

                                          ],
                                        ),
                                        SizedBox(height: 5.ah),
                                        Text('letme'.tr,
                                          style: TextStyle(
                                              color: Colors.black,fontWeight: FontWeight.w600,fontSize:20.fSize
                                          ),
                                        ),
                                        SizedBox(height: 5.ah),
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              height: 32.ah,
                                              width: 32.aw,
                                              decoration: BoxDecoration(
                                                // borderRadius: BorderRadius.all(Radius.circular(35)),
                                                  color: Color(0x305B5B5B),
                                                  shape: BoxShape.circle,
                                                  image: DecorationImage(
                                                    fit: BoxFit.fill,
                                                    image: AssetImage('assets/image/Frame 427320834.png'),
                                                  )),
                                              // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                                            ),
                                            SizedBox(width: 10.aw),
                                            Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              mainAxisAlignment: MainAxisAlignment.center,
                                              children: [
                                                Text('Naila Iman',
                                                  style: TextStyle(
                                                    color: Colors.black,fontWeight: FontWeight.w600,fontSize:14.fSize,
                                                  ),),
                                                Text('Kriston.3 weeks'.tr,
                                                  style: TextStyle(
                                                    color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize,
                                                  ),),
                                              ],
                                            ),

                                          ],
                                        ),
                                      ],
                                    ),

                                  ],
                                ),
                                Image.asset('assets/image/more option.png',height: 16.ah,width: 4.aw,),

                              ],
                            ),

                            SizedBox(height: 15.ah),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      height: 144.ah,width: 144.aw,
                                      decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(15),
                                          image: DecorationImage(
                                              image: AssetImage('assets/image/Frame 21150 (2).png')
                                          )
                                      ),
                                    ),
                                    SizedBox(width:5.aw,),
                                    Column(
                                      mainAxisSize: MainAxisSize.min,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Container(
                                              height: 20.ah,width: 60.aw,
                                              decoration: BoxDecoration(
                                                  border: Border.all(
                                                      color: Colors.black,
                                                      width: 0.3
                                                  ),
                                                  borderRadius: BorderRadius.circular(5),
                                                  color: Colors.grey.shade300
                                              ),
                                              child:  Center(
                                                child: Text('Cooking'.tr,
                                                  style: TextStyle(
                                                      color: Colors.grey,fontWeight: FontWeight.w500,fontSize:10.fSize
                                                  ),
                                                ),
                                              ),
                                            ),

                                          ],
                                        ),
                                        SizedBox(height: 5.ah),
                                        Text('letme'.tr,
                                          style: TextStyle(
                                              color: Colors.black,fontWeight: FontWeight.w600,fontSize:20.fSize
                                          ),
                                        ),
                                        SizedBox(height: 5.ah),
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              height: 32.ah,
                                              width: 32.aw,
                                              decoration: BoxDecoration(
                                                // borderRadius: BorderRadius.all(Radius.circular(35)),
                                                  color: Color(0x305B5B5B),
                                                  shape: BoxShape.circle,
                                                  image: DecorationImage(
                                                    fit: BoxFit.fill,
                                                    image: AssetImage('assets/image/Frame 427320834.png'),
                                                  )),
                                              // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                                            ),
                                            SizedBox(width: 10.aw),
                                            Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              mainAxisAlignment: MainAxisAlignment.center,
                                              children: [
                                                Text('Naila Iman',
                                                  style: TextStyle(
                                                    color: Colors.black,fontWeight: FontWeight.w600,fontSize:14.fSize,
                                                  ),),
                                                Text('Kriston.3 weeks'.tr,
                                                  style: TextStyle(
                                                    color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize,
                                                  ),),
                                              ],
                                            ),

                                          ],
                                        ),
                                      ],
                                    ),

                                  ],
                                ),
                                Image.asset('assets/image/more option.png',height: 16.ah,width: 4.aw,),

                              ],
                            ),
                          ],
                        ),
                      ),

                      SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Image.asset('assets/image/Frame 21150 (2).png',height: 120.ah,width: 120.aw,fit: BoxFit.fill,),
                                Image.asset('assets/image/Frame 21158.png',height: 120.ah,width: 120.aw,fit: BoxFit.fill,),
                                Image.asset('assets/image/Frame 21150 (2).png',height: 120.ah,width: 120.aw,fit: BoxFit.fill,),
                              ],
                            ),
                            SizedBox(height: 10.ah),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Image.asset('assets/image/Frame 21160.png',height: 120.ah,width: 120.aw,fit: BoxFit.fill,),
                                    SizedBox(height: 8.ah),
                                    Image.asset('assets/image/Frame 21150 (2).png',height: 120.ah,width: 120.aw,fit: BoxFit.fill,),

                                  ],
                                ),
                                SizedBox(width: 5.aw,),
                                Image.asset('assets/image/Frame 21161.png',height:252.ah,width:243.aw,fit: BoxFit.fill,),

                              ],
                            ),
                            SizedBox(height: 10.ah),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [

                                Image.asset('assets/image/Frame 21161.png',height:252.ah,width:243.aw,fit: BoxFit.fill,),
                                SizedBox(width: 5.aw,),
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Image.asset('assets/image/Frame 21160.png',height: 120.ah,width: 120.aw,fit: BoxFit.fill,),
                                    SizedBox(height: 8.ah),
                                    Image.asset('assets/image/Frame 21150 (2).png',height: 120.ah,width: 120.aw,fit: BoxFit.fill,),

                                  ],
                                ),

                              ],
                            ),

                          ],
                        ),
                      ),

                      SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Stack(
                              alignment: Alignment.topLeft,
                              children: [
                                Container(
                                  height: 196.ah,width:MediaQuery.of(context).size.width,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(25),
                                    // color: Colors.grey,
                                    image: DecorationImage(
                                        alignment: Alignment.center,fit: BoxFit.fill,
                                        image: AssetImage('assets/image/Frame 21150.png')
                                    ),

                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(left:10,right: 15,top: 10),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Row(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Icon(Icons.location_on,color: Colors.white,),
                                              // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                              Text('Sydney, Australia',
                                                style: TextStyle(
                                                  color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                                ),),
                                            ],
                                          ),
                                          Image.asset('assets/image/more op.png',width:22.aw,height: 16.ah,),
                                        ],
                                      ),
                                      SizedBox(height: 60.ah),
                                      Text('Circle'.tr,
                                        style: TextStyle(
                                            color: HexColor('#FFFFFF'),fontWeight: FontWeight.w700,fontSize:16.fSize,
                                            height:1.5
                                        ),
                                      ),
                                      SizedBox(height:10.ah),
                                      Row(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                height: 24.ah,
                                                width: 24.aw,
                                                decoration: BoxDecoration(
                                                  // borderRadius: BorderRadius.all(Radius.circular(35)),
                                                    color: Color(0x305B5B5B),
                                                    shape: BoxShape.circle,
                                                    image: DecorationImage(
                                                      fit: BoxFit.fill,
                                                      image: AssetImage('assets/image/Ellipse 1.png'),
                                                    )),
                                                // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                                              ),
                                              // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                              Text('   Kriston',
                                                style: TextStyle(
                                                  color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                                ),),
                                              Text('  125K views',
                                                style: TextStyle(
                                                  color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                                ),),
                                              Text('  3 weeks ago',
                                                style: TextStyle(
                                                  color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                                ),),

                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment. spaceBetween,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Image.asset('assets/image/Unionnn.png',width:21.aw,height:21.ah,),
                                              SizedBox(width: 5.aw),
                                              Image.asset('assets/image/rename.png',width:22.aw,height:21.ah,),
                                              SizedBox(width: 5.aw),
                                              Image.asset('assets/image/bookmark.png',width:22.aw,height:21.ah,),

                                            ],
                                          )

                                        ],
                                      ),
                                    ],
                                  ),
                                ),

                              ],
                            ),

                            SizedBox(height: 15.ah),
                            Stack(
                              alignment: Alignment.topLeft,
                              children: [
                                Container(
                                  height: 196.ah,width:MediaQuery.of(context).size.width,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(25),
                                    // color: Colors.grey,
                                    image: DecorationImage(
                                        alignment: Alignment.center,fit: BoxFit.fill,
                                        image: AssetImage('assets/image/Frame 21150.png')
                                    ),

                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(left:10,right: 15,top: 10),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Row(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Icon(Icons.location_on,color: Colors.white,),
                                              // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                              Text('Sydney, Australia',
                                                style: TextStyle(
                                                  color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                                ),),
                                            ],
                                          ),
                                          Image.asset('assets/image/more op.png',width:22.aw,height: 16.ah,),
                                        ],
                                      ),
                                      SizedBox(height: 60.ah),
                                      Text('Circle'.tr,
                                        style: TextStyle(
                                            color: HexColor('#FFFFFF'),fontWeight: FontWeight.w700,fontSize:16.fSize,
                                            height:1.5
                                        ),
                                      ),
                                      SizedBox(height:10.ah),
                                      Row(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                height: 24.ah,
                                                width: 24.aw,
                                                decoration: BoxDecoration(
                                                  // borderRadius: BorderRadius.all(Radius.circular(35)),
                                                    color: Color(0x305B5B5B),
                                                    shape: BoxShape.circle,
                                                    image: DecorationImage(
                                                      fit: BoxFit.fill,
                                                      image: AssetImage('assets/image/Ellipse 1.png'),
                                                    )),
                                                // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                                              ),
                                              // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                              Text('   Kriston',
                                                style: TextStyle(
                                                  color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                                ),),
                                              Text('  125K views',
                                                style: TextStyle(
                                                  color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                                ),),
                                              Text('  3 weeks ago',
                                                style: TextStyle(
                                                  color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                                ),),

                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment. spaceBetween,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Image.asset('assets/image/Unionnn.png',width:21.aw,height:21.ah,),
                                              SizedBox(width: 5.aw),
                                              Image.asset('assets/image/rename.png',width:22.aw,height:21.ah,),
                                              SizedBox(width: 5.aw),
                                              Image.asset('assets/image/bookmark.png',width:22.aw,height:21.ah,),

                                            ],
                                          )
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),

                            SizedBox(height: 15.ah),
                            Stack(
                              alignment: Alignment.topLeft,
                              children: [
                                Container(
                                  height: 196.ah,width:MediaQuery.of(context).size.width,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(25),
                                    // color: Colors.grey,
                                    image: DecorationImage(
                                        alignment: Alignment.center,fit: BoxFit.fill,
                                        image: AssetImage('assets/image/Frame 21150.png')
                                    ),

                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(left:10,right: 15,top: 10),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Row(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Icon(Icons.location_on,color: Colors.white,),
                                              // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                              Text('Sydney, Australia',
                                                style: TextStyle(
                                                  color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                                ),),
                                            ],
                                          ),
                                          Image.asset('assets/image/more op.png',width:22.aw,height: 16.ah,),
                                        ],
                                      ),
                                      SizedBox(height: 60.ah),
                                      Text('Circle'.tr,
                                        style: TextStyle(
                                            color: HexColor('#FFFFFF'),fontWeight: FontWeight.w700,fontSize:16.fSize,
                                            height:1.5
                                        ),
                                      ),
                                      SizedBox(height:10.ah),
                                      Row(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                height: 24.ah,
                                                width: 24.aw,
                                                decoration: BoxDecoration(
                                                  // borderRadius: BorderRadius.all(Radius.circular(35)),
                                                    color: Color(0x305B5B5B),
                                                    shape: BoxShape.circle,
                                                    image: DecorationImage(
                                                      fit: BoxFit.fill,
                                                      image: AssetImage('assets/image/Ellipse 1.png'),
                                                    )),
                                                // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                                              ),
                                              // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                              Text('   Kriston',
                                                style: TextStyle(
                                                  color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                                ),),
                                              Text('  125K views',
                                                style: TextStyle(
                                                  color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                                ),),
                                              Text('  3 weeks ago',
                                                style: TextStyle(
                                                  color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                                ),),

                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment. spaceBetween,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Image.asset('assets/image/Unionnn.png',width:21.aw,height:21.ah,),
                                              SizedBox(width: 5.aw),
                                              Image.asset('assets/image/rename.png',width:22.aw,height:21.ah,),
                                              SizedBox(width: 5.aw),
                                              Image.asset('assets/image/bookmark.png',width:22.aw,height:21.ah,),

                                            ],
                                          )

                                        ],
                                      ),
                                    ],
                                  ),
                                ),

                              ],
                            ),
                            SizedBox(height: 15.ah),

                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),

            ],
          ),
        ),
      ),
    );
  }
}
