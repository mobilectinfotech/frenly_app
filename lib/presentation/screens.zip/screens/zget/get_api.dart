
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'get_controoler.dart';
import 'package:get/get.dart';

class GetApi extends StatefulWidget {
  const GetApi({super.key});

  @override
  State<GetApi> createState() => _GetApiState();
}

class _GetApiState extends State<GetApi> {


  RamControllewr controller = Get.put(RamControllewr());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Obx(
        ()=>controller.isLoading.value ? Center(child:CircularProgressIndicator()): ListView.builder(
          shrinkWrap: true,
          itemCount: controller.demoModel.productInfo!.length,
          itemBuilder:(context, index) {
            return Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Image.network(controller.demoModel.productInfo![index].productImage.toString()),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(controller.demoModel.productInfo![index].productName.toString()),
                    Container(
                      width: 200,
                      child: Text(controller.demoModel.productInfo![index].description.toString(),
                      maxLines: 2,),
                    )
                  ]),
              ],
            );
          },),
      )
      );

  }
}

/*class Fetch extends StatefulWidget {
  const Fetch({super.key});

  @override
  State<Fetch> createState() => _FetchState();
}

class _FetchState extends State<Fetch> {
  late BuildContext context;
  //ApiService apiService;
  late SharedPreferences sharedPreferences;

  @override
  void initState() {
    super.initState();
    apiService = ApiService();
    fetchUser();
  }
  Future<List<Profile>> fetchUser() async {
    sharedPreferences = await SharedPreferences.getInstance();
    int id = sharedPreferences.getInt("id");
    final response = await client.get('$baseUrl/user/$id');
    if(response.statusCode == 200){
      return userFromJson(response.body);
    }else return null;
  }
  getProfiles()async{
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    int? id = sharedPreferences.getInt("id");
    // perform http request to get UserProfile
  }
  @override
  Widget build(BuildContext context) {
    this.context = context;
    return SafeArea(
      child: FutureBuilder(
        future: fetchUser(),
        builder: (BuildContext context, AsyncSnapshot<List<Profile>> snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Text(
                  "Something wrong with message: ${snapshot.error.toString()}"),
            );
          } else if (snapshot.connectionState == ConnectionState.done) {
            User user = snapshot.data;
            return _buildListView(user);
          } else {
            return Center(
              child: CircularProgressIndicator(),
            );
          }
        },
      ),
    );
  }
}*/
