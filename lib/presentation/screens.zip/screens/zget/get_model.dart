// To parse this JSON data, do
//
//     final familyMembersModel = familyMembersModelFromJson(jsonString);

import 'dart:convert';

FamilyMembersModel familyMembersModelFromJson(String str) => FamilyMembersModel.fromJson(json.decode(str));

String familyMembersModelToJson(FamilyMembersModel data) => json.encode(data.toJson());

class FamilyMembersModel {
  int status;
  String message;
  bool success;
  List<FamilyDetail> familyDetails;

  FamilyMembersModel({
    required this.status,
    required this.message,
    required this.success,
    required this.familyDetails,
  });

  factory FamilyMembersModel.fromJson(Map<String, dynamic> json) => FamilyMembersModel(
    status: json["status"],
    message: json["message"],
    success: json["success"],
    familyDetails: List<FamilyDetail>.from(json["familyDetails"].map((x) => FamilyDetail.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "success": success,
    "familyDetails": List<dynamic>.from(familyDetails.map((x) => x.toJson())),
  };
}

class FamilyDetail {
  int id;
  int familyId;
  String userName;
  int levelAtTree;
  String firstName;
  String lastName;
  String gender;
  String imageLink;
  String maritalStatus;
  String hasChild;
  DateTime createdAt;
  DateTime updatedAt;

  FamilyDetail({
    required this.id,
    required this.familyId,
    required this.userName,
    required this.levelAtTree,
    required this.firstName,
    required this.lastName,
    required this.gender,
    required this.imageLink,
    required this.maritalStatus,
    required this.hasChild,
    required this.createdAt,
    required this.updatedAt,
  });

  factory FamilyDetail.fromJson(Map<String, dynamic> json) => FamilyDetail(
    id: json["id"],
    familyId: json["family_id"],
    userName: json["user_name"],
    levelAtTree: json["level_at_tree"],
    firstName: json["first_name"],
    lastName: json["last_name"],
    gender: json["gender"],
    imageLink: json["image_link"],
    maritalStatus: json["marital_status"],
    hasChild: json["has_child"],
    createdAt: DateTime.parse(json["created_at"]),
    updatedAt: DateTime.parse(json["updated_at"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "family_id": familyId,
    "user_name": userName,
    "level_at_tree": levelAtTree,
    "first_name": firstName,
    "last_name": lastName,
    "gender": gender,
    "image_link": imageLink,
    "marital_status": maritalStatus,
    "has_child": hasChild,
    "created_at": createdAt.toIso8601String(),
    "updated_at": updatedAt.toIso8601String(),
  };
}


List<UserModels> userModelsFromJson(String str) =>
    List<UserModels>.from(json.decode(str).map((x) => UserModels.fromJson(x)));

String userModelsToJson(List<UserModels> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class UserModels {
  int id;
  String name;
  String position;

  UserModels({
    required this.id,
    required this.name,
    required this.position,
  });
// `toJson` converts a UserModels object to a JSON representation.
// `fromJson` creates a UserModels object from a JSON map.

  factory UserModels.fromJson(Map<String, dynamic> json) => UserModels(
    id: json["id"],
    name: json["name"],
    position: json["position"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "position": position,
  };
}


class Skinmodel {
  int? status;
  bool? success;
  String? message;
  List<ProductInfo>? productInfo;

  Skinmodel({this.status, this.success, this.message, this.productInfo});

  Skinmodel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    success = json['success'];
    message = json['message'];
    if (json['product_info'] != null) {
      productInfo = <ProductInfo>[];
      json['product_info'].forEach((v) {
        productInfo!.add(new ProductInfo.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['success'] = this.success;
    data['message'] = this.message;
    if (this.productInfo != null) {
      data['product_info'] = this.productInfo!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class ProductInfo {
  String? productName;
  String? productImage;
  String? description;

  ProductInfo({this.productName, this.productImage, this.description});

  ProductInfo.fromJson(Map<String, dynamic> json) {
    productName = json['product_name'];
    productImage = json['product_image'];
    description = json['description'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['product_name'] = this.productName;
    data['product_image'] = this.productImage;
    data['description'] = this.description;
    return data;
  }
}


