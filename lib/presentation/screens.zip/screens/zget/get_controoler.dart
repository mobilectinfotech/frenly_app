import 'dart:convert';

import 'package:frenly_file/presentation/screens/zget/dggdsg_model.dart';
import 'package:get/get.dart';
import 'package:dio/dio.dart';

class RamControllewr extends GetxController{


  RxBool isLoading = false.obs;

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    getData();
  }

  DemoModel demoModel = DemoModel();

  Future<void> getData() async {
    isLoading(true);
    var data = {};
    var dio = Dio();
    var response = await dio.request(
      'http://18.233.72.175:4000/Get_all_product',
      options: Options(
        method: 'GET',
      ),
      data: data,
    );

    if (response.statusCode == 200) {

      demoModel =DemoModel.fromJson(response.data);
      isLoading(false);
      print(json.encode(response.data));
    }
    else {
      print(response.statusMessage);
    }
  }



}