// To parse this JSON data, do
//
//     final demoModel = demoModelFromJson(jsonString);

import 'dart:convert';

DemoModel demoModelFromJson(String str) => DemoModel.fromJson(json.decode(str));

String demoModelToJson(DemoModel data) => json.encode(data.toJson());

class DemoModel {
  int? status;
  bool? success;
  String? message;
  List<ProductInfo>? productInfo;

  DemoModel({
    this.status,
    this.success,
    this.message,
    this.productInfo,
  });

  factory DemoModel.fromJson(Map<String, dynamic> json) => DemoModel(
    status: json["status"],
    success: json["success"],
    message: json["message"],
    productInfo: json["product_info"] == null ? [] : List<ProductInfo>.from(json["product_info"]!.map((x) => ProductInfo.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "success": success,
    "message": message,
    "product_info": productInfo == null ? [] : List<dynamic>.from(productInfo!.map((x) => x.toJson())),
  };
}

class ProductInfo {
  String? productName;
  String? productImage;
  String? description;

  ProductInfo({
    this.productName,
    this.productImage,
    this.description,
  });

  factory ProductInfo.fromJson(Map<String, dynamic> json) => ProductInfo(
    productName: json["product_name"],
    productImage: json["product_image"],
    description: json["description"],
  );

  Map<String, dynamic> toJson() => {
    "product_name": productName,
    "product_image": productImage,
    "description": description,
  };
}
