import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:frenly_file/presentation/screens/saved_blog/saved_blog.dart';
import 'package:frenly_file/presentation/screens/saved_photo/saved_photo.dart';
import 'package:frenly_file/presentation/screens/saved_vlogs/saved_vlogs.dart';
import 'package:frenly_file/presentation/screens/settings_screen/setting_screen.dart';
import 'package:frenly_file/core/utils/size_utils.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:get/get.dart';


class SavedPeople_profile extends StatefulWidget {
  const SavedPeople_profile({super.key});

  @override
  State<SavedPeople_profile> createState() => _SavedPeople_profileState();
}

class _SavedPeople_profileState extends State<SavedPeople_profile> {
  List<bool> active = [false, false, ];
  List<String> follow_Unfollow = [
    "Follow",
    "Unfollow",
  ];

  var selectone;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        surfaceTintColor: Colors.white,
        backgroundColor: Colors.white,
        //shadowColor: Colors.white,
        title: Row(
          children: [
            Text('Fashion'.tr,
              style: TextStyle(
                  color: Colors.black,fontWeight: FontWeight.w700,fontSize:32.fSize
              ),
            ),
          ],
        ),
        leading: Padding(
          padding:  EdgeInsets.only(left: 15.h),
          child: InkWell(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => Setting_Screen()));
              },
              child: Icon(Icons.arrow_back_sharp)),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              height: 36.ah,
              width: 36.aw,
              decoration: BoxDecoration(
                // borderRadius: BorderRadius.all(Radius.circular(35)),
                  color: Color(0x305B5B5B),
                  shape: BoxShape.circle,
                  image: DecorationImage(
                    fit: BoxFit.fill,
                    image: AssetImage('assets/image/Ellipse 1.png'),
                  )),
              // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.only(left: 10,right: 10,top:20),
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                height: 52.ah,width: 358.aw,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10)
                ),
                child: Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      InkWell(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => Save_Vlogs_Screen()));
                        },
                        child: Container(
                          height: 40.ah,width:83.aw,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                            // color: HexColor('#001649')
                          ),
                          child:  Center(
                            child: Text('Vlogs'.tr,
                              style: TextStyle(
                                  color: Colors.grey,fontWeight: FontWeight.w600,fontSize:18.fSize
                              ),
                            ),
                          ),
                        ),
                      ),

                      InkWell(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => Saved_Blog_screen()));
                        },
                        child: Container(
                          height: 40.ah,width:83.aw,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                            //color: HexColor('#001649')
                          ),
                          child:  Center(
                            child: Text('Blogs'.tr,
                              style: TextStyle(
                                  color: Colors.grey,fontWeight: FontWeight.w500,fontSize:18.fSize
                              ),
                            ),
                          ),
                        ),
                      ),

                      InkWell(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => SavedPhoto_Screen()));
                        },
                        child: Container(
                          height: 40.ah,width:83.aw,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                            //color: HexColor('#001649')
                          ),
                          child:  Center(
                            child: Text('Photos'.tr,
                              style: TextStyle(
                                  color: Colors.grey,fontWeight: FontWeight.w500,fontSize:18.fSize
                              ),
                            ),
                          ),
                        ),
                      ),

                      Container(
                        height: 40.ah,width:83.aw,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                            color: HexColor('#001649')
                        ),
                        child:  Center(
                          child: Text('Profiles'.tr,
                            style: TextStyle(
                                color: Colors.white,fontWeight: FontWeight.w500,fontSize:18.fSize
                            ),),

                        ),
                      ),
                    ],
                  ),
                ),
              ),

             // SizedBox(height: 10.ah),
             // Text('Vlogs', style: TextStyle(color: Colors.black,fontWeight: FontWeight.w600,fontSize: 24.fSize),),

              SizedBox(height: 20.ah),
              // SavedBlog()
              Expanded(
                child: GridView.builder(
                    itemCount: 12,
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3,mainAxisExtent: 223,
                        mainAxisSpacing: 5,crossAxisSpacing: 5
                    ),
                    itemBuilder: (context, index) {
                      return Container(
                        height: 223.ah,width: 120.aw,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(7),
                            border: Border.all(
                              //color: HexColor('#FFFFFF'),
                                color: Colors.black12,
                                width:1
                            )
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                                height: 109.ah,width: 109.aw,
                                decoration: ShapeDecoration(
                                    color: Colors.white,
                                    shape: CircleBorder(),
                                    image: DecorationImage(
                                        image: AssetImage('assets/image/girrrls.png'),
                                        fit: BoxFit.cover
                                    )
                                )
                            ),

                            SizedBox(height:2.ah),
                            Text('Rose celebs',
                              style: TextStyle(
                                  color: Colors.black,fontWeight: FontWeight.w500,fontSize:13.fSize
                              ),
                            ),

                            SizedBox(height:2.ah),
                            Text('rose_ce',
                              style: TextStyle(
                                  color: Colors.grey,fontWeight: FontWeight.w600,fontSize:12.fSize
                              ),
                            ),

                            SizedBox(height:2.ah),
                            Text('27M',
                              style: TextStyle(
                                  color: Colors.black,fontWeight: FontWeight.w500,fontSize:12.fSize
                              ),
                            ),


                            SizedBox(height:10.ah),
                            InkWell(
                              onTap:  () {
                                active[0] = !active[0];
                                setState(() {
                                  follow_Unfollow[0] = "Follow".tr;
                                },
                                );
                              },
                              child: Container(
                                height: 24.ah,width: 98.aw,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(4),
                                  color: active[0] ? Colors.red : HexColor('#001649'),
                                ),
                                child:  Center(
                                  child: Text(active[0] ?'Unfollow'.tr:'Follow'.tr,
                                    style: TextStyle(
                                        color: active[0] ? Colors.white : Colors.white,
                                        fontWeight: FontWeight.w500,fontSize:14.fSize
                                    ),
                                  ),
                                ),
                              ),
                            )
                          ],
                        ),
                      );
                    }),
              ),
            ]
        ),
      ),
    );
  }
}
