import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:frenly_file/core/utils/size_utils.dart';
import 'package:hexcolor/hexcolor.dart';
import '../../dashboard_screen/dashboard_screen.dart';
import '../search_accounts/search_account.dart';
import '../search_blogs/search_blogs.dart';
import '../search_photos/search_photo_screen.dart';
import '../search_places/search_place.dart';
import 'package:get/get.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';

class SearchVlog_screen extends StatefulWidget {
  const SearchVlog_screen({super.key});

  @override
  State<SearchVlog_screen> createState() => _SearchVlog_screenState();
}

class _SearchVlog_screenState extends State<SearchVlog_screen> {
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
     // appBar: PreferredSize(preferredSize: Size(20,20), child: Text(" "),),

      body: Padding(
        padding: const EdgeInsets.only(left: 15,right: 15,top:63),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Card(
              color: Colors.white,
              shadowColor: Colors.black,
              surfaceTintColor: Colors.black,
              child: Container(
                // width: 293,
                width: MediaQuery.of(context).size.width,
                height:45,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                    color: Color(0xFFe9eaec),
                    borderRadius: BorderRadius.circular(14),

                ),
                child: TextField(
                  cursorColor: Color(0xFF000000),
                  style: TextStyle(color: Colors.black),
                  decoration: InputDecoration(
                      prefixIcon: //Image.asset('assets/images/seearch.png',),
                      Icon(Icons.search, color: Colors.black,),
                      hintText:"Search".tr,
                      hintStyle: TextStyle(color:Colors.grey,fontSize:19.fSize,fontWeight: FontWeight.w500),
                      border: InputBorder.none),

                ),
              ),
            ),
            SizedBox(height: 20.ah),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                InkWell(
                  onTap: () {
                  //  Navigator.pop(context);
                  },
                  child: Container(
                    padding: EdgeInsets.only(bottom: 5),
                    decoration: BoxDecoration(
                        border: Border(bottom: BorderSide(
                          color: Colors.black,  // Text colour here
                          width: 1.0, // Underline width
                        ))
                    ),
                    child: Text(
                      'Vlogs'.tr,
                      style: TextStyle(
                        color: Color(0xFF9C9C9C),
                        fontSize: 14.fSize,
                        fontFamily: 'Inter',
                        fontWeight: FontWeight.w500,
                        height: 1.ah,
                        //decorationColor: Colors.black,
                      //  decoration: TextDecoration.underline,
                       // decorationThickness: 2,
                       // decorationStyle: TextDecorationStyle.solid,
                        letterSpacing:2.ah,
                      ),
                    ),
                  ),
                ),

                SizedBox(width: 22.aw,),
                InkWell(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => SearchBlog_screen()));
                  },
                  child: Container(
                    padding: EdgeInsets.only(bottom: 5),
                    child: Text(
                      'Blogs'.tr,
                      style: TextStyle(
                        color: Color(0xFF9C9C9C),
                        fontSize: 14.fSize,
                        fontFamily: 'Inter',
                        fontWeight: FontWeight.w500,
                        height: 1,
                        letterSpacing: 0.65,
                      ),
                    ),
                  ),
                ),

                SizedBox(width: 22.aw,),

                InkWell(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => SearchPhoto_Screen()));
                  },
                  child: Container(
                    padding: EdgeInsets.only(bottom: 5),
                    child: Text(
                      'Photos'.tr,
                      style: TextStyle(
                        color: Color(0xFF9C9C9C),
                        fontSize: 14.fSize,
                        fontFamily: 'Inter',
                        fontWeight: FontWeight.w500,
                        height: 1,
                        letterSpacing: 0.65,
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 22.aw,),

                InkWell(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => SearchAccount_Screen()));
                  },
                  child: Container(
                    padding: EdgeInsets.only(bottom: 5),
                    child: Text(
                      'Profiles'.tr,
                      style: TextStyle(
                        color: Color(0xFF9C9C9C),
                        fontSize: 14.fSize,
                        fontFamily: 'Inter',
                        fontWeight: FontWeight.w500,
                        height: 1,
                        letterSpacing: 0.65,
                      ),
                    ),
                  ),
                ),
                /*SizedBox(width: 22.aw,),
                InkWell(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => SearchPlace_Screen()));
                  },
                  child: Container(
                    padding: EdgeInsets.only(bottom: 5),
                    child: Text(
                      'Places'.tr,
                      style: TextStyle(
                        color: Color(0xFF7F7F7F),
                        fontSize: 14.fSize,
                        fontFamily: 'Inter',
                        fontWeight: FontWeight.w500,
                        height: 1,
                        letterSpacing: 0.65,
                      ),
                    ),
                  ),
                )*/
              ],
            ),
            //SizedBox(height: 20.ah),
            Vlogslist(),

          ],
        ),
      ),

     // floatingActionButton: Padding(
     //   padding: const EdgeInsets.only(left: 30,),
     //   child: Container(
     //     height: 50.ah,width: MediaQuery.of(context).size.width,
     //     decoration: BoxDecoration(
     //       color: Colors.red,
     //       borderRadius: BorderRadius.circular(30),
     //     ),
     //   ),
     // ),

    /* bottomNavigationBar: Padding(
       padding: const EdgeInsets.all(8.0),
       child: Container(
         height: 50.ah,width: MediaQuery.of(context).size.width,
         decoration: BoxDecoration(
           color: Colors.red,
           borderRadius: BorderRadius.circular(30),
         ),
       ),
     ),*/

      bottomNavigationBar:  Padding(
        padding: const EdgeInsets.only(left: 15,right: 15,bottom: 15),
        child: Container(
          height: 61.ah,
          decoration: BoxDecoration(
             borderRadius: BorderRadius.circular(80),
             color: Color(0xff001649),
            //color: Colors.black.withOpacity(0.5),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: <Widget>[
              IconButton(
                icon: InkWell(
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => DashBoardScreen()));
                    },
                    child: Icon(Icons.home,color: Colors.white,)),
                onPressed: () => _onItemTapped(0),
              ),
              // This is necessary to create space in the center
              IconButton(
                icon:Image.asset('assets/image/Icon.png',height: 21.ah,width: 21.aw,color: Colors.white,),

                // Icon(Icons.notifications),
                onPressed: () => _onItemTapped(1),
              ),
              IconButton(
                icon:Container(
                  height: 43.ah,
                  width: 43.aw,
                  decoration: BoxDecoration(
                    // borderRadius: BorderRadius.all(Radius.circular(35)),
                    color:Colors.white,
                    shape: BoxShape.circle,
                  ),
                  child:Center(child: Image.asset('assets/image/Union (1).png',height: 19.ah,width: 19.aw,)),
                  // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                ),
                // Image.asset('assets/image/plus.png'),
                onPressed: () => _onItemTapped(2),
              ),
              IconButton(
                icon:Image.asset('assets/image/Icon (1).png',height: 21.ah,width: 21.aw,color: Colors.white,),
                onPressed: () => _onItemTapped(3),
              ),
              IconButton(
                icon:Image.asset('assets/image/Vector.png',height: 21.ah,width: 21.aw,color: Colors.white,),
                onPressed: () => _onItemTapped(4),
              ),
              // Image.asset('assets/image/Vector.png',height: 21.ah,width: 21.aw,color: Colors.white,)
            ],
          ),
        ),
      ),

     /* floatingActionButton:  Padding(
        padding: const EdgeInsets.all(15.0),
        child: Container(
          height: 61.ah,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(80),
            color: Color(0xff001649),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: <Widget>[
              InkWell(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => Demo_deshboardPage()));
                },
                child: IconButton(
                  icon: InkWell(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => Demo_deshboardPage()));
                      },
                      child: Icon(Icons.home,color: Colors.white,)),
                  onPressed: () => _onItemTapped(0),
                ),
              ),
              // This is necessary to create space in the center
              IconButton(
                icon:Image.asset('assets/image/Icon.png',height: 21.ah,width: 21.aw,color: Colors.white,),

                // Icon(Icons.notifications),
                onPressed: () => _onItemTapped(1),
              ),

              IconButton(
                icon:Container(
                  height: 43.ah,
                  width: 43.aw,
                  decoration: BoxDecoration(
                    // borderRadius: BorderRadius.all(Radius.circular(35)),
                    color:Colors.white,
                    shape: BoxShape.circle,
                  ),
                  child:Center(child: Image.asset('assets/image/Union (1).png',height: 19.ah,width: 19.aw,)),
                  // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                ),
                // Image.asset('assets/image/plus.png'),
                onPressed: () => _onItemTapped(2),
              ),
              IconButton(
                icon:Image.asset('assets/image/Icon (1).png',height: 21.ah,width: 21.aw,color: Colors.white,),
                onPressed: () => _onItemTapped(3),
              ),
              IconButton(
                icon:Image.asset('assets/image/Vector.png',height: 21.ah,width: 21.aw,color: Colors.white,),
                onPressed: () => _onItemTapped(4),
              ),
              // Image.asset('assets/image/Vector.png',height: 21.ah,width: 21.aw,color: Colors.white,)
            ],
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,*/
    );
  }
}

class Vlogslist extends StatelessWidget {
  const Vlogslist({super.key});

  @override
  Widget build(BuildContext context) {
    return  Expanded(
      child: Container(
        width: MediaQuery.of(context).size.width,
        height: 165.ah,
        child: ListView.builder(
          shrinkWrap: true,
          scrollDirection: Axis.vertical,
          itemCount: 10,
          itemBuilder: (context, index) {
            return Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Stack(
                alignment: Alignment.topLeft,
                children: [
                  Container(
                    height: 194.ah,width:MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(25),
                      // color: Colors.grey,
                      image: DecorationImage(
                          alignment: Alignment.center,fit: BoxFit.fill,
                          image: AssetImage('assets/image/Frame 21150.png')
                      ),

                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left:10,right: 15,top: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Icon(Icons.location_on,color: Colors.white,),
                                // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                Text('Sydney, Australia',
                                  style: TextStyle(
                                    color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                  ),),
                              ],
                            ),
                            Image.asset('assets/image/more op.png',width:22.aw,height: 16.ah,),
                          ],
                        ),
                        SizedBox(height: 60.ah),
                        Text('Circle'.tr,
                          style: TextStyle(
                              color: HexColor('#FFFFFF'),fontWeight: FontWeight.w700,fontSize:16.fSize,
                              height:1.5
                          ),
                        ),
                        SizedBox(height:10.ah),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  height: 24.ah,
                                  width: 24.aw,
                                  decoration: BoxDecoration(
                                    // borderRadius: BorderRadius.all(Radius.circular(35)),
                                      color: Color(0x305B5B5B),
                                      shape: BoxShape.circle,
                                      image: DecorationImage(
                                        fit: BoxFit.fill,
                                        image: AssetImage('assets/image/Ellipse 1.png'),
                                      )),
                                  // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                                ),
                                // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                Text('   Kriston',
                                  style: TextStyle(
                                    color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                  ),),
                                Text('  125K views',
                                  style: TextStyle(
                                    color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                  ),),
                                Text('3 week',
                                  style: TextStyle(
                                    color: HexColor('#FFFFFF'),fontWeight: FontWeight.w600,fontSize:11.fSize,
                                  ),),

                              ],
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment. spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Image.asset('assets/image/Unionnn.png',width:21.aw,height:21.ah,),
                                SizedBox(width: 5.aw),
                                Image.asset('assets/image/rename.png',width:22.aw,height:21.ah,),
                                SizedBox(width: 5.aw),
                                Image.asset('assets/image/bookmark.png',width:22.aw,height:21.ah,),

                              ],
                            )

                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}


/*
class StaggeredGridDemo extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Staggered Grid View Demo'),
      ),
      body: StaggeredGridView.countBuilder(
        crossAxisCount: 4,
        itemCount: 6, // Number of items in the grid
        itemBuilder: (BuildContext context, int index) => _buildItem(index),
        staggeredTileBuilder: (int index) => _tileBuilder(index),
        mainAxisSpacing: 4.0,
        crossAxisSpacing: 4.0,
      ),
    );
  }

  // Build individual grid items
  Widget _buildItem(int index) {
    return Container(
      color: Colors.blueGrey,
      child: Center(
        child: Text(
          'Item $index',
          style: TextStyle(color: Colors.white),
        ),
      ),
    );
  }

  // Build staggered tiles
  StaggeredTile _tileBuilder(int index) {
    if (index == 0) {
      return StaggeredTile.count(2, 2); // Larger tile at index 0
    } else {
      return StaggeredTile.count(1, 1); // Smaller tiles for other indices
    }
  }
}
*/

