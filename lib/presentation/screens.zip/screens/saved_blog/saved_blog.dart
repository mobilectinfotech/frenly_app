import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:frenly_file/presentation/screens/saved_people_profile/saved_people_profile.dart';
import 'package:frenly_file/presentation/screens/saved_photo/saved_photo.dart';
import 'package:frenly_file/presentation/screens/saved_vlogs/saved_vlogs.dart';
import 'package:frenly_file/core/utils/size_utils.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:get/get.dart';

class Saved_Blog_screen extends StatefulWidget {
  const Saved_Blog_screen({super.key});

  @override
  State<Saved_Blog_screen> createState() => _Saved_Blog_screenState();
}

class _Saved_Blog_screenState extends State<Saved_Blog_screen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        surfaceTintColor: Colors.white,
        backgroundColor: Colors.white,
        title: Row(
          children: [
            Text('Fashion'.tr,
              style: TextStyle(
                  color: Colors.black,fontWeight: FontWeight.w700,fontSize:32.fSize
              ),
            ),
          ],
        ),
        leading: Padding(
          padding:  EdgeInsets.only(left: 15.h),
          child: InkWell(
              onTap: () {
                Navigator.pop(context);
              },
              child: Icon(Icons.arrow_back_sharp)),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              height: 36.ah,
              width: 36.aw,
              decoration: BoxDecoration(
                // borderRadius: BorderRadius.all(Radius.circular(35)),
                  color: Color(0x305B5B5B),
                  shape: BoxShape.circle,
                  image: DecorationImage(
                    fit: BoxFit.fill,
                    image: AssetImage('assets/image/Ellipse 1.png'),
                  )),
              // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
            ),
          ),
        ],
      ),

      body: Padding(
        padding: const EdgeInsets.only(left: 10,right: 10,top:20),
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                height: 52.ah,width: 358.aw,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10)
                ),
                child: Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      InkWell(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => Save_Vlogs_Screen()));
                        },
                        child: Container(
                          height: 40.ah,width:83.aw,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                            // color: HexColor('#001649')
                          ),
                          child:  Center(
                            child: Text('Vlogs'.tr,
                              style: TextStyle(
                                  color: Colors.grey,fontWeight: FontWeight.w600,fontSize:18.fSize
                              ),
                            ),
                          ),
                        ),
                      ),

                      Container(
                        height: 40.ah,width:83.aw,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          color: HexColor('#001649')
                        ),
                        child:  Center(
                          child: Text('Blogs'.tr,
                            style: TextStyle(
                                color: Colors.white,fontWeight: FontWeight.w500,fontSize:18.fSize
                            ),
                          ),
                        ),
                      ),

                      InkWell(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => SavedPhoto_Screen()));
                        },
                        child: Container(
                          height: 40.ah,width:83.aw,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                            //color: HexColor('#001649')
                          ),
                          child:  Center(
                            child: Text('Photos'.tr,
                              style: TextStyle(
                                  color: Colors.grey,fontWeight: FontWeight.w500,fontSize:18.fSize
                              ),
                            ),
                          ),
                        ),
                      ),

                      InkWell(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => SavedPeople_profile()));
                        },
                        child: Container(
                          height: 40.ah,width:83.aw,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                             // color: HexColor('#001649')
                          ),
                          child:  Center(
                            child: Text('Profiles'.tr,
                              style: TextStyle(
                                  color: Colors.grey,fontWeight: FontWeight.w500,fontSize:18.fSize
                              ),),

                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

             // SizedBox(height: 10.ah),
              //Text('Vlogs', style: TextStyle(color: Colors.black,fontWeight: FontWeight.w600,fontSize: 24.fSize),),

              SizedBox(height: 20.ah),
              SavedBlog_list()
            ]
        ),
      ),
    );
  }
}


class SavedBlog_list extends StatelessWidget {
  const SavedBlog_list({super.key});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        width: MediaQuery.of(context).size.width,
        height: 105.ah,
        child: ListView.builder(
          shrinkWrap: true,
          scrollDirection: Axis.vertical,
          itemCount: 10,
          itemBuilder: (context, index) {
            return Padding(
              padding: const EdgeInsets.only(top: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    height: 144.ah,width: 144.aw,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        image: DecorationImage(
                            image: AssetImage('assets/image/Frame 21150 (2).png')
                        )
                    ),
                  ),
                  SizedBox(width:5.aw,),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            height: 20.ah,width: 60.aw,
                            decoration: BoxDecoration(
                                border: Border.all(
                                    color: Colors.black,
                                    width: 0.3
                                ),
                                borderRadius: BorderRadius.circular(5),
                                color: Colors.grey.shade300
                            ),
                            child:  Center(
                              child: Text('Cooking'.tr,
                                style: TextStyle(
                                    color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize
                                ),
                              ),
                            ),
                          ),
                          SizedBox(width: 130.aw),
                          Image.asset('assets/image/more option.png',height: 16.ah,width: 4.aw,),

                        ],
                      ),
                      SizedBox(height: 5.ah),
                      Text('letme'.tr,
                        style: TextStyle(
                            color: Colors.black,fontWeight: FontWeight.w600,fontSize:20.fSize
                        ),
                      ),
                      SizedBox(height: 5.ah),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            height: 32.ah,
                            width: 32.aw,
                            decoration: BoxDecoration(
                              // borderRadius: BorderRadius.all(Radius.circular(35)),
                                color: Color(0x305B5B5B),
                                shape: BoxShape.circle,
                                image: DecorationImage(
                                  fit: BoxFit.fill,
                                  image: AssetImage('assets/image/Frame 427320834.png'),
                                )),
                            // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                          ),
                          SizedBox(width: 10.aw),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text('Naila Iman',
                                style: TextStyle(
                                  color: Colors.black,fontWeight: FontWeight.w600,fontSize:14.fSize,
                                ),),
                              Text('Kriston.3 week'.tr,
                                style: TextStyle(
                                  color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize,
                                ),),
                            ],
                          ),


                        ],
                      ),
                    ],
                  )

                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
