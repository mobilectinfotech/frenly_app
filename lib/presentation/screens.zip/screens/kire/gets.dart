import 'dart:convert';
import 'package:http/http.dart';

import 'getmode.dart';

class HttpService {
  final String postsURL = "https://jsonplaceholder.typicode.com/post_photo_screen";

  Future<List<Post>> getPosts() async {
    Response res = await get(Uri.parse('http://3.104.197.136:4000/user/getFamilyMembers'));

    if (res.statusCode == 200) {
      List<dynamic> body = jsonDecode(res.body);

      List<Post> posts = body
          .map(
            (dynamic item) => Post.fromJson(item),
      )
          .toList();

      return posts;
    } else {
      throw "Unable to retrieve post_photo_screen.";
    }
  }
}