import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:frenly_file/core/constants/my_app_url.dart';
import 'package:frenly_file/data/repositories/api_repository.dart';
import 'package:get/get.dart';
import 'package:fluttertoast/fluttertoast.dart';

import '../../../dashboard_screen/dashboard_screen.dart';

class LoginController extends GetxController {

  TextEditingController emaillController = TextEditingController();
  TextEditingController passworddController = TextEditingController();

  RxBool isLoading = false.obs;

  @override
  void dispose() {
    emaillController.dispose();
    passworddController.dispose();
    super.dispose();
  }

  Future<void> loginWithEmail() async {
    bool login = await ApiRepository.loginWithEmailPassword(
        email: emaillController.text, password: passworddController.text);
    if (login) {
      Get.off(() => DashBoardScreen());
    }
  }
}
