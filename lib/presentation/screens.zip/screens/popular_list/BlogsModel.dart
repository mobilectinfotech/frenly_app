// To parse this JSON data, do
//
//     final blogsModel = blogsModelFromJson(jsonString);

import 'dart:convert';

BlogsModel blogsModelFromJson(String str) => BlogsModel.fromJson(json.decode(str));

String blogsModelToJson(BlogsModel data) => json.encode(data.toJson());

    class BlogsModel {
    bool? success;
    int? status;
    String? message;
    List<Blog>? blogs;

    BlogsModel({
        this.success,
        this.status,
        this.message,
        this.blogs,
    });

    factory BlogsModel.fromJson(Map<String, dynamic> json) => BlogsModel(
        success: json["success"],
        status: json["status"],
        message: json["message"],
        blogs: json["blogs"] == null ? [] : List<Blog>.from(json["blogs"]!.map((x) => Blog.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "success": success,
        "status": status,
        "message": message,
        "blogs": blogs == null ? [] : List<dynamic>.from(blogs!.map((x) => x.toJson())),
    };
}

class Blog {
    int? id;
    String? body;
    String? title;
    String? tags;
    dynamic city;
    String? imageUrl;
    dynamic country;
    int? userId;
    DateTime? createdAt;
    DateTime? updatedAt;
    int? numberOfLikes;
    int? numberOfShares;
    int? numberOfComments;
    int? numberOfSaves;
    User? user;
    bool? alreadyLiked;
    bool? alreadySaved;

    Blog({
        this.id,
        this.body,
        this.title,
        this.tags,
        this.city,
        this.imageUrl,
        this.country,
        this.userId,
        this.createdAt,
        this.updatedAt,
        this.numberOfLikes,
        this.numberOfShares,
        this.numberOfComments,
        this.numberOfSaves,
        this.user,
        this.alreadyLiked,
        this.alreadySaved,
    });

    factory Blog.fromJson(Map<String, dynamic> json) => Blog(
        id: json["id"],
        body: json["body"],
        title: json["title"],
        tags: json["tags"],
        city: json["city"],
        imageUrl: json["image_url"],
        country: json["country"],
        userId: json["userId"],
        createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
        updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
        numberOfLikes: json["numberOfLikes"],
        numberOfShares: json["numberOfShares"],
        numberOfComments: json["numberOfComments"],
        numberOfSaves: json["numberOfSaves"],
        user: json["user"] == null ? null : User.fromJson(json["user"]),
        alreadyLiked: json["alreadyLiked"],
        alreadySaved: json["alreadySaved"],
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "body": body,
        "title": title,
        "tags": tags,
        "city": city,
        "image_url": imageUrl,
        "country": country,
        "userId": userId,
        "createdAt": createdAt?.toIso8601String(),
        "updatedAt": updatedAt?.toIso8601String(),
        "numberOfLikes": numberOfLikes,
        "numberOfShares": numberOfShares,
        "numberOfComments": numberOfComments,
        "numberOfSaves": numberOfSaves,
        "user": user?.toJson(),
        "alreadyLiked": alreadyLiked,
        "alreadySaved": alreadySaved,
    };
}

class User {
    int? id;
    String? fullName;
    String? city;
    String? country;
    String? avatarUrl;
    String? coverPhotoUrl;

    User({
        this.id,
        this.fullName,
        this.city,
        this.country,
        this.avatarUrl,
        this.coverPhotoUrl,
    });

    factory User.fromJson(Map<String, dynamic> json) => User(
        id: json["id"],
        fullName: json["full_name"],
        city: json["city"],
        country: json["country"],
        avatarUrl: json["avatar_url"],
        coverPhotoUrl: json["cover_photo_url"],
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "full_name": fullName,
        "city": city,
        "country": country,
        "avatar_url": avatarUrl,
        "cover_photo_url": coverPhotoUrl,
    };
}
