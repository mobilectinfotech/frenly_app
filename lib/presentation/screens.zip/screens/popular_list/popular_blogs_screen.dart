import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:frenly_file/Widgets/custom_image_view.dart';
import 'package:frenly_file/core/utils/size_utils.dart';
import 'package:frenly_file/presentation/screens/popular_list/popular_blogs_controller.dart';
import 'package:get/get.dart';
import 'package:hexcolor/hexcolor.dart';

class PopularListScreen extends StatefulWidget {
  const PopularListScreen({super.key});

  @override
  State<PopularListScreen> createState() => _PopularListScreenState();
}

class _PopularListScreenState extends State<PopularListScreen> {


  PopularBlocController controller=Get.put(PopularBlocController());


  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Container(
              height: 140.ah,
              width: MediaQuery.of(context).size.width,
              //color: Colors.red,
              decoration: BoxDecoration(
                  image: DecorationImage(
                    fit: BoxFit.fill,
                    image: AssetImage('assets/image/aaa.png'),
                  )
              ),
              child:   Padding(
                padding: const EdgeInsets.only(left: 10,right: 10),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        InkWell(
                            onTap:(){
                              Navigator.pop(context);
                            },
                            child: Icon(Icons.arrow_back_outlined)),
                        SizedBox(width: 10),
                        Text('Popular'.tr,
                          style: TextStyle(
                              color: Colors.black,fontWeight: FontWeight.w700,fontSize: 30
                          ),
                        ),
                      ],
                    ),


                    InkWell(
                      onTap: () {
                        //Navigator.push(context, MaterialPageRoute(builder: (context) => Active_Friends()));
                      },
                      child: Container(
                        height: 36.ah,
                        width: 36.aw,
                        decoration: BoxDecoration(
                            color: Color(0x305B5B5B),
                            shape: BoxShape.circle,
                            image: DecorationImage(
                              fit: BoxFit.cover,
                              image: AssetImage('assets/image/Frame 21158.png'),
                            )),
                      ),

                    ),
                  ],
                ),
              ),
            ),

            SizedBox(height: 10.ah),
            Padding(
              padding: const EdgeInsets.only(left: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                //mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Row(
                     mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Dubai',
                            style: TextStyle(
                                color: Colors.black,fontWeight: FontWeight.w600,fontSize:24
                            ),
                          ),
                          Text('UAE',
                            style: TextStyle(
                                color: Colors.grey,fontWeight: FontWeight.w500,fontSize:16
                            ),
                          ),
                        ],
                      ),

                    ],
                  ),
                ],
              ),
            ),
            cardList(),

          ],
        ),
      ),
    );
  }

 Widget cardList(){
    return Expanded(
      child: Obx(
        ()=> controller.isLoading.value ? const Center(child: CircularProgressIndicator(),) : ListView.builder(
          shrinkWrap: true,
          scrollDirection: Axis.vertical,
          itemCount: controller.blogsModel!.blogs!.length,
          padding: const EdgeInsets.only(bottom: 10),
          itemBuilder: (context, index) {
            return Padding(
              padding: EdgeInsets.only(top: 10,),
              child: Stack(
                alignment: Alignment.topCenter,
                children: [
                  CustomImageView(
                    height: 196.ah, width: 362.aw,
                    radius: BorderRadius.circular(25),
                    fit: BoxFit.cover,
                    color: Colors.black,
                  //  color: Colors.black,
                    imagePath: controller.blogsModel!.blogs![index].imageUrl,

                  ),
                  Padding(
                    padding: const EdgeInsets.only(left:20, right:20, top: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                controller.blogsModel!.blogs![index].city !=null ?  Image.asset(
                                  'assets/image/location-outline.png', width: 21.aw,
                                  height: 21.ah,) : Container(),
                                Text('${controller.blogsModel!.blogs![index].city ?? ""}',
                                  style: TextStyle(
                                    color: HexColor('#FFFFFF'),
                                    fontWeight: FontWeight.w600,
                                    fontSize: 11.fSize,
                                  ),),
                              ],
                            ),
                            Image.asset('assets/image/more op.png', width: 22.aw,
                              height: 16.ah,),
                          ],
                        ),
                        SizedBox(height:70.ah),
                        Text('${controller.blogsModel!.blogs![index].title}'.tr,
                          style: TextStyle(
                              color: HexColor('#FFFFFF'),
                              fontWeight: FontWeight.w700,
                              fontSize: 16.fSize,
                              height: 1.5
                          ),
                        ),
                        SizedBox(height: 10.ah),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  height: 24.ah,
                                  width: 24.aw,
                                  decoration: const BoxDecoration(
                                    // borderRadius: BorderRadius.all(Radius.circular(35)),
                                      color: Color(0x305B5B5B),
                                      shape: BoxShape.circle,
                                      image: DecorationImage(
                                        fit: BoxFit.fill,
                                        image: AssetImage(
                                            'assets/image/Ellipse 1.png'),
                                      )),
                                  // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                                ),
                                // Image.asset('assets/image/location-outline.png',width: 10.aw,height: 15.ah,),
                                Text('${controller.blogsModel!.blogs![index].user!.fullName}',
                                  style: TextStyle(
                                    color: HexColor('#FFFFFF'),
                                    fontWeight: FontWeight.w600,
                                    fontSize: 11.fSize,
                                  ),),
                                Text('  125K views  ',
                                  style: TextStyle(
                                    color: HexColor('#FFFFFF'),
                                    fontWeight: FontWeight.w600,
                                    fontSize: 11.fSize,
                                  ),),
                                Text('3 week'.tr,
                                  style: TextStyle(
                                    color: HexColor('#FFFFFF'),
                                    fontWeight: FontWeight.w600,
                                    fontSize: 11.fSize,
                                  ),),

                              ],
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Image.asset('assets/image/like.png', width: 21.aw, height: 21.ah,),
                                SizedBox(width:11.aw),
                                Image.asset('assets/image/Union (2).png', width: 21.aw, height: 21.ah,),
                                SizedBox(width:11.aw),
                                Image.asset('assets/image/Vector (1).png', width: 22.aw, height: 21.ah,),
                                SizedBox(width:11.aw),
                                Image.asset('assets/image/bookmark.png', width: 22.aw, height: 21.ah,),
                              ],
                            )

                          ],
                        ),
                      ],
                    ),
                  ),

                ],
              ),
            );
          },
        ),
      ),
    );
  }
}


