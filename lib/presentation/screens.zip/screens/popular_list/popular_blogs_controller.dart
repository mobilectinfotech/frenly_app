import 'package:frenly_file/data/repositories/api_repository.dart';
import 'package:get/get.dart';

import 'BlogsModel.dart';
class PopularBlocController extends GetxController{

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    getBlock();
  }

  BlogsModel ? blogsModel;
  RxBool isLoading = false.obs;

   getBlock() async {
     isLoading.value =true;
    // blogsModel = await  ApiRepository.popularBlogs();
     isLoading.value =false;

   }


}