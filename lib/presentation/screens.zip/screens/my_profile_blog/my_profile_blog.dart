import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:frenly_file/core/utils/size_utils.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:get/get.dart';
import '../../dashboard_screen/dashboard_screen.dart';
import '../../user_profile_screen/my_profile_screen.dart';
import '../../user_profile_screen/user_profile_screen.dart';
import '../my_profile_photo/my_profile_photos.dart';

class MY_Profile_Blog extends StatefulWidget {
  const MY_Profile_Blog({super.key});

  @override
  State<MY_Profile_Blog> createState() => _MY_Profile_BlogState();
}

class _MY_Profile_BlogState extends State<MY_Profile_Blog> {

  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: HexColor('#E8E8E8'),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Stack(
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 10,right: 10,top: 235),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [

                              Text('Jessie Alvarado',
                                style: TextStyle(
                                    color: Colors.black,fontWeight: FontWeight.w600,fontSize:25
                                ),
                              ),

                              Text('jessie5204',
                                style: TextStyle(
                                    color: Colors.black54,fontWeight: FontWeight.w700,fontSize:15
                                ),
                              ),
                            ],
                          ),

                          Container(
                            height: 34.ah,width: 98.aw,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(4),
                                color: HexColor('#001649')
                            ),
                            child:  Center(
                              child: Text('Edit Profile'.tr,
                                style: TextStyle(
                                    color: Colors.white,fontWeight: FontWeight.w500,fontSize:14.fSize
                                ),
                              ),
                            ),
                          )
                        ],
                      ),

                      SizedBox(height: 10.ah),
                      Text('MyNamePro'.tr,
                        style: TextStyle(height: 1.5,
                          color: Colors.grey,fontWeight: FontWeight.w400,fontSize:16.fSize,
                        ),
                      ),

                      SizedBox(height: 15.ah),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text('18',
                                style: TextStyle(
                                  color: Colors.black,fontWeight: FontWeight.w600,fontSize:16.fSize,
                                ),
                              ),

                              Text('Posts'.tr,
                                style: TextStyle(
                                  color: Colors.grey,fontWeight: FontWeight.w500,fontSize:16.fSize,
                                ),
                              ),
                            ],
                          ),

                          Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text('517K',
                                style: TextStyle(
                                  color: Colors.black,fontWeight: FontWeight.w600,fontSize:16.fSize,
                                ),
                              ),

                              Text('Follower'.tr,
                                style: TextStyle(
                                  color: Colors.grey,fontWeight: FontWeight.w500,fontSize:16.fSize,
                                ),
                              ),
                            ],
                          ),

                          Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text('5.3k',
                                style: TextStyle(
                                  color: Colors.black,fontWeight: FontWeight.w600,fontSize:16.fSize,
                                ),
                              ),

                              Text('Following'.tr,
                                style: TextStyle(
                                  color: Colors.grey,fontWeight: FontWeight.w500,fontSize:16.fSize,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),

                      SizedBox(height: 15.ah),
                      Container(
                        height: 52.ah,width:MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10)
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(4.0),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              InkWell(
                                onTap: () {
                                  Navigator.push(context, MaterialPageRoute(builder: (context) => MyProfileScreen()));
                                },
                                child: Container(
                                  height: 40.ah,width:112.aw,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(8),
                                     // color: HexColor('#001649')
                                  ),
                                  child:  Center(
                                    child: Text('Vlogs'.tr,
                                      style: TextStyle(
                                          color: Colors.grey,fontWeight: FontWeight.w600,fontSize:18.fSize
                                      ),
                                    ),
                                  ),
                                ),
                              ),

                              Container(
                                height: 40.ah,width:112.aw,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                   color: HexColor('#001649')
                                ),
                                child:  Center(
                                  child: Text('Blogs'.tr,
                                    style: TextStyle(
                                        color: Colors.white,fontWeight: FontWeight.w500,fontSize:18.fSize
                                    ),
                                  ),
                                ),
                              ),

                              InkWell(
                                onTap: () {
                                  Navigator.push(context, MaterialPageRoute(builder: (context) => MyProfile_photos()));
                                },
                                child: Container(
                                  height: 40.ah,width:112.aw,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(8),
                                    // color: HexColor('#001649')
                                  ),
                                  child:  Center(
                                    child: Text('Photos'.tr,
                                      style: TextStyle(
                                          color: Colors.grey,fontWeight: FontWeight.w500,fontSize:18.fSize
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      SizedBox(height:20.ah),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                height: 144.ah,width: 144.aw,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(15),
                                    image: DecorationImage(
                                        image: AssetImage('assets/image/Frame 21150 (2).png')
                                    )
                                ),
                              ),
                              SizedBox(width:5.aw,),
                              Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Container(
                                        height: 20.ah,width: 60.aw,
                                        decoration: BoxDecoration(
                                            border: Border.all(
                                                color: Colors.black,
                                                width: 0.3
                                            ),
                                            borderRadius: BorderRadius.circular(5),
                                            color: Colors.grey.shade300
                                        ),
                                        child:  Center(
                                          child: Text('Cooking'.tr,
                                            style: TextStyle(
                                                color: Colors.grey,fontWeight: FontWeight.w500,fontSize:10.fSize
                                            ),
                                          ),
                                        ),
                                      ),

                                    ],
                                  ),
                                  SizedBox(height: 5.ah),
                                  Text('letme'.tr,
                                    style: TextStyle(
                                        color: Colors.black,fontWeight: FontWeight.w600,fontSize:20.fSize
                                    ),
                                  ),
                                  SizedBox(height: 5.ah),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        height: 32.ah,
                                        width: 32.aw,
                                        decoration: BoxDecoration(
                                          // borderRadius: BorderRadius.all(Radius.circular(35)),
                                            color: Color(0x305B5B5B),
                                            shape: BoxShape.circle,
                                            image: DecorationImage(
                                              fit: BoxFit.fill,
                                              image: AssetImage('assets/image/Frame 427320834.png'),
                                            )),
                                        // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                                      ),
                                      SizedBox(width: 10.aw),
                                      Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Text('Naila Iman',
                                            style: TextStyle(
                                              color: Colors.black,fontWeight: FontWeight.w600,fontSize:14.fSize,
                                            ),),
                                          Text('Kriston.3 weeks'.tr,
                                            style: TextStyle(
                                              color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize,
                                            ),),
                                        ],
                                      ),

                                    ],
                                  ),
                                ],
                              ),

                            ],
                          ),
                          Image.asset('assets/image/more option.png',height: 16.ah,width: 4.aw,),

                        ],
                      ),

                      SizedBox(height:20.ah),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                height: 144.ah,width: 144.aw,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(15),
                                    image: DecorationImage(
                                        image: AssetImage('assets/image/Frame 21150 (2).png')
                                    )
                                ),
                              ),
                              SizedBox(width:5.aw,),
                              Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Container(
                                        height: 20.ah,width: 60.aw,
                                        decoration: BoxDecoration(
                                            border: Border.all(
                                                color: Colors.black,
                                                width: 0.3
                                            ),
                                            borderRadius: BorderRadius.circular(5),
                                            color: Colors.grey.shade300
                                        ),
                                        child:  Center(
                                          child: Text('Cooking'.tr,
                                            style: TextStyle(
                                                color: Colors.grey,fontWeight: FontWeight.w500,fontSize:10.fSize
                                            ),
                                          ),
                                        ),
                                      ),

                                    ],
                                  ),
                                  SizedBox(height: 5.ah),
                                  Text('letme'.tr,
                                    style: TextStyle(
                                        color: Colors.black,fontWeight: FontWeight.w600,fontSize:20.fSize
                                    ),
                                  ),
                                  SizedBox(height: 5.ah),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        height: 32.ah,
                                        width: 32.aw,
                                        decoration: BoxDecoration(
                                          // borderRadius: BorderRadius.all(Radius.circular(35)),
                                            color: Color(0x305B5B5B),
                                            shape: BoxShape.circle,
                                            image: DecorationImage(
                                              fit: BoxFit.fill,
                                              image: AssetImage('assets/image/Frame 427320834.png'),
                                            )),
                                        // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                                      ),
                                      SizedBox(width: 10.aw),
                                      Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Text('Naila Iman',
                                            style: TextStyle(
                                              color: Colors.black,fontWeight: FontWeight.w600,fontSize:14.fSize,
                                            ),),
                                          Text('Kriston.3 weeks'.tr,
                                            style: TextStyle(
                                              color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize,
                                            ),),
                                        ],
                                      ),

                                    ],
                                  ),
                                ],
                              ),

                            ],
                          ),
                          Image.asset('assets/image/more option.png',height: 16.ah,width: 4.aw,),

                        ],
                      ),

                      SizedBox(height:20.ah),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                height: 144.ah,width: 144.aw,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(15),
                                    image: DecorationImage(
                                        image: AssetImage('assets/image/Frame 21150 (2).png')
                                    )
                                ),
                              ),
                              SizedBox(width:5.aw,),
                              Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Container(
                                        height: 20.ah,width: 60.aw,
                                        decoration: BoxDecoration(
                                            border: Border.all(
                                                color: Colors.black,
                                                width: 0.3
                                            ),
                                            borderRadius: BorderRadius.circular(5),
                                            color: Colors.grey.shade300
                                        ),
                                        child:  Center(
                                          child: Text('Cooking'.tr,
                                            style: TextStyle(
                                                color: Colors.grey,fontWeight: FontWeight.w500,fontSize:10.fSize
                                            ),
                                          ),
                                        ),
                                      ),

                                    ],
                                  ),
                                  SizedBox(height: 5.ah),
                                  Text('letme'.tr,
                                    style: TextStyle(
                                        color: Colors.black,fontWeight: FontWeight.w600,fontSize:20.fSize
                                    ),
                                  ),
                                  SizedBox(height: 5.ah),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        height: 32.ah,
                                        width: 32.aw,
                                        decoration: BoxDecoration(
                                          // borderRadius: BorderRadius.all(Radius.circular(35)),
                                            color: Color(0x305B5B5B),
                                            shape: BoxShape.circle,
                                            image: DecorationImage(
                                              fit: BoxFit.fill,
                                              image: AssetImage('assets/image/Frame 427320834.png'),
                                            )),
                                        // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                                      ),
                                      SizedBox(width: 10.aw),
                                      Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Text('Naila Iman',
                                            style: TextStyle(
                                              color: Colors.black,fontWeight: FontWeight.w600,fontSize:14.fSize,
                                            ),),
                                          Text('Kriston.3 weeks'.tr,
                                            style: TextStyle(
                                              color: Colors.grey,fontWeight: FontWeight.w500,fontSize:12.fSize,
                                            ),),
                                        ],
                                      ),

                                    ],
                                  ),
                                ],
                              ),

                            ],
                          ),
                          Image.asset('assets/image/more option.png',height: 16.ah,width: 4.aw,),

                        ],
                      ),

                      SizedBox(height:20.ah),

                    ],
                  ),
                ),
                Container(
                  height: MediaQuery.of(context).size.width,
                  width: MediaQuery.of(context).size.width,),

                Container(
                  width: MediaQuery.of(context).size.width,
                  height: 229.ah,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                        bottomRight: Radius.circular(25),bottomLeft: Radius.circular(25)
                    ),
                    image: DecorationImage(
                      image: AssetImage('assets/image/Frame 21141.png'),
                      fit: BoxFit.fill,
                    ),
                  ),
                ),


                Padding(
                  padding: const EdgeInsets.all(30.0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Image.asset('assets/image/ic_settings_24px.png',height: 20.ah,width: 20.aw,color: Colors.white,),
                    ],
                  ),
                ),

                Positioned(
                    top: 135.ah,
                    left: 120.aw,
                    child: Center(
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            Container(
                                width: 148.aw,
                                height: 148.ah,
                                //color: Colors.redAccent,
                                decoration: ShapeDecoration(
                                  color: Colors.white,
                                  shape: CircleBorder(),
                                )
                            ),
                            Container(
                                width: 140.aw,
                                height: 140.ah,
                                decoration: ShapeDecoration(
                                  color: Colors.grey,
                                  shape: CircleBorder(),
                                  image: DecorationImage(
                                      fit: BoxFit.cover,
                                      image:
                                      //NetworkImage("${firestore.currentUser!.photoURL}"),
                                      AssetImage('assets/image/nick-andreka-XJWm6jERxcc-unsplash.jpg')
                                  ),
                                )
                            ),
                          ],
                        )
                    )),


              ],
            ),

          ],
        ),
      ),

      floatingActionButton:  Padding(
        padding: const EdgeInsets.all(15.0),
        child: Container(
          height: 61.ah,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(80),
            color: Color(0xff001649),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: <Widget>[
              IconButton(
                icon: InkWell(
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => DashBoardScreen()));
                    },
                    child: Icon(Icons.home,color: Colors.white,)),
                onPressed: () => _onItemTapped(0),
              ),
              // This is necessary to create space in the center
              IconButton(
                icon:Image.asset('assets/image/Icon.png',height: 21.ah,width: 21.aw,color: Colors.white,),

                // Icon(Icons.notifications),
                onPressed: () => _onItemTapped(1),
              ),
              IconButton(
                icon:Container(
                  height: 43.ah,
                  width: 43.aw,
                  decoration: BoxDecoration(
                    // borderRadius: BorderRadius.all(Radius.circular(35)),
                    color:Colors.white,
                    shape: BoxShape.circle,
                  ),
                  child:Center(child: Image.asset('assets/image/Union (1).png',height: 19.ah,width: 19.aw,)),
                  // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                ),
                // Image.asset('assets/image/plus.png'),
                onPressed: () => _onItemTapped(2),
              ),
              IconButton(
                icon:Image.asset('assets/image/Icon (1).png',height: 21.ah,width: 21.aw,color: Colors.white,),
                onPressed: () => _onItemTapped(3),
              ),
              IconButton(
                icon:Image.asset('assets/image/Vector.png',height: 21.ah,width: 21.aw,color: Colors.white,),
                onPressed: () => _onItemTapped(4),
              ),
              // Image.asset('assets/image/Vector.png',height: 21.ah,width: 21.aw,color: Colors.white,)
            ],
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
}
