import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:frenly_file/presentation/screens/login_screen/login_screen.dart';
import 'package:frenly_file/core/utils/size_utils.dart';
import 'package:hexcolor/hexcolor.dart';
import '../../../core/constants/my_textfield.dart';
import 'controller/signup_controller.dart';
import 'package:get/get.dart';

class SignUp_Screen extends StatefulWidget {
  const SignUp_Screen({super.key});

  @override
  State<SignUp_Screen> createState() => _SignUp_ScreenState();
}

class _SignUp_ScreenState extends State<SignUp_Screen> {
  bool passwordVisible1 = false;
  @override
  void initState() {
    bool _isloding = false;

    super.initState();
    passwordVisible1 = true;
    passwordVisible2 = true;
  }

  bool passwordVisible2 = false;
  final formkey1 = GlobalKey<FormState>();

  final SignUpController signUpController = Get.put(SignUpController());
  final _formKeyLogin = GlobalKey<FormState>();


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //key: scaffoldKey,
      body: SingleChildScrollView(
        physics: BouncingScrollPhysics(),
        child: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          color: HexColor('#001649'),
          child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(height: 80.ah),
                Padding(
                  padding: EdgeInsets.only(left: 10.h, right: 10.h),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'createacc'.tr,
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                            fontSize: 35.fSize,
                            height: 1.ah),
                      ),
                      SizedBox(width: 50.aw),
                      Container(
                        height: 74.ah,
                        width: 74.aw,
                        decoration: BoxDecoration(
                            // borderRadius: BorderRadius.all(Radius.circular(35)),
                            color: Color(0x305B5B5B),
                            shape: BoxShape.circle,
                            image: DecorationImage(
                              fit: BoxFit.contain,
                              image: AssetImage('assets/image/image 1.png'),
                            )),

                        // child: Center(child: Text(firestore.currentUser!.displayName!.toUpperCase().characters.first.toString(), style: TextStyle(fontSize: 20.fSize,fontWeight: FontWeight.w400),)),
                      ),
                      // Image.asset('assets/image/image 1.png',height: 74.ah,width:74.aw,)
                    ],
                  ),
                ),
                Spacer(),
                Padding(
                  padding: EdgeInsets.only(left: 10.h, right: 10.h),
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(35),
                        topRight: Radius.circular(35),
                      ),
                    ),
                    child: Padding(
                      padding: EdgeInsets.only(left: 15.h, right: 15.h),
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(height: 30.ah),
                          Padding(
                            padding: EdgeInsets.only(left: 10.h),
                            child: Text(
                              'fullnm'.tr,
                              style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 15.fSize),
                            ),
                          ),

                          SizedBox(
                            height: 10.ah,
                          ),
                          primaryTextfield1(
                            hintText: 'john smith',
                            controller: signUpController.fullNameController,
                            // validator:Validator.validateFullName,
                          ),

                          // SizedBox(height: 10.ah,),
                          // primaryTextfield1(
                          //   hintText: 'smith',
                          //   controller:signUpController.lastnameCon,
                          //  // validator:Validator.validateFullName,
                          // ),

                          /*TextFormField(
                        validator: Validator.validateFullName,
                        decoration: InputDecoration(
                          counterText: "",
                          contentPadding: const EdgeInsets.only(left: 10,top: 12),
                          isDense: true,

                          // filled: true,
                          // fillColor: Colors.grey.withOpacity(.25),

                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12.h),
                            borderSide: BorderSide(
                              color: HexColor('#B5B5B5'),
                              width: 1,
                            ),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12.h),
                            borderSide: BorderSide(
                              color: HexColor('#B5B5B5'),
                              width: 1,
                            ),
                          ),
                          errorStyle: TextStyle(color: Colors.red),
                          errorBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12.h),
                            borderSide: BorderSide(
                              color: Colors.red,
                              width: 1,
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12.h),
                            borderSide: const BorderSide(
                              color: Color(0xff001649), width: 1,),),
                          hintStyle: TextStyle(
                              color: Colors.black.withOpacity(.40),
                              fontWeight: FontWeight.bold,
                              fontSize: 12),

                        ),


                        // validator: validator,
                      ),*/

                          SizedBox(
                            height: 10.ah,
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 10.h),
                            child: Text(
                              'emailn'.tr,
                              style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 15.fSize),
                            ),
                          ),

                          SizedBox(
                            height: 10.ah,
                          ),
                          primaryTextfield1(
                            hintText: 'john.smith@gmail.com',
                            controller: signUpController.emailController,
                            //validator:Validator.validateEmail,
                          ),

                          SizedBox(
                            height: 15.ah,
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 10.h),
                            child: Text(
                              'Passw'.tr,
                              style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 15.fSize),
                            ),
                          ),

                          SizedBox(
                            height: 10.ah,
                          ),
                          SizedBox(
                            height: 44.ah,
                            child: TextFormField(
                              controller: signUpController.passwordController,
                              obscureText: passwordVisible1,
                              //  validator: Validator.validatePassword,

                              /*validator: (val ){
                                if(val ==null)
                                  return 'Please enter your  password';
                                if(val != signUpController.passwordController.text)
                                  return "Passwords do not match";
                                return null;
                              },*/

                              autovalidateMode:
                                  AutovalidateMode.onUserInteraction,
                              textInputAction: TextInputAction.done,
                              decoration: InputDecoration(
                                contentPadding:
                                    EdgeInsets.only(left: 10.h, top: 10.h),
                                isDense: true,
                                fillColor: Colors.white,
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12.h),
                                  borderSide: BorderSide(
                                    color: HexColor('#B5B5B5'),
                                    width: 1,
                                  ),
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12.h),
                                  borderSide: BorderSide(
                                    color: HexColor('#B5B5B5'),
                                    width: 1,
                                  ),
                                ),
                                errorStyle: TextStyle(color: Colors.red),
                                errorBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12.h),
                                  borderSide: BorderSide(
                                    color: Colors.red,
                                    width: 1,
                                  ),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12.h),
                                  borderSide: BorderSide(
                                    color: Color(0xff001649),
                                    width: 1.aw,
                                  ),
                                ),
                                hintText: "Passw".tr,
                                hintStyle: TextStyle(
                                    color: Colors.black.withOpacity(.40),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 12.fSize),
                                suffixIcon: IconButton(
                                  icon: Icon(passwordVisible1
                                      ? Icons.visibility_off
                                      : Icons.visibility),
                                  onPressed: () {
                                    setState(
                                      () {
                                        passwordVisible1 = !passwordVisible1;
                                      },
                                    );
                                  },
                                ),
                                alignLabelWithHint: false,
                                filled: true,
                              ),
                              keyboardType: TextInputType.visiblePassword,
                            ),
                          ),

                          SizedBox(
                            height: 15.ah,
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 10.h),
                            child: Text(
                              'REPassw'.tr,
                              style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 15.fSize),
                            ),
                          ),

                          SizedBox(
                            height: 10.ah,
                          ),
                          SizedBox(
                            height: 44.ah,
                            child: TextFormField(
                              obscureText: passwordVisible2,
                              controller:
                                  signUpController.confirmpasswordController,

                              //controller: null,
                              // validator: Validator.validatePassword,

                              // validator: (val ){
                              //   if(val ==null)
                              //     return 'Please enter your confirm password';
                              //   if(val != signUpController.confirmpasswordController.text)
                              //     return "Passwords do not match";
                              //   return null;
                              // },

                              autovalidateMode:
                                  AutovalidateMode.onUserInteraction,
                              textInputAction: TextInputAction.done,

                              decoration: InputDecoration(
                                isDense: true,
                                fillColor: Colors.white,
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12.h),
                                  borderSide: BorderSide(
                                    color: HexColor('#B5B5B5'),
                                    width: 1.aw,
                                  ),
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12.h),
                                  borderSide: BorderSide(
                                    color: HexColor('#B5B5B5'),
                                    width: 1.aw,
                                  ),
                                ),
                                errorStyle: TextStyle(color: Colors.red),
                                errorBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12.h),
                                  borderSide: BorderSide(
                                    color: Colors.red,
                                    width: 1,
                                  ),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12.h),
                                  borderSide: BorderSide(
                                    color: Color(0xff001649),
                                    width: 1.aw,
                                  ),
                                ),
                                hintText: "Passw".tr,
                                hintStyle: TextStyle(
                                    color: Colors.black.withOpacity(.40),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 12.fSize),
                                suffixIcon: IconButton(
                                  icon: Icon(passwordVisible2
                                      ? Icons.visibility_off
                                      : Icons.visibility),
                                  onPressed: () {
                                    setState(
                                      () {
                                        passwordVisible2 = !passwordVisible2;
                                      },
                                    );
                                  },
                                ),
                                alignLabelWithHint: false,
                                filled: true,
                              ),
                              keyboardType: TextInputType.visiblePassword,
                              // textInputAction: TextInputAction.done,
                            ),
                          ),

                          /*CustomTextFormField(
                            validator: (val ){
                              if(val ==null)
                                return 'Please enter your confirm password';
                              if(val != controller.passWordValueController.text)
                                return "Passwords do not match";
                              return null;
                            }  ,
                            autovalidateMode: AutovalidateMode.onUserInteraction,
                            controller: controller.cpassWordValueController,
                            textInputAction: TextInputAction.done,
                            suffix: InkWell(
                                onTap: () {
                                  controller.cisShowPassword.value = !controller.cisShowPassword.value;
                                },
                                child: Container(
                                    margin: EdgeInsets.fromLTRB(30.h, 14.v, 10.h, 14.v),
                                    child:controller.cisShowPassword.value ? Icon(Icons.password)  :
                                    Icon(Icons.remove_red_eye_sharp)
                                )),
                            suffixConstraints: BoxConstraints(maxHeight: 44.v),
                            obscureText: controller.cisShowPassword.value)));
                            */

                          SizedBox(
                            height: 30.ah,
                          ),
                          Obx(
                            () => CustomPrimaryBtn1(
                              title: 'sg'.tr,
                              isLoading: signUpController.isLoading.value,
                              onTap: () {
                                if (formkey1.currentState!.validate()) {

                                }
                              },
                            ),
                          ),

                          SizedBox(height: 10.ah),
                          Center(
                            child: Text(
                              'Alredy'.tr,
                              style: TextStyle(
                                  color: Colors.black38,
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16.fSize),
                            ),
                          ),

                          SizedBox(height: 10.ah),
                          Center(
                            child: InkWell(
                              onTap: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => LoginScreen()));
                              },
                              child: Text(
                                'Log'.tr,
                                style: TextStyle(
                                    color: Colors.black,
                                    fontWeight: FontWeight.w700,
                                    fontSize: 20.fSize),
                              ),
                            ),
                          ),

                          SizedBox(
                            height: 30.ah,
                          )
                        ],
                      ),
                    ),
                  ),
                ),

                //Padding(padding: EdgeInsets.symmetric(vertical: MediaQuery.of(context).viewInsets.bottom),)
              ]),
        ),
      ),
    );
  }
}
