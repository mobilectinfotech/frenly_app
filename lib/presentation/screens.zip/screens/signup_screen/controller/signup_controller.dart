import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:frenly_file/data/repositories/api_repository.dart';
import 'package:get/get_state_manager/get_state_manager.dart';
import 'package:get/get_rx/get_rx.dart';
import 'package:get/get.dart';


class  SignUpController extends GetxController {

  TextEditingController fullNameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmpasswordController = TextEditingController();
  TextEditingController firstnameCon = TextEditingController();
  TextEditingController lastnameCon = TextEditingController();


  RxBool isLoading = false.obs;
  RxBool seePassword = true.obs;
  RxBool seePassword1 = true.obs;



   @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    fullNameController.dispose();
    emailController.dispose();
    passwordController.dispose();
    confirmpasswordController.dispose();
    firstnameCon.dispose();
    lastnameCon.dispose();
  }


    signUp(){
     
     
   //  ApiRepository.signUpWithEmailPassword(email: emailController.text, password: password, frist_name: frist_name, last_name: last_name)
     
     
    }









}
